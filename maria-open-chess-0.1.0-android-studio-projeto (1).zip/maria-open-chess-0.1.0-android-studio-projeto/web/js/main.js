import { h } from './dom.js';
import { S, subscribe, refresh, connectWs } from './net.js';
import { renderPublic, resetRound } from './public.js';
import { mountGame } from './game.js';

const app = document.getElementById('app');
const isAdmin = location.pathname.replace(/\/+$/, '') === '/admin';

// ------------------------------------------------------------ tema
function applyTheme(t) { document.documentElement.setAttribute('data-theme', t); const m = document.querySelector('meta[name=theme-color]'); if (m) m.content = t === 'light' ? '#f3f5f8' : '#0e1116'; }
let theme = 'dark';
try { theme = localStorage.getItem('oc.theme') || 'dark'; } catch (_) { /* padrão escuro */ }
applyTheme(theme);
function toggleTheme() { theme = theme === 'dark' ? 'light' : 'dark'; applyTheme(theme); try { localStorage.setItem('oc.theme', theme); } catch (_) { /* ok */ } render(true); }

// ------------------------------------------------------------ estrutura
const connLabel = { ok: 'Ao vivo', bad: 'Reconectando…', connecting: 'Conectando…' };
const connDot = h('i');
const connText = h('span', null, 'Conectando…');
const conn = h('span', { class: 'conn', role: 'status' }, connDot, connText);
const themeBtn = h('button', { class: 'btn small', type: 'button', 'aria-label': 'Alternar tema claro/escuro', onclick: toggleTheme }, 'Tema');
const main = h('main', { id: 'main', tabindex: '-1' });
app.append(
  h('header', { class: 'topbar' }, h('div', { class: 'topbar-in' },
    h('a', { class: 'brand', href: isAdmin ? '/admin' : '/' }, h('img', { src: '/logo.svg', alt: '' }), h('span', null, 'maria open '), h('b', null, 'CHESS')),
    isAdmin && h('span', { class: 'chip warn' }, 'Organizador'), h('span', { class: 'spacer' }), conn, themeBtn)),
  main,
);

function paintConn() { conn.className = 'conn ' + (S.conn === 'ok' ? 'ok' : S.conn === 'bad' ? 'bad' : ''); connText.textContent = connLabel[S.conn]; }

// ------------------------------------------------------------ roteamento
const route = () => { const parts = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean); return { page: parts[0] || '', id: Number(parts[1]) || null }; };
let current = { key: '', dispose: null }, lastSig = '', renderSeq = 0;

async function render(force = false) {
  paintConn();
  const r = route();
  const gameRoute = !isAdmin ? (r.page === 'jogo' || r.page === 'pgn') && r.id : (r.page === 'jogo' || r.page === 'pgn') && r.id;
  const key = gameRoute ? `${r.page}/${r.id}` : 'page:' + r.page;
  if (gameRoute) {
    renderSeq++;
    if (current.key !== key || force) {
      if (current.dispose) current.dispose();
      lastSig = '';
      current = { key, dispose: mountGame(main, r.page === 'pgn' ? 'pgn' : 'game', r.id) };
      window.scrollTo(0, 0);
    }
    return;
  }
  if (current.dispose) { current.dispose(); current.dispose = null; }
  const seq = ++renderSeq;
  const sig = JSON.stringify([key, S.t, S.players, S.rounds, S.games, S.standings, S.stats, S.imported, S.me, S.adminStatus, S.error, theme, S.admin, S.adminData]);
  if (!force && sig === lastSig && current.key === key) return;
  lastSig = sig; current.key = key;
  const y = window.scrollY;
  const box = h('div');
  if (isAdmin) { const { renderAdmin } = await import('./admin.js'); await renderAdmin(box, r.page); }
  else renderPublic(box, r.page);
  if (seq !== renderSeq) return; // uma renderização mais nova já assumiu
  main.replaceChildren(...box.childNodes);
  window.scrollTo(0, y);
}

window.addEventListener('hashchange', () => { resetRound(); render(true); });
window.addEventListener('oc-rerender', () => render(true));
subscribe(() => render());

(async () => {
  if (isAdmin) { const { initAdmin } = await import('./admin.js'); await initAdmin(); }
  await refresh();
  connectWs();
  render(true);
})();
