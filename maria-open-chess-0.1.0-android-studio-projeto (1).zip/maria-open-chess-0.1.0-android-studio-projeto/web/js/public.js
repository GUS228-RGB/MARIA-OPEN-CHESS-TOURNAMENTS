// Página dos participantes.
import { h, LABELS, idLabel, toast, openForm, confirmDialog, fmtPts } from './dom.js';
import { S, api, setToken, authWs, refresh } from './net.js';
import { playersTable, standingsTable, statsView, roundsView, emptyState, pname } from './views.js';

export const PUBLIC_TABS = [['participantes', 'Participantes'], ['rodadas', 'Rodadas'], ['classificacao', 'Classificação'], ['estatisticas', 'Estatísticas'], ['downloads', 'Downloads']];
let selectedRound = null;
export const resetRound = () => { selectedRound = null; };

export function joinDialog() {
  return openForm({
    title: 'Participar do torneio',
    intro: 'Só precisamos do nome que vai aparecer na classificação. Não há cadastro, e-mail nem senha. Nomes repetidos são permitidos: cada pessoa recebe um ID próprio.',
    submitLabel: 'Entrar no torneio',
    fields: [
      { name: 'name', label: 'Nome de exibição', maxlength: 40, placeholder: 'Ex.: Maria' },
      { name: 'elo', label: 'Rating Elo (opcional)', type: 'number', min: 0, max: 4000, hint: 'Se você conhece o seu rating, informe. Ele ajuda no sorteio inicial e no desempate.' },
    ],
    async submit(v) {
      if (!String(v.name || '').trim()) throw new Error('Digite o seu nome.');
      const r = await api('POST', '/api/join', { name: v.name, elo: v.elo });
      setToken(r.token); authWs();
      await refresh();
      toast(`Inscrição feita! Você é ${r.player.name} (ID ${idLabel(r.player.number)}).`, 'ok');
    },
  });
}

async function leave() {
  if (!(await confirmDialog({ title: 'Sair do torneio?', message: S.t.status === 'setup' ? 'Sua inscrição será removida.' : 'Você será marcado como desistente e suas partidas pendentes serão canceladas.', confirmLabel: 'Sair do torneio', danger: true }))) return;
  try { await api('POST', '/api/leave'); setToken(null); await refresh(); toast('Você saiu do torneio.'); } catch (e) { toast(e.message, 'error'); }
}

export function infoChips(t) {
  return h('div', { class: 'row' },
    h('span', { class: 'chip accent' }, LABELS.modality[t.modality]), h('span', { class: 'chip' }, LABELS.system[t.system]),
    h('span', { class: 'chip ' + (t.status === 'running' ? 'ok live' : t.status === 'finished' ? '' : 'warn') }, LABELS.status[t.status]),
    t.status === 'setup' && h('span', { class: 'chip ' + (t.registration === 'open' && !t.full ? 'ok' : 'danger') }, t.full ? 'Lotado' : LABELS.registration[t.registration]),
    t.modality !== 'presencial' && h('span', { class: 'chip' }, `${Math.floor(t.time_base_s / 60)}${t.time_base_s % 60 ? ':' + String(t.time_base_s % 60).padStart(2, '0') : ''} min${t.time_inc_s ? ' + ' + t.time_inc_s + 's' : ''}`));
}

export function slotsBlock(t) {
  const pct = Math.min(100, Math.round((t.players_count / t.max_players) * 100));
  return h('div', { class: 'stack' },
    h('div', { class: 'row between' }, h('span', null, h('b', null, t.players_count), ` de ${t.max_players} participantes`), h('b', { style: t.full ? 'color:var(--danger)' : '' }, t.full ? 'Torneio lotado' : `${t.slots_left} ${t.slots_left === 1 ? 'vaga restante' : 'vagas restantes'}`)),
    h('div', { class: 'bar', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': t.max_players, 'aria-valuenow': t.players_count, 'aria-label': 'Vagas ocupadas' }, h('i', { style: `width:${pct}%` })));
}

function myMatch() {
  if (!S.me) return null;
  const mine = S.me.games.filter((g) => ['waiting', 'playing'].includes(g.state) && g.black_id != null && S.rounds.find((r) => r.number === g.round && r.status === 'running'));
  return mine.length ? mine[mine.length - 1] : null;
}

function joinArea() {
  const t = S.t;
  if (S.me) {
    const p = S.me.player;
    const m = myMatch();
    const opp = m && (m.white_id === p.id ? m.black : m.white);
    const color = m && (m.white_id === p.id ? 'brancas' : 'pretas');
    return h('div', { class: 'stack' },
      h('div', { class: 'banner' }, h('span', null, 'Você está inscrito como ', h('b', null, p.name), h('span', { class: 'pid' }, idLabel(p.number)), S.me.position && t.status !== 'setup' ? ` — ${S.me.position}º na classificação` : ''),
        t.status !== 'finished' && p.status === 'active' && h('button', { class: 'btn small', onclick: leave }, 'Sair do torneio')),
      m && S.me.currentGame ? h('div', { class: 'banner' }, h('span', null, h('b', null, 'Sua partida online está pronta. '), `Rodada ${m.round}, você joga de ${color} contra `, pname(opp), '.'), h('a', { class: 'btn primary', href: `#/jogo/${S.me.currentGame}` }, 'Jogar agora'))
        : m ? h('div', { class: 'banner' }, h('span', null, h('b', null, `Rodada ${m.round}: `), `você joga de ${color} contra `, pname(opp), m.table_no ? ` na mesa ${m.table_no}.` : '.', m.kind === 'presencial' ? ' O resultado é lançado pelo organizador.' : ''), h('a', { class: 'btn', href: `#/jogo/${m.id}` }, 'Ver confronto')) : null);
  }
  if (t.status === 'finished') return h('div', { class: 'banner' }, 'Este torneio foi finalizado. Veja a classificação e baixe os resultados abaixo.');
  if (t.status === 'running') return h('div', { class: 'banner warn' }, 'O torneio já começou e as inscrições estão encerradas. Você pode acompanhar tudo por aqui.');
  if (t.full) return h('div', { class: 'banner danger' }, h('b', null, 'O torneio está lotado.'), ' Todas as vagas foram preenchidas.');
  if (t.registration !== 'open') return h('div', { class: 'banner warn' }, LABELS.registration[t.registration] + ' pelo organizador.');
  return h('div', null, h('button', { class: 'btn primary big', onclick: joinDialog }, 'PARTICIPAR'));
}

function downloads() {
  const t = S.t;
  const link = (href, label, desc) => h('div', { class: 'award' }, h('div', { class: 'ic', 'aria-hidden': 'true' }, '⬇'), h('div', { style: 'flex:1' }, h('b', null, label), h('small', null, desc)), h('a', { class: 'btn small', href, download: '' }, 'Baixar'));
  return h('div', { class: 'stack' },
    link('/api/results.txt', 'Resultados (TXT)', t.status === 'finished' ? 'Classificação final do torneio.' : 'Classificação parcial — o arquivo final é gerado quando o torneio termina.'),
    link('/api/pgn?download=1', 'Partidas com lances (PGN)', 'Todas as partidas que têm lances registrados, em notação SAN.'),
    link('/api/pgn?todas=1&download=1', 'Todas as partidas (PGN)', 'Inclui partidas presenciais só com resultado, sem inventar lances.'),
    S.imported.length ? h('div', { class: 'card' }, h('h3', null, 'Partidas importadas (PGN)'), S.imported.map((g) => h('div', { class: 'row between', style: 'padding:6px 0' }, h('span', null, `${g.white} × ${g.black}`, h('span', { class: 'muted' }, ` ${g.event} ${g.date} · ${g.plies} lances`)), h('a', { class: 'btn small', href: `#/pgn/${g.id}` }, 'Reproduzir')))) : null);
}

export function renderPublic(root, tab) {
  const t = S.t;
  if (!t) { root.append(S.error ? h('div', { class: 'card' }, h('div', { class: 'err' }, S.error), h('button', { class: 'btn', onclick: refresh }, 'Tentar de novo')) : h('div', { class: 'empty-state' }, 'Carregando…')); return; }
  tab = PUBLIC_TABS.some(([k]) => k === tab) ? tab : 'participantes';
  S.statsWanted = tab === 'estatisticas'; S.importedWanted = tab === 'downloads';
  root.append(
    h('section', { class: 'card hero stack' }, h('h1', null, t.name), t.description && h('p', null, t.description), infoChips(t), slotsBlock(t), joinArea()),
    h('nav', { class: 'tabs', role: 'tablist', 'aria-label': 'Seções' }, PUBLIC_TABS.map(([k, label]) => h('a', { class: 'tab', role: 'tab', href: '#/' + k, 'aria-selected': String(tab === k) }, label))),
    tab === 'participantes' ? h('div', { class: 'card pad0' }, playersTable())
      : tab === 'rodadas' ? roundsView({ selected: selectedRound, onSelect: (n) => { selectedRound = n; window.dispatchEvent(new Event('oc-rerender')); }, meId: S.me && S.me.player.id })
        : tab === 'classificacao' ? h('div', { class: 'stack' }, h('div', { class: 'card pad0' }, standingsTable()), h('p', { class: 'note' }, 'Desempate: ' + (S.t.tiebreaks || []).map((k) => LABELS.tiebreak[k] || k).join(' → ') + `. Pontuação: vitória ${fmtPts(t.pts_win)}, empate ${fmtPts(t.pts_draw)}, derrota ${fmtPts(t.pts_loss)}.`))
          : tab === 'estatisticas' ? statsView() : downloads());
}
