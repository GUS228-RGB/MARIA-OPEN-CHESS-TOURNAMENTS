'use strict';
/**
 * Túnel de acesso por outras redes (internet), sem conta e sem serviço pago.
 * Usa um programa externo que o computador do organizador já tenha:
 *   1) cloudflared  — "Quick Tunnel" gratuito da Cloudflare  (https://xxxx.trycloudflare.com)
 *   2) ssh          — cliente OpenSSH (já vem no Windows 10/11, Linux e macOS) + localhost.run
 * O túnel entrega HTTPS/WSS; o servidor continua rodando no computador do organizador.
 */
const { spawn, spawnSync } = require('node:child_process');

const PROVIDERS = {
  cloudflared: {
    bin: 'cloudflared',
    label: 'Cloudflare Quick Tunnel',
    args: (port) => ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${port}`],
    re: /https:\/\/[a-z0-9-]+\.trycloudflare\.com/i,
    hint: 'Instale o cloudflared: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/',
  },
  ssh: {
    bin: 'ssh',
    label: 'SSH + localhost.run',
    args: (port) => ['-o', 'StrictHostKeyChecking=accept-new', '-o', 'ServerAliveInterval=30', '-o', 'ExitOnForwardFailure=yes', '-o', 'BatchMode=yes', '-R', `80:127.0.0.1:${port}`, 'nokey@localhost.run'],
    re: /https:\/\/[a-z0-9-]+\.(?:lhr\.life|localhost\.run)/i,
    hint: 'Instale o cliente OpenSSH (já vem no Windows 10/11; no Linux: sudo apt install openssh-client).',
  },
};

/** Extrai a URL pública de um trecho de saída do programa de túnel. */
function parseTunnelUrl(provider, text) {
  const p = PROVIDERS[provider];
  if (!p) return null;
  const m = p.re.exec(String(text));
  return m ? m[0].toLowerCase() : null;
}

function hasBinary(bin) {
  const r = spawnSync(bin, [bin === 'ssh' ? '-V' : '--version'], { stdio: 'ignore', timeout: 5000 });
  return !(r.error && r.error.code === 'ENOENT');
}

/**
 * Inicia o túnel. Resolve { url, provider, label, stop(), onDown(cb) } ou rejeita com mensagem clara.
 * @param {{port:number, provider?:'auto'|'cloudflared'|'ssh', timeoutMs?:number, log?:(s:string)=>void}} o
 */
function startTunnel({ port, provider = 'auto', timeoutMs = 45000, log = () => {} }) {
  const order = provider === 'auto' ? ['cloudflared', 'ssh'] : [provider];
  for (const name of order) if (!PROVIDERS[name]) return Promise.reject(new Error(`Provedor de túnel desconhecido: "${name}". Use: auto, cloudflared ou ssh.`));
  const available = order.filter((n) => hasBinary(PROVIDERS[n].bin));
  if (!available.length) {
    const hints = order.map((n) => `  • ${PROVIDERS[n].bin}: ${PROVIDERS[n].hint}`).join('\n');
    return Promise.reject(new Error(`Nenhum programa de túnel encontrado neste computador.\n${hints}`));
  }
  const attempt = (idx, errors) => new Promise((resolve, reject) => {
    const name = available[idx];
    const prov = PROVIDERS[name];
    const child = spawn(prov.bin, prov.args(port), { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    let buf = '', done = false, downCb = null;
    const fail = (msg) => {
      if (done) return; done = true; clearTimeout(timer);
      try { child.kill(); } catch (_) { /* já encerrou */ }
      if (idx + 1 < available.length) attempt(idx + 1, [...errors, `${prov.label}: ${msg}`]).then(resolve, reject);
      else reject(new Error([...errors, `${prov.label}: ${msg}`].join('\n')));
    };
    const onData = (d) => {
      const t = d.toString();
      buf = (buf + t).slice(-4000);
      log(t.trim().split('\n').pop());
      if (done) return;
      const url = parseTunnelUrl(name, buf);
      if (url) {
        done = true; clearTimeout(timer);
        resolve({
          url: url + '/', provider: name, label: prov.label,
          stop: () => { downCb = null; try { child.kill(); } catch (_) { /* ok */ } },
          onDown: (cb) => { downCb = cb; },
        });
      }
    };
    child.stdout.on('data', onData); child.stderr.on('data', onData);
    child.on('error', (e) => fail(`não foi possível executar (${e.code || e.message})`));
    child.on('exit', (code) => {
      if (!done) fail(`encerrou antes de abrir o túnel (código ${code}). ${buf.trim().split('\n').slice(-2).join(' ').slice(0, 200)}`);
      else if (downCb) downCb(code);
    });
    const timer = setTimeout(() => fail(`sem resposta em ${Math.round(timeoutMs / 1000)}s (verifique a conexão com a internet)`), timeoutMs);
  });
  return attempt(0, []);
}

module.exports = { startTunnel, parseTunnelUrl, hasBinary, PROVIDERS };
