'use strict';
/**
 * Lançador local ("modo app"): tela CRIAR TORNEIO / INICIAR HOSPEDAGEM que roda no navegador do
 * próprio aparelho (celular via Termux, ou computador). Escuta SOMENTE em 127.0.0.1.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const { TournamentError, TournamentService } = require('../core/tournament');
const { HostSession } = require('./session');
const { listSaved, isTermux, isAndroidApp } = require('./paths');
const { hasBinary } = require('../cli/tunnel');
const { qrSvg } = require('../core/qr');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.json': 'application/json; charset=utf-8' };
const ALLOWED_STATIC = /^\/(launcher\.html|app\.css|logo\.svg|js\/(dom|launcher)\.js)$/;
const HOST_OK = /^(localhost|127\.0\.0\.1|\[::1\]):\d+$/;

class Launcher {
  constructor({ webDir, log = null }) {
    this.webDir = webDir;
    this.session = new HostSession({ webDir, log });
    this.server = http.createServer((req, res) => this._handle(req, res));
    this.port = null;
    this.tunnelTools = null;
  }

  async listen(port = 8780) {
    for (let i = 0; i < 20; i++) {
      try {
        await new Promise((resolve, reject) => { const onErr = (e) => { this.server.off('listening', ok); reject(e); }; const ok = () => { this.server.off('error', onErr); resolve(); }; this.server.once('error', onErr); this.server.once('listening', ok); this.server.listen(port + i, '127.0.0.1'); });
        this.port = this.server.address().port; return this.port;
      } catch (e) { if (e.code !== 'EADDRINUSE') throw e; }
    }
    throw new Error('Não foi possível encontrar uma porta livre para a tela do aplicativo.');
  }

  url() { return `http://localhost:${this.port}/`; }
  async close() { await this.session.stop(); await new Promise((r) => { this.server.close(() => r()); this.server.closeAllConnections?.(); }); }

  _send(res, status, body, type = 'application/json; charset=utf-8') {
    res.writeHead(status, {
      'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
      'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'",
    });
    res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
  }

  state() {
    if (!this.tunnelTools) this.tunnelTools = isAndroidApp() ? { cloudflared: false, ssh: false } : { cloudflared: hasBinary('cloudflared'), ssh: hasBinary('ssh') };
    return {
      platform: { termux: isTermux(), android_app: isAndroidApp(), os: process.platform },
      tunnel_tools: this.tunnelTools,
      saved: listSaved().filter((t) => t.status !== 'finished').slice(0, 10),
      hosting: this.session.info(),
    };
  }

  _body(req) {
    return new Promise((resolve, reject) => {
      const chunks = []; let n = 0;
      req.on('data', (c) => { n += c.length; if (n > 32768) { reject(new Error('Requisição grande demais.')); req.destroy(); } else chunks.push(c); });
      req.on('end', () => { try { const t = Buffer.concat(chunks).toString('utf8'); resolve(t.trim() ? JSON.parse(t) : {}); } catch (_) { reject(new Error('JSON inválido.')); } });
      req.on('error', reject);
    });
  }

  async _handle(req, res) {
    try {
      // Proteção contra "DNS rebinding" e sites externos tentando controlar o lançador
      if (!HOST_OK.test(String(req.headers.host || ''))) return this._send(res, 403, { error: { message: 'Host não permitido.' } });
      const url = new URL(req.url, 'http://x');
      const p = url.pathname;
      if (!p.startsWith('/api/')) {
        if (req.method !== 'GET') return this._send(res, 405, 'Método não permitido', 'text/plain');
        const rel = p === '/' ? '/launcher.html' : p;
        if (!ALLOWED_STATIC.test(rel)) return this._send(res, 404, 'Não encontrado', 'text/plain; charset=utf-8');
        return this._send(res, 200, fs.readFileSync(path.join(this.webDir, rel)), MIME[path.extname(rel)] || 'application/octet-stream');
      }
      if (req.method !== 'GET') {
        const origin = req.headers.origin;
        if (origin) { let ok = false; try { ok = new URL(origin).host === req.headers.host; } catch (_) { /* inválida */ } if (!ok) return this._send(res, 403, { error: { message: 'Origem não permitida.' } }); }
        if (!String(req.headers['content-type'] || '').startsWith('application/json')) return this._send(res, 415, { error: { message: 'Tipo de conteúdo não suportado.' } });
      }
      if (p === '/api/launcher/qr.svg' && req.method === 'GET') {
        const text = String(url.searchParams.get('text') || '');
        if (!text || text.length > 200) return this._send(res, 400, { error: { message: 'Texto inválido.' } });
        return this._send(res, 200, qrSvg(text), 'image/svg+xml');
      }
      if (p === '/api/launcher/state' && req.method === 'GET') return this._send(res, 200, this.state());
      if (p === '/api/launcher/start' && req.method === 'POST') {
        const b = await this._body(req);
        const cfg = {
          name: b.name, description: b.description || '', max_players: Number(b.max_players), modality: b.modality, system: b.system,
          rounds_total: b.rounds_total ? Number(b.rounds_total) : null, rr_double: !!b.rr_double,
          time_base_s: Math.round(Number(b.time_min ?? 10) * 60), time_inc_s: Number(b.time_inc_s || 0),
          pts_win: Number(b.pts_win ?? 1), pts_draw: Number(b.pts_draw ?? 0.5), pts_loss: Number(b.pts_loss ?? 0), tables_count: Number(b.tables_count || 0),
        };
        TournamentService.normalizeConfig({ ...cfg }); // valida com mensagens em português antes de criar qualquer pasta
        await this.session.start({ cfg, port: 8787, tunnel: b.tunnel ? 'auto' : null, remoteAdmin: !!b.remote_admin });
        return this._send(res, 200, this.state());
      }
      if (p === '/api/launcher/resume' && req.method === 'POST') {
        const b = await this._body(req);
        const t = listSaved().find((x) => x.dir === b.dir);
        if (!t) return this._send(res, 404, { error: { message: 'Torneio salvo não encontrado.' } });
        await this.session.start({ resumeDir: t.dir, port: 8787, tunnel: b.tunnel ? 'auto' : null });
        return this._send(res, 200, this.state());
      }
      if (p === '/api/launcher/stop' && req.method === 'POST') { await this.session.stop(); return this._send(res, 200, this.state()); }
      return this._send(res, 404, { error: { message: 'Rota não encontrada.' } });
    } catch (e) {
      const known = e instanceof TournamentError || /porta|torneio|Requisição|JSON|hospedado|permissão|rede|túnel/i.test(e.message);
      if (!known) { try { fs.appendFileSync(path.join(os.tmpdir(), 'open-chess-launcher.log'), `${new Date().toISOString()} ${e.stack}\n`); } catch (_) { /* ok */ } }
      return this._send(res, known ? 400 : 500, { error: { message: known ? e.message : 'Erro interno.' } });
    }
  }
}

module.exports = { Launcher };
