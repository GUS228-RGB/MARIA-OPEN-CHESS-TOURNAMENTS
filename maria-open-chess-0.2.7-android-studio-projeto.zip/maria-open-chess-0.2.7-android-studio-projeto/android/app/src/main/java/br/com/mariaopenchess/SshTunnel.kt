package br.com.mariaopenchess

import android.content.Context
import com.jcraft.jsch.ChannelShell
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import org.json.JSONObject
import java.io.File

/**
 * Túnel SSH embutido (localhost.run), sem Termux e sem programa externo.
 * O Node pede o túnel gravando tunnel-req.json {id, port}; aqui abrimos o túnel e respondemos em tunnel-url.json
 * ({id,url} | {id,error} | {id,down:true}). Apagar o pedido encerra o túnel. Chamado a cada ciclo do NodeService.
 */
object SshTunnel {
    private var session: Session? = null
    private var runningId = ""
    private val URL_RE = Regex("https://[a-z0-9-]+\\.(?:lhr\\.life|localhost\\.run)", RegexOption.IGNORE_CASE)

    private fun reqFile(ctx: Context) = File(NodeRuntime.runtimeDir(ctx), "tunnel-req.json")
    private fun urlFile(ctx: Context) = File(NodeRuntime.runtimeDir(ctx), "tunnel-url.json")
    private fun answer(ctx: Context, o: JSONObject) {
        val tmp = File(NodeRuntime.runtimeDir(ctx), "tunnel-url.json.tmp")
        tmp.writeText(o.toString()); tmp.renameTo(urlFile(ctx))
    }

    @Synchronized
    fun tick(ctx: Context) {
        val rf = reqFile(ctx)
        if (!rf.exists()) { if (session != null) stop(); return }
        val req = try { JSONObject(rf.readText()) } catch (_: Exception) { return }
        val id = req.optString("id")
        if (id == runningId) {
            val s = session
            if (s != null && !s.isConnected) { answer(ctx, JSONObject().put("id", id).put("down", true)); stop() }
            return
        }
        stop(); runningId = id
        val port = req.optInt("port")
        Thread {
            try {
                val jsch = JSch()
                // o JSch não faz autenticação "none"; o localhost.run aceita qualquer chave, então usamos uma descartável
                val kp = com.jcraft.jsch.KeyPair.genKeyPair(jsch, com.jcraft.jsch.KeyPair.RSA, 2048)
                val priv = java.io.ByteArrayOutputStream(); val pub = java.io.ByteArrayOutputStream()
                kp.writePrivateKey(priv); kp.writePublicKey(pub, "maria-open-chess"); kp.dispose()
                jsch.addIdentity("oc", priv.toByteArray(), pub.toByteArray(), null)
                val s = jsch.getSession("nokey", "localhost.run", 22)
                s.setConfig("PreferredAuthentications", "publickey")
                s.setConfig("StrictHostKeyChecking", "no")
                s.setServerAliveInterval(30000)
                s.connect(20000)
                s.setPortForwardingR(80, "127.0.0.1", port)
                val ch = s.openChannel("shell") as ChannelShell
                val input = ch.inputStream
                ch.connect(10000)
                val buf = ByteArray(2048); val sb = StringBuilder(); val end = System.currentTimeMillis() + 25000
                var url: String? = null
                while (url == null && System.currentTimeMillis() < end) {
                    if (input.available() > 0) { val n = input.read(buf); if (n > 0) sb.append(String(buf, 0, n)); url = URL_RE.find(sb)?.value?.lowercase() }
                    else Thread.sleep(150)
                }
                synchronized(this) {
                    if (runningId != id) { s.disconnect(); return@Thread }
                    session = s
                    answer(ctx, if (url != null) JSONObject().put("id", id).put("url", url) else JSONObject().put("id", id).put("error", "o servidor não devolveu o endereço"))
                }
            } catch (e: Exception) {
                answer(ctx, JSONObject().put("id", id).put("error", e.message ?: e.javaClass.simpleName))
            }
        }.start()
    }

    @Synchronized
    fun stop() { try { session?.disconnect() } catch (_: Exception) {}; session = null; runningId = "" }
}
