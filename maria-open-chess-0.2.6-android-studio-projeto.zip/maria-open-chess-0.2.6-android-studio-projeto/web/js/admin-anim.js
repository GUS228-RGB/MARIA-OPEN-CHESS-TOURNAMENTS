// Painel do organizador: GERENCIAMENTO DE ANIMAÇÕES e CONVITES / ACESSO / CONEXÕES.
// Tudo é revalidado no servidor; aqui só há interface.
import { h, toast, openForm, confirmDialog, copyText, fmtClock, fmtDate, idLabel } from './dom.js';
import { S, api, refresh } from './net.js';
import { emptyState } from './views.js';
import { playVictory } from './anim/engine.js';
import { loadCatalog } from './anim/watch.js';

const reload = () => window.dispatchEvent(new Event('oc-rerender'));
async function act(fn, okMsg) {
  try { const r = await fn(); await refresh(); reload(); if (okMsg) toast(okMsg, 'ok'); return r; }
  catch (e) { toast(e.message, 'error'); }
}
const animLabel = (cat, id) => { const a = cat.find((x) => x.id === id); return a ? (a.num ? `<${a.num}> ` : '') + a.nome : id; };
const preview = (id, name) => playVictory({ animation: id, name: name || 'Nome do vencedor', force: true });

// ================================================================= ANIMAÇÕES
export async function loadAnim() { S.adminData.anim = await api('GET', '/api/admin/anim'); await loadCatalog(); }

function codeForm(cur, d) {
  const cat = d.catalog;
  const animOpts = [{ value: '', label: 'Automática (pelo número: 001 = dourada…)' }, ...cat.map((a) => ({ value: a.id, label: (a.num ? `<${a.num}> ` : '') + a.nome }))];
  const free = d.players.filter((p) => !d.codes.some((c) => c.player && c.player.id === p.id && (!cur || c.id !== cur.id)));
  const targets = [{ value: '', label: 'Ninguém ainda (código livre: vale para quem usar primeiro)' }, { value: 'name', label: 'Reservar para um nome (ainda não inscrito)…' },
    ...free.map((p) => ({ value: 'p' + p.id, label: `${p.name} ${idLabel(p.number)}` }))];
  const curTarget = cur ? (cur.player ? 'p' + cur.player.id : cur.reserved_name ? 'name' : '') : '';
  return [
    { name: 'code', label: 'Código (3 a 6 números; vazio = gerar automaticamente)', value: cur ? cur.code : '', maxlength: 6, placeholder: '001' },
    { name: 'animation', label: 'Animação', type: 'select', options: cur ? animOpts.slice(1) : animOpts, value: cur ? cur.animation : '' },
    { name: 'target', label: 'Participante que recebe o código', type: 'select', options: targets, value: curTarget },
    { name: 'reserved_name', label: 'Nome reservado (só se escolheu "Reservar para um nome")', value: cur && cur.reserved_name ? cur.reserved_name : '', maxlength: 40, placeholder: 'Ex.: Gustavo' },
    cur ? { name: 'active', type: 'checkbox', label: 'Código ativo', value: cur.active, hint: 'Desmarque para desativar temporariamente: o participante volta a usar a animação padrão.' } : null,
  ].filter(Boolean);
}
function payload(v, editing) {
  const b = {};
  if (v.code && v.code.trim()) b.code = v.code.trim(); else if (!editing) b.auto = true;
  if (v.animation) b.animation = v.animation;
  if (v.target && v.target.startsWith('p')) b.player_id = Number(v.target.slice(1));
  else if (v.target === 'name') { if (!String(v.reserved_name || '').trim()) throw new Error('Digite o nome para reservar o código.'); b.reserved_name = v.reserved_name; if (editing) b.player_id = null; }
  else if (editing) { b.player_id = null; b.reserved_name = null; }
  if (editing) b.active = v.active;
  return b;
}
function createDialog(d, auto = false) {
  openForm({ title: auto ? 'Gerar código automaticamente' : 'Criar código personalizado', submitLabel: 'Criar código',
    intro: 'Cada código é exclusivo: só um participante pode usá-lo. Quem recebe o código escreve no fim do nome, por exemplo Gustavo<001>.',
    fields: codeForm(null, d).map((f) => (auto && f.name === 'code' ? { ...f, value: '', label: 'Código (deixe vazio: será gerado)' } : f)),
    async submit(v) { const r = await api('POST', '/api/admin/anim/codes', payload(v, false)); await loadAnim(); await refresh(); reload(); toast(`Código <${r.code.code}> criado.`, 'ok'); } });
}
function editDialog(c, d) {
  openForm({ title: `Editar código <${c.code}>`, submitLabel: 'Salvar', fields: codeForm(c, d),
    async submit(v) { await api('POST', `/api/admin/anim/codes/${c.id}`, payload(v, true)); await loadAnim(); await refresh(); reload(); toast('Código atualizado.', 'ok'); } });
}

export function animView() {
  const d = S.adminData.anim;
  if (!d) return h('div', { class: 'empty-state' }, 'Carregando…');
  const cat = d.catalog;
  const nameOf = (c) => c.player ? h('span', null, c.player.name, h('span', { class: 'pid' }, idLabel(c.player.number))) : c.reserved_name ? h('span', { class: 'muted' }, `reservado: ${c.reserved_name}`) : h('span', { class: 'muted' }, '— livre —');
  const rows = d.codes.map((c) => h('tr', { class: c.active ? '' : 'out' },
    h('td', { class: 'anim-code' }, `<${c.code}>`),
    h('td', null, animLabel(cat, c.animation)),
    h('td', null, nameOf(c)),
    h('td', null, h('span', { class: 'chip ' + (c.status === 'vinculado' ? 'ok' : c.status === 'reservado' ? 'warn' : '') }, c.status), ' ', c.active ? null : h('span', { class: 'chip danger' }, 'desativado')),
    h('td', null, h('div', { class: 'row' },
      h('button', { class: 'btn small', type: 'button', onclick: () => preview(c.animation, c.player ? c.player.name : undefined) }, '▶'),
      h('button', { class: 'btn small', type: 'button', onclick: async () => toast((await copyText(`${c.player ? c.player.name : c.reserved_name || 'Nome'}<${c.code}>`)) ? 'Copiado: nome com código.' : 'Não foi possível copiar.', 'ok') }, 'Copiar'),
      h('button', { class: 'btn small', type: 'button', onclick: () => editDialog(c, d) }, 'Editar'),
      h('button', { class: 'btn small', type: 'button', onclick: () => act(async () => { await api('POST', `/api/admin/anim/codes/${c.id}`, { active: !c.active }); await loadAnim(); }, c.active ? 'Código desativado.' : 'Código reativado.') }, c.active ? 'Desativar' : 'Ativar'),
      h('button', { class: 'btn small danger', type: 'button', onclick: async () => { if (await confirmDialog({ title: `Excluir o código <${c.code}>?`, message: c.player ? `${c.player.name} volta a usar a animação padrão.` : 'Esse código deixa de existir.', confirmLabel: 'Excluir', danger: true })) act(async () => { await api('DELETE', `/api/admin/anim/codes/${c.id}`); await loadAnim(); }, 'Código excluído.'); } }, 'Excluir')))));
  return h('div', { class: 'stack' },
    h('div', { class: 'row between' }, h('h2', { style: 'margin:0' }, 'GERENCIAMENTO DE ANIMAÇÕES'),
      h('div', { class: 'row' }, h('button', { class: 'btn primary', type: 'button', onclick: () => createDialog(d) }, '＋ Criar código'), h('button', { class: 'btn', type: 'button', onclick: () => createDialog(d, true) }, '⚙ Gerar automaticamente'))),
    h('p', { class: 'note', style: 'margin:0' }, 'A animação de vitória toca só para quem vence (nunca em derrota ou empate) e não altera o jogo. O código fica vinculado ao participante no servidor: copiar o código no nome de outra pessoa não funciona. Quem não tem código usa a animação padrão.'),
    h('div', { class: 'card stack' }, h('h3', null, 'Códigos distribuídos (' + d.codes.length + ')'),
      d.codes.length ? h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, ['Código', 'Animação', 'Participante', 'Situação', 'Ações'].map((x) => h('th', null, x)))), h('tbody', null, rows)))
        : emptyState('Nenhum código criado', 'Crie um código e entregue ao participante, ou escolha o participante na criação.')),
    h('div', { class: 'card stack' }, h('h3', null, 'Catálogo de animações'),
      h('div', { class: 'grid cols-2' }, cat.map((a) => h('div', { class: 'award' }, h('div', { style: 'flex:1' }, h('b', null, (a.num ? `<${a.num}> ` : '') + a.nome), h('small', null, a.descricao)),
        h('button', { class: 'btn small', type: 'button', onclick: () => preview(a.id) }, '▶ Ver'))))));
}

// ================================================================= CONVITES, ACESSO E CONEXÕES
export async function loadAccess() {
  const [inv, conn] = await Promise.all([api('GET', '/api/admin/invite'), api('GET', '/api/admin/connections')]);
  S.adminData.invite = inv; S.adminData.conn = conn;
}
const ago = (ms) => { if (!ms) return '—'; const s = Math.round((Date.now() - ms) / 1000); return s < 60 ? `${s}s atrás` : s < 3600 ? `${Math.floor(s / 60)} min atrás` : fmtDate(new Date(ms).toISOString()); };

export function accessView() {
  const inv = S.adminData.invite, conn = S.adminData.conn, t = S.t;
  if (!inv || !conn) return h('div', { class: 'empty-state' }, 'Carregando…');
  const setReg = (state, msg) => act(() => api('POST', '/api/admin/registration', { state }), msg);
  const setInvite = (b, msg) => act(async () => { await api('POST', '/api/admin/invite', b); await loadAccess(); }, msg);
  const main = inv.links[0];
  const modeText = { presencial: 'Presencial: todos no mesmo local; o organizador lança os resultados.', online: 'Online: cada participante joga do próprio aparelho, de qualquer rede.', hibrido: 'Híbrido: parte presencial, parte online, na mesma classificação. Marque os confrontos presenciais em "Editar confronto".' }[t.modality];
  const linkRows = inv.links.map((l) => h('div', { class: 'stack', style: 'padding:6px 0' }, h('div', { class: 'row between' }, h('b', null, l.label), l.scope === 'public' ? h('span', { class: 'chip ok' }, 'funciona de qualquer rede') : l.scope === 'vpn' ? h('span', { class: 'chip ok' }, 'qualquer rede, com Tailscale') : l.scope === 'lan' ? h('span', { class: 'chip warn' }, 'só na mesma rede') : h('span', { class: 'chip' }, 'só neste aparelho')),
    h('div', { class: 'row' }, h('div', { class: 'urlbox', style: 'flex:1' }, l.url), h('button', { class: 'btn small', type: 'button', onclick: async () => toast((await copyText(l.url)) ? 'Link de convite copiado.' : 'Não foi possível copiar.', 'ok') }, 'Copiar link'))));
  const inviteCard = h('div', { class: 'card share-box' },
    h('h2', { style: 'margin:0' }, 'Convite do torneio'),
    h('div', { class: 'row' }, h('span', { class: 'muted' }, 'Tipo:'),
      h('button', { class: 'btn small' + (inv.visibility === 'public' ? ' primary' : ''), type: 'button', onclick: () => setInvite({ visibility: 'public' }, 'Torneio público: qualquer pessoa com o link entra.') }, 'Público'),
      h('button', { class: 'btn small' + (inv.visibility === 'private' ? ' primary' : ''), type: 'button', onclick: () => setInvite({ visibility: 'private' }, 'Torneio privado: só entra quem tem o código de acesso.') }, 'Privado')),
    h('p', { class: 'note', style: 'margin:0' }, inv.visibility === 'private' ? 'Privado: para se inscrever é preciso o código de acesso (já vai dentro do link e do QR Code). Quem só tem o endereço não entra.' : 'Público: qualquer pessoa que abrir o link pode se inscrever. O código de acesso abaixo continua válido, mas não é exigido.'),
    h('div', null, h('div', { class: 'muted' }, 'Código de acesso'), h('div', { class: 'code-big' }, inv.access_code_display)),
    h('div', { class: 'row' },
      h('button', { class: 'btn small', type: 'button', onclick: async () => toast((await copyText(inv.access_code_display)) ? 'Código copiado.' : 'Não foi possível copiar.', 'ok') }, 'Copiar código'),
      h('button', { class: 'btn small', type: 'button', onclick: async () => { if (await confirmDialog({ title: 'Gerar um novo código de acesso?', message: 'O código atual deixa de valer para novas inscrições (quem já entrou continua inscrito). Links antigos param de funcionar.', confirmLabel: 'Gerar novo código' })) setInvite({ regenerate: true }, 'Novo código de acesso gerado.'); } }, 'Gerar novo'),
      h('button', { class: 'btn small', type: 'button', onclick: () => openForm({ title: 'Definir código de acesso', submitLabel: 'Salvar', intro: 'De 4 a 12 letras ou números, sem espaços.', fields: [{ name: 'c', label: 'Novo código', maxlength: 12 }], async submit(v) { await api('POST', '/api/admin/invite', { access_code: v.c }); await loadAccess(); await refresh(); reload(); toast('Código de acesso atualizado.', 'ok'); } }) }, 'Escolher o meu')),
    h('div', { class: 'share' }, h('img', { src: '/api/qr.svg?text=' + encodeURIComponent(main.url), alt: 'QR Code do convite: ' + main.url, width: 168, height: 168 }), h('div', { class: 'stack', style: 'flex:1' }, linkRows)),
    navigator.share ? h('button', { class: 'btn', type: 'button', onclick: () => navigator.share({ title: t.name, text: `Participe do torneio de xadrez "${t.name}"${inv.visibility === 'private' ? ` — código de acesso: ${inv.access_code_display}` : ''}`, url: main.url }).catch(() => {}) }, 'Compartilhar convite…') : null,
    !inv.public_url ? h('p', { class: 'note', style: 'margin:0' }, 'Sem endereço de internet: o convite só chega a quem está na mesma rede Wi-Fi. Para participantes de outras redes (casa, 4G, outra cidade) reinicie a hospedagem com o túnel ativado: open-chess host --tunnel (veja o README).') : h('p', { class: 'note', style: 'margin:0' }, 'O endereço de internet passa por um túnel seguro: o seu aparelho não fica exposto e não é preciso abrir portas no roteador. O link só funciona enquanto a hospedagem estiver ligada.'));
  const ctl = h('div', { class: 'card stack' }, h('h2', { style: 'margin:0' }, 'Quem pode entrar'),
    h('div', { class: 'row' }, h('span', { class: 'chip accent' }, { presencial: 'Presencial', online: 'Online', hibrido: 'Híbrido' }[t.modality]), h('span', { class: 'muted' }, modeText)),
    t.status === 'setup' ? h('div', { class: 'row' }, h('span', { class: 'muted' }, 'Inscrições:'),
      h('button', { class: 'btn small' + (t.registration === 'open' ? ' primary' : ''), type: 'button', onclick: () => setReg('open', 'Inscrições abertas.') }, 'Abertas'),
      h('button', { class: 'btn small' + (t.registration === 'paused' ? ' primary' : ''), type: 'button', onclick: () => setReg('paused', 'Inscrições pausadas.') }, 'Pausar'),
      h('button', { class: 'btn small' + (t.registration === 'closed' ? ' primary' : ''), type: 'button', onclick: () => setReg('closed', 'Inscrições encerradas.') }, 'Encerrar'))
      : h('p', { class: 'note', style: 'margin:0' }, 'O torneio já começou: novas inscrições estão fechadas. Você ainda pode adicionar alguém em Participantes → Adicionar.'),
    h('p', { class: 'note', style: 'margin:0' }, `${t.players_count} de ${t.max_players} vagas ocupadas. Para tirar alguém, use a aba Participantes.`));
  const pRows = conn.players.map((p) => h('tr', { class: p.status === 'withdrawn' ? 'out' : '' },
    h('td', null, h('span', { class: 'status-dot ' + (p.connected ? 'on' : 'off'), 'aria-hidden': 'true' }), p.name, h('span', { class: 'pid' }, idLabel(p.number))),
    h('td', null, p.status === 'withdrawn' ? 'desistiu' : p.connected ? 'conectado' : 'desconectado'),
    h('td', { class: 'num' }, String(p.reconnects)),
    h('td', null, p.connected ? 'agora' : ago(p.last_disconnect)),
    h('td', null, p.current_game ? h('a', { href: `#/jogo/${p.current_game}` }, 'partida ' + p.current_game) : '—'),
    h('td', null, p.connected ? h('button', { class: 'btn small', type: 'button', title: 'Derruba a conexão deste participante; o navegador dele reconecta sozinho em instantes.', onclick: () => act(async () => { await api('POST', `/api/admin/connections/${p.id}/reset`, {}); await loadAccess(); }, 'Conexão reiniciada: o participante reconecta sozinho.') }, 'Reiniciar conexão') : null)));
  const gRows = conn.games.map((g) => h('tr', null,
    h('td', null, `R${g.round} · T${g.board}`),
    h('td', null, h('span', { class: 'status-dot ' + (g.presence.w ? 'on' : 'off') }), g.white ? g.white.name : '—'),
    h('td', null, h('span', { class: 'status-dot ' + (g.presence.b ? 'on' : 'off') }), g.black ? g.black.name : '—'),
    h('td', null, g.state === 'playing' ? h('span', { class: 'chip accent' }, 'jogando') : h('span', { class: 'chip warn' }, 'aguardando')),
    h('td', { class: 'num mono' }, g.white_ms == null ? '—' : `${fmtClock(g.white_ms)} / ${fmtClock(g.black_ms)}`),
    h('td', { class: 'num' }, String(g.moves)),
    h('td', null, h('a', { class: 'btn small', href: `#/jogo/${g.id}` }, 'Ver'))));
  return h('div', { class: 'stack' },
    h('div', { class: 'row between' }, h('h2', { style: 'margin:0' }, 'Convites, acesso e conexões'), h('button', { class: 'btn small', type: 'button', onclick: () => act(loadAccess) }, '↻ Atualizar')),
    h('div', { class: 'grid cols-2' }, inviteCard, ctl),
    h('div', { class: 'card pad0' }, h('div', { style: 'padding:16px 18px 0' }, h('h2', null, 'Participantes e reconexões')),
      conn.players.length ? h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, ['Participante', 'Situação', 'Reconexões', 'Última queda', 'Partida', ''].map((x) => h('th', null, x)))), h('tbody', null, pRows))) : emptyState('Ninguém inscrito', 'Compartilhe o convite.')),
    h('div', { class: 'card pad0' }, h('div', { style: 'padding:16px 18px 0' }, h('h2', null, 'Partidas online ao vivo')),
      conn.games.length ? h('div', { class: 'tablewrap' }, h('table', null, h('thead', null, h('tr', null, ['Mesa', 'Brancas', 'Pretas', 'Estado', 'Relógios (B / P)', 'Lances', ''].map((x) => h('th', null, x)))), h('tbody', null, gRows))) : emptyState('Nenhuma partida online aberta', 'As partidas aparecem aqui quando a rodada começa.'),
      h('p', { class: 'note', style: 'padding:0 18px 14px;margin:0' }, 'Uma queda de internet não encerra nem decide a partida: o relógio segue o regulamento e, se o jogador voltar a tempo, a partida continua do ponto exato em que parou.')));
}
