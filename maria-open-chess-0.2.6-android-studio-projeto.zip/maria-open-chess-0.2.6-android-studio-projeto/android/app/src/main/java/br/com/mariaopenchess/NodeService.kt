package br.com.mariaopenchess

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.Process
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

/**
 * Serviço em primeiro plano: mantém o processo (e o servidor Node) vivos enquanto o aplicativo está aberto,
 * mostra o estado do torneio na notificação e, durante uma hospedagem, segura WakeLock e WifiLock
 * para o Android não suspender a rede com a tela apagada.
 */
class NodeService : Service() {
    private var executor: ScheduledExecutorService? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var lastShown = ""
    @Volatile private var quitting = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
        ch.description = getString(R.string.channel_desc)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_QUIT) {
            quit()
            return START_NOT_STICKY
        }
        val n = buildNotification(getString(R.string.notif_idle_title), getString(R.string.notif_idle_text))
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (executor == null) {
            // Se o Android recriou o serviço depois de matar o processo, garante que o Node volte a rodar
            Thread { NodeRuntime.ensureStarted(applicationContext) }.start()
            executor = Executors.newSingleThreadScheduledExecutor().also {
                it.scheduleWithFixedDelay({ tick() }, 1, 3, TimeUnit.SECONDS)
            }
        }
        return START_STICKY
    }

    private fun tick() {
        if (quitting) return
        try {
            LanAddresses.write(applicationContext)
            SshTunnel.tick(applicationContext)
            val hosting = LauncherClient.state(applicationContext)?.optJSONObject("hosting")
            setLocks(hosting != null)
            val (title, text) = describe(hosting)
            if ("$title|$text" != lastShown) {
                lastShown = "$title|$text"
                getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(title, text))
            }
        } catch (_: Exception) {
            // próxima volta tenta de novo
        }
    }

    private fun describe(h: JSONObject?): Pair<String, String> {
        if (h == null) return getString(R.string.notif_idle_title) to getString(R.string.notif_idle_text)
        val lan = h.optJSONObject("urls")?.optJSONArray("lan")
        val url = if (lan != null && lan.length() > 0) lan.getJSONObject(0).optString("url") else ""
        val line = "${h.optInt("players")}/${h.optInt("max_players")} jogadores · ${h.optInt("connected")} online" +
            (if (url.isNotEmpty()) "\n$url" else "")
        return "Hospedando: ${h.optString("name")}" to line
    }

    private fun buildNotification(title: String, text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val quit = PendingIntent.getService(
            this, 1, Intent(this, NodeService::class.java).setAction(ACTION_QUIT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_chess)
            .setContentTitle(title)
            .setContentText(text.lineSequence().first())
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(0, getString(R.string.notif_action_open), open)
            .addAction(0, getString(R.string.notif_action_quit), quit)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    @Suppress("DEPRECATION")
    private fun setLocks(hosting: Boolean) {
        if (hosting) {
            if (wakeLock == null) {
                wakeLock = getSystemService(PowerManager::class.java)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "maria-open-chess:hosting").apply { acquire() }
            }
            if (wifiLock == null) {
                wifiLock = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                    .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "maria-open-chess:hosting").apply { acquire() }
            }
        } else {
            wakeLock?.let { if (it.isHeld) it.release() }; wakeLock = null
            wifiLock?.let { if (it.isHeld) it.release() }; wifiLock = null
        }
    }

    /** Encerra a hospedagem com segurança, fecha a tela e mata o processo (o Node não pode ser reiniciado). */
    private fun quit() {
        if (quitting) return
        quitting = true
        executor?.shutdownNow()
        Thread {
            LauncherClient.stopHosting(applicationContext)
            setLocks(false)
            sendBroadcast(Intent(ACTION_FINISH_UI).setPackage(packageName))
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            Thread.sleep(400)
            Process.killProcess(Process.myPid())
        }.start()
    }

    override fun onDestroy() {
        executor?.shutdownNow()
        setLocks(false)
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "hospedagem"
        const val NOTIF_ID = 1
        const val ACTION_QUIT = "br.com.mariaopenchess.QUIT"
        const val ACTION_FINISH_UI = "br.com.mariaopenchess.FINISH_UI"
    }
}
