package br.com.mariaopenchess

import android.content.Context
import android.content.res.AssetManager
import android.system.Os
import android.util.Log
import org.json.JSONObject
import java.io.File

/**
 * Prepara e inicia o Node.js embutido. O nodejs-mobile só permite UMA execução do Node por processo,
 * então [ensureStarted] é idempotente e, para "reiniciar", o aplicativo encerra o próprio processo.
 */
object NodeRuntime {
    private const val TAG = "MariaOpenChess"
    private const val NODE_STACK_BYTES = 4L * 1024 * 1024

    private val lock = Any()
    @Volatile private var started = false

    fun projectDir(ctx: Context) = File(ctx.filesDir, "nodejs-project")
    fun homeDir(ctx: Context) = File(ctx.filesDir, "open-chess")
    fun runtimeDir(ctx: Context) = File(ctx.filesDir, "runtime").apply { mkdirs() }
    fun readyFile(ctx: Context) = File(runtimeDir(ctx), "launcher.json")
    fun errorFile(ctx: Context) = File(runtimeDir(ctx), "launcher.json.error")
    fun lanFile(ctx: Context) = File(runtimeDir(ctx), "lan.json")

    /** Copia o código Node.js dos assets para filesDir (o Node precisa de arquivos reais). Refaz após cada atualização do app. */
    private fun installAssets(ctx: Context) {
        val info = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        val key = "${info.lastUpdateTime}-${BuildConfig.VERSION_NAME}"
        val dir = projectDir(ctx)
        val marker = File(dir, ".installed")
        if (marker.exists() && marker.readText() == key) return
        dir.deleteRecursively()
        copyAssetDir(ctx.assets, "nodejs-project", dir)
        marker.writeText(key)
    }

    private fun copyAssetDir(am: AssetManager, asset: String, dest: File) {
        val children = am.list(asset) ?: emptyArray()
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            am.open(asset).use { input -> dest.outputStream().use { out -> input.copyTo(out) } }
            return
        }
        dest.mkdirs()
        for (c in children) copyAssetDir(am, "$asset/$c", File(dest, c))
    }

    private fun setenv(k: String, v: String) {
        try { Os.setenv(k, v, true) } catch (e: Exception) { Log.w(TAG, "setenv $k falhou", e) }
    }

    fun ensureStarted(ctx: Context) {
        synchronized(lock) {
            if (started) return
            val app = ctx.applicationContext
            try {
                installAssets(app)
            } catch (e: Exception) {
                Log.e(TAG, "Falha ao instalar os arquivos do servidor", e)
                errorFile(app).writeText("Falha ao preparar os arquivos: ${e.message}")
                return
            }
            readyFile(app).delete()
            errorFile(app).delete()
            homeDir(app).mkdirs()
            val cache = app.cacheDir.apply { mkdirs() }

            setenv("OPEN_CHESS_HOME", homeDir(app).absolutePath)
            setenv("OPEN_CHESS_ANDROID", "1")
            setenv("OPEN_CHESS_READY_FILE", readyFile(app).absolutePath)
            setenv("OPEN_CHESS_LAN_FILE", lanFile(app).absolutePath)
            setenv("OPEN_CHESS_TUNNEL_DIR", runtimeDir(app).absolutePath)
            setenv("HOME", app.filesDir.absolutePath)
            setenv("TMPDIR", cache.absolutePath)
            LanAddresses.write(app)

            val main = File(projectDir(app), "src/mobile/main.js").absolutePath
            started = true
            Thread(null, {
                try {
                    val rc = NodeBridge().startNodeWithArguments(arrayOf("node", main))
                    Log.w(TAG, "O Node terminou com código $rc")
                } catch (t: Throwable) {
                    Log.e(TAG, "Falha ao iniciar o Node", t)
                    try { errorFile(app).writeText("Falha ao iniciar o Node: ${t.message}") } catch (_: Exception) { }
                }
            }, "node-main", NODE_STACK_BYTES).start()
        }
    }

    /** Porta da tela do aplicativo, assim que o Node a publicar; null se falhar ou esgotar o tempo. */
    fun waitReady(ctx: Context, timeoutMs: Long): Int? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            readPort(ctx)?.let { return it }
            if (errorFile(ctx).exists()) return null
            Thread.sleep(150)
        }
        return null
    }

    fun readPort(ctx: Context): Int? = try {
        val f = readyFile(ctx)
        if (f.exists()) JSONObject(f.readText()).getInt("port") else null
    } catch (_: Exception) { null }

    fun errorText(ctx: Context): String =
        try { errorFile(ctx).takeIf { it.exists() }?.readText() } catch (_: Exception) { null }
            ?: "O servidor não respondeu a tempo. Feche e abra o aplicativo de novo."
}
