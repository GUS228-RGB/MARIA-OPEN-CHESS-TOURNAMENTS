'use strict';
/**
 * Servidor do open CHESS: HTTP (API + interface web) e WebSocket (tempo real).
 * Um servidor hospeda exatamente um torneio, cujos dados ficam em <dir>/torneio.db.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const crypto = require('node:crypto');
const { attachWebSocket } = require('./ws');
const { Store } = require('../db/db');
const { TournamentService, TournamentError, sha256, newToken } = require('../core/tournament');
const { OnlineManager, OnlineError } = require('../core/online');
const exp = require('../export/exports');
const { qrSvg } = require('../core/qr');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json', '.txt': 'text/plain; charset=utf-8',
};
const SESSION_MS = 12 * 60 * 60 * 1000;
const BACKUP_EVERY_MS = 10 * 60 * 1000;
const BACKUP_KEEP = 20;

class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

/**
 * No aplicativo Android o Node não consegue listar as interfaces de rede (o Android 11+ bloqueia). O aplicativo
 * grava os endereços num arquivo JSON ([{"name":"wlan0","address":"192.168.0.5"}]), apontado por OPEN_CHESS_LAN_FILE.
 */
function lanFromFile() {
  const f = process.env.OPEN_CHESS_LAN_FILE;
  if (!f) return null;
  const out = {};
  try {
    for (const e of JSON.parse(fs.readFileSync(f, 'utf8'))) {
      if (e && /^\d{1,3}(\.\d{1,3}){3}$/.test(String(e.address))) (out[String(e.name || 'wlan0')] ||= []).push({ family: 'IPv4', internal: false, address: e.address });
    }
  } catch (_) { /* arquivo ainda não existe */ }
  return out;
}

/** Endereços IPv4 locais, priorizando redes privadas reais (Wi-Fi/Ethernet) sobre interfaces virtuais. */
function lanAddresses() {
  const out = [];
  let ifs = {};
  try { ifs = lanFromFile() || os.networkInterfaces(); } catch (_) { ifs = {}; } // no Android/Termux pode falhar
  for (const [name, list] of Object.entries(ifs)) {
    for (const i of list || []) {
      if (i.family !== 'IPv4' || i.internal) continue;
      const virtual = /^(docker|br-|veth|virbr|vmnet|vboxnet|tailscale|zt|utun|lo|rmnet|ccmni|v4-rmnet|tun|dummy)/i.test(name) || /VirtualBox|VMware|vEthernet|WSL/i.test(name);
      const [a, b] = i.address.split('.').map(Number);
      const priv = a === 10 || (a === 192 && b === 168) || (a === 172 && b >= 16 && b <= 31);
      out.push({ name, address: i.address, score: (priv ? 2 : 0) + (virtual ? -3 : 0) + (/^(wl|wi|eth|en|ap\d|swlan|rndis|Wi-Fi|Ethernet)/i.test(name) ? 1 : 0) });
    }
  }
  return out.sort((x, y) => y.score - x.score);
}

/** Converte erros de listen() em mensagens claras em português. */
function explainListenError(e, port) {
  const err = new Error();
  err.code = e.code;
  if (e.code === 'EADDRINUSE') err.message = `A porta ${port} já está em uso por outro programa (talvez outro torneio maria open CHESS). Use --port com outro número ou encerre o programa que a ocupa.`;
  else if (e.code === 'EACCES') err.message = `Sem permissão para usar a porta ${port}. Portas abaixo de 1024 exigem privilégios de administrador; use uma porta maior (ex.: 8787).`;
  else if (e.code === 'EADDRNOTAVAIL') err.message = 'O endereço de rede solicitado não está disponível neste dispositivo. Verifique a conexão Wi-Fi/Ethernet.';
  else err.message = `Não foi possível iniciar o servidor (${e.code || e.message}).`;
  return err;
}

class OpenChessServer {
  /**
   * @param {object} o
   * @param {string} o.dir      pasta do torneio (banco, resultados, backups, logs)
   * @param {string} o.webDir   pasta da interface web
   * @param {(line:string)=>void} [o.log]
   */
  constructor({ dir, webDir, log = null, store = null }) {
    this.dir = dir;
    this.webDir = webDir;
    fs.mkdirSync(dir, { recursive: true });
    fs.mkdirSync(path.join(dir, 'logs'), { recursive: true });
    this.logSink = log;
    this.store = store || new Store(path.join(dir, 'torneio.db'));
    this.svc = new TournamentService(this.store);
    this.svc.tournament(); // garante que existe
    this.online = new OnlineManager(this.svc, { onUpdate: (id) => this._pushGame(id) });
    this.sessions = new Map();
    this.loginAttempts = new Map();
    this.joinAttempts = new Map();
    this.adminKey = null;
    this.port = null;
    this.host = null;
    this.startedAt = null;
    this.running = false;
    this._pendingTopics = new Set();
    this._flushTimer = null;
    this._backupTimer = null;
    this._tickTimer = null;
    this._stopHooks = [];
    this.watchers = new Map(); // gameId -> Set<ws>
    this.presence = new Map(); // playerId -> {conns, lastSeen, lastDisconnect, reconnects, everSeen}
    this.publicUrl = null;      // URL pública (túnel), definida pelo CLI/app
    this.remoteAdmin = false;   // permite o painel do organizador pela URL pública

    this.svc.on((type) => {
      this._queue(type);
      if (type === 'finished') this._onFinished();
      if (type === 'finished' || type === 'rounds') this._scheduleBackup();
    });

    this.server = http.createServer((req, res) => this._handle(req, res));
    this.server.requestTimeout = 30000;
    this.server.headersTimeout = 15000;
    this.ws = attachWebSocket(this.server, '/ws', (ws, req) => this._onWs(ws, req), { verify: (req) => this._originOk(req) });
  }

  // ------------------------------------------------------------------ log
  log(level, msg, extra = null) {
    const line = `${new Date().toISOString()} [${level}] ${msg}${extra ? ' ' + JSON.stringify(extra) : ''}`;
    try { fs.appendFileSync(path.join(this.dir, 'logs', 'servidor.log'), line + '\n'); } catch (_) { /* log não pode derrubar o servidor */ }
    if (this.logSink) this.logSink(line);
  }

  // ------------------------------------------------------------------ ciclo de vida
  /** Gera uma nova chave do organizador (só o hash fica no banco). */
  rotateAdminKey() {
    this.adminKey = crypto.randomBytes(12).toString('base64url');
    this.store.run('UPDATE tournament SET admin_hash=? WHERE id=1', [sha256(this.adminKey)]);
    this.sessions.clear();
    return this.adminKey;
  }

  async listen({ port = 8787, host = '0.0.0.0', autoPort = false } = {}) {
    if (!this.adminKey) this.rotateAdminKey();
    const tryPort = (p) => new Promise((resolve, reject) => {
      const onErr = (e) => { this.server.off('listening', onOk); reject(e); };
      const onOk = () => { this.server.off('error', onErr); resolve(); };
      this.server.once('error', onErr);
      this.server.once('listening', onOk);
      this.server.listen(p, host);
    });
    let p = port;
    for (let attempt = 0; ; attempt++) {
      try { await tryPort(p); break; }
      catch (e) {
        if (e.code === 'EADDRINUSE' && autoPort && attempt < 30 && port !== 0) { p++; continue; }
        throw explainListenError(e, p);
      }
    }
    this.port = this.server.address().port;
    this.host = host;
    this.startedAt = Date.now();
    this.running = true;
    const recovered = this.online.recover();
    this._tickTimer = setInterval(() => { try { this.online.tick(); } catch (e) { this.log('erro', 'tick: ' + e.message); } }, 1000);
    this._tickTimer.unref();
    this._backupTimer = setInterval(() => this._backupNow('periodico'), BACKUP_EVERY_MS);
    this._backupTimer.unref();
    this.server.on('error', (e) => this.log('erro', 'servidor: ' + e.message));
    this.log('info', `Servidor ativo na porta ${this.port}`, { partidasRecuperadas: recovered });
    if (this.svc.tournament().status === 'finished') this._onFinished(true);
    return this.port;
  }

  urls() {
    const addrs = lanAddresses();
    const list = addrs.map((a) => ({ interface: a.name, address: a.address, url: `http://${a.address}:${this.port}/` }));
    return { local: `http://localhost:${this.port}/`, lan: list, public: this.publicUrl };
  }

  /** Estado resumido para terminal, app e comando "status". */
  getStatus() {
    const t = this.svc.publicInfo();
    const games = this.store.all('SELECT state, black_id FROM games');
    const real = games.filter((g) => g.black_id != null);
    return {
      state: this.running ? 'ativo' : 'parado',
      name: t.name, status: t.status, modality: t.modality, system: t.system, registration: t.registration,
      port: this.port, urls: this.urls(), public_url: this.publicUrl, remote_admin: this.remoteAdmin,
      players: t.players_count, max_players: t.max_players, slots_left: t.slots_left, full: t.full,
      connected: this.connectedPlayers().length, viewers: this.ws.connections.size,
      current_round: t.current_round, rounds_total: t.rounds_total,
      games_playing: real.filter((g) => g.state === 'playing').length,
      games_waiting: real.filter((g) => g.state === 'waiting').length,
      results_recorded: real.filter((g) => g.state === 'finished').length,
      uptime_s: this.startedAt ? Math.round((Date.now() - this.startedAt) / 1000) : 0,
      dir: this.dir, invite: this.inviteInfo(),
    };
  }

  /** Convite do organizador: código de acesso, visibilidade e links prontos (o código vai na query ?c=). */
  inviteInfo() {
    const inv = this.svc.inviteAdmin();
    const q = '?c=' + inv.access_code;
    const links = [];
    const u = this.urls();
    if (u.public) links.push({ scope: 'public', label: 'Internet (qualquer rede)', url: u.public.replace(/\/+$/, '/') + q });
    for (const a of u.lan) {
      const ts = /^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(a.address); // faixa do Tailscale (CGNAT 100.64/10)
      links.push(ts ? { scope: 'vpn', label: 'Tailscale (quem também usa o Tailscale, em qualquer rede)', url: a.url + q } : { scope: 'lan', label: `Mesma rede Wi-Fi (${a.interface})`, url: a.url + q });
    }
    links.push({ scope: 'local', label: 'Neste aparelho', url: u.local + q });
    return { ...inv, links, public_url: u.public, remote_admin: this.remoteAdmin, registration: this.svc.tournament().registration };
  }

  connectedPlayers() {
    const ids = new Set();
    for (const c of this.ws.connections) if (!c.closed && c.data.player) ids.add(c.data.player.id);
    return [...ids];
  }

  onStop(fn) { this._stopHooks.push(fn); }

  async close() {
    if (!this.running && !this.server.listening) { this.store.close(); return; }
    this.running = false;
    clearInterval(this._tickTimer); clearInterval(this._backupTimer); clearTimeout(this._flushTimer);
    try { await this._backupNow('encerramento'); } catch (_) { /* já registrado no log */ }
    this.ws.broadcast({ type: 'closing' }); // avisa os participantes antes de desligar
    await new Promise((r) => setTimeout(r, 150));
    this.ws.closeAll();
    this.online.shutdown();
    await new Promise((resolve) => { this.server.close(() => resolve()); this.server.closeAllConnections?.(); });
    this.log('info', 'Servidor encerrado');
    this.store.close();
    for (const fn of this._stopHooks) { try { fn(); } catch (_) { /* ignora */ } }
  }

  // ------------------------------------------------------------------ backup e exportação automática
  _scheduleBackup() {
    clearTimeout(this._bkTimer);
    this._bkTimer = setTimeout(() => this._backupNow('automatico').catch(() => {}), 1500);
    this._bkTimer.unref();
  }

  async _backupNow(tag = 'manual') {
    if (!this.store.db.isOpen) return null;
    const dir = path.join(this.dir, 'backups');
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const file = path.join(dir, `torneio-${stamp}-${tag}.db`);
    try {
      await this.store.backupTo(file);
      const all = fs.readdirSync(dir).filter((f) => f.endsWith('.db')).sort();
      for (const old of all.slice(0, Math.max(0, all.length - BACKUP_KEEP))) fs.rmSync(path.join(dir, old), { force: true });
      return file;
    } catch (e) { this.log('erro', 'Falha no backup: ' + e.message); return null; }
  }

  _onFinished(quiet = false) {
    try {
      const file = exp.writeResultsTxt(this.svc, this.dir);
      if (!quiet) this.log('info', 'Resultados gravados em ' + file);
    } catch (e) { this.log('erro', 'Falha ao gravar o TXT de resultados: ' + e.message); }
  }

  // ------------------------------------------------------------------ tempo real
  _queue(topic) {
    this._pendingTopics.add(topic);
    if (this._flushTimer) return;
    this._flushTimer = setTimeout(() => {
      this._flushTimer = null;
      const topics = [...this._pendingTopics]; this._pendingTopics.clear();
      this.ws.broadcast({ type: 'invalidate', topics });
    }, 60);
  }

  _pushGame(gameId) {
    const set = this.watchers.get(gameId);
    if (set) {
      for (const ws of set) {
        if (ws.closed) continue;
        try { ws.send({ type: 'game', snapshot: this.online.snapshot(gameId, ws.data.player ? ws.data.player.id : null) }); } catch (_) { /* conexão fechando */ }
      }
    }
    this._queue('rounds');
  }

  _originOk(req) {
    const origin = req.headers.origin;
    if (!origin) return true;
    try { return new URL(origin).host === req.headers.host; } catch (_) { return false; }
  }

  _onWs(ws, req) {
    ws.data = { player: null, watching: new Map() }; // gameId -> cor (ou null se só espectador)
    ws.send({ type: 'hello', serverTime: Date.now() });
    ws.on('message', (text) => {
      let msg;
      try { msg = JSON.parse(text); } catch (_) { ws.send({ type: 'error', code: 'bad_json', message: 'Mensagem inválida.' }); return; }
      try { this._wsMessage(ws, msg); }
      catch (e) {
        const known = e instanceof OnlineError || e instanceof TournamentError;
        if (!known) this.log('erro', 'ws: ' + (e.stack || e.message));
        ws.send({ type: 'error', code: known ? e.code : 'internal', message: known ? e.message : 'Erro interno.', game: msg && msg.game });
      }
    });
    ws.on('close', () => {
      for (const gid of [...ws.data.watching.keys()]) this._unwatch(ws, gid);
      if (ws.data.player) { this._presenceDown(ws.data.player.id); this._queue('presence'); }
    });
  }

  _presenceUp(id) {
    const e = this.presence.get(id) || { conns: 0, lastSeen: null, lastDisconnect: null, reconnects: 0, everSeen: false };
    if (e.everSeen && e.conns === 0) e.reconnects++;
    e.everSeen = true; e.conns++; e.lastSeen = Date.now();
    this.presence.set(id, e);
  }

  _presenceDown(id) {
    const e = this.presence.get(id); if (!e) return;
    e.conns = Math.max(0, e.conns - 1); e.lastSeen = Date.now();
    if (e.conns === 0) e.lastDisconnect = Date.now();
  }

  /** Visão do organizador: quem está conectado, reconexões e estado ao vivo das partidas online. */
  connectionsInfo() {
    const conn = new Set(this.connectedPlayers());
    const players = this.svc.players().map((p) => {
      const e = this.presence.get(p.id) || {};
      return { id: p.id, number: p.number, name: p.name, status: p.status, connected: conn.has(p.id), connections: e.conns || 0,
        reconnects: e.reconnects || 0, last_seen: e.lastSeen || null, last_disconnect: e.lastDisconnect || null, current_game: this.online.currentGameFor(p.id) };
    });
    const live = this.svc.games().filter((g) => g.kind === 'online' && g.black_id != null && ['waiting', 'playing'].includes(g.state)).map((g) => {
      let snap = null; try { snap = this.online.snapshot(g.id, null); } catch (_) { /* partida ainda não carregável */ }
      return { id: g.id, round: g.round, board: g.board, state: g.state, white: g.white, black: g.black,
        presence: snap ? snap.presence : { w: false, b: false }, white_ms: snap ? snap.whiteMs : null, black_ms: snap ? snap.blackMs : null, moves: snap ? snap.moves.length : 0 };
    });
    return { players, games: live, server_time: Date.now() };
  }

  _unwatch(ws, gameId) {
    if (!ws.data.watching.has(gameId)) return;
    const color = ws.data.watching.get(gameId);
    ws.data.watching.delete(gameId);
    const set = this.watchers.get(gameId);
    if (set) { set.delete(ws); if (!set.size) this.watchers.delete(gameId); }
    if (color && ws.data.player) {
      this.online.disconnect(gameId, ws.data.player.id);
      this._pushGame(gameId);
    }
  }

  _wsMessage(ws, msg) {
    if (!msg || typeof msg !== 'object') return;
    const gid = Number.isInteger(msg.game) ? msg.game : null;
    switch (msg.type) {
      case 'ping': ws.send({ type: 'pong', serverTime: Date.now() }); return;
      case 'auth': {
        const p = this.svc.authPlayer(msg.token);
        if (!p || p.status !== 'active') { ws.send({ type: 'auth', ok: false }); return; }
        if (!ws.data.player || ws.data.player.id !== p.id) this._presenceUp(p.id);
        ws.data.player = p;
        ws.send({ type: 'auth', ok: true, player: p });
        this._queue('presence');
        return;
      }
      case 'watch': {
        if (gid == null) throw new OnlineError('invalid', 'Partida inválida.');
        if (ws.data.watching.has(gid)) this._unwatch(ws, gid);
        const row = this.svc.game(gid);
        if (!row || row.kind !== 'online' || row.black_id == null) throw new OnlineError('not_online', 'Esta não é uma partida online.');
        let color = null;
        if (ws.data.player) color = this.online.connect(gid, ws.data.player.id);
        ws.data.watching.set(gid, color);
        if (!this.watchers.has(gid)) this.watchers.set(gid, new Set());
        this.watchers.get(gid).add(ws);
        this._pushGame(gid);
        return;
      }
      case 'unwatch': if (gid != null) this._unwatch(ws, gid); return;
      case 'move': case 'resign': case 'draw_offer': case 'draw_response': {
        if (!ws.data.player) throw new OnlineError('unauthorized', 'Entre no torneio para jogar.');
        if (gid == null) throw new OnlineError('invalid', 'Partida inválida.');
        const pid = ws.data.player.id;
        if (msg.type === 'move') {
          const m = msg.move;
          const ok = typeof m === 'string' ? m.length <= 12 : (m && typeof m.from === 'string' && typeof m.to === 'string');
          if (!ok) throw new OnlineError('invalid', 'Lance inválido.');
          this.online.move(gid, pid, typeof m === 'string' ? m : { from: m.from, to: m.to, promotion: m.promotion });
        } else if (msg.type === 'resign') this.online.resign(gid, pid);
        else if (msg.type === 'draw_offer') this.online.offerDraw(gid, pid);
        else this.online.respondDraw(gid, pid, !!msg.accept);
        return;
      }
      default: throw new OnlineError('unknown', 'Mensagem desconhecida.');
    }
  }

  // ------------------------------------------------------------------ autenticação do organizador
  _adminToken(req) {
    const auth = req.headers.authorization;
    if (auth && auth.startsWith('Bearer ')) return auth.slice(7).trim();
    const cookie = req.headers.cookie || '';
    const m = /(?:^|;\s*)oc_admin=([A-Za-z0-9_-]+)/.exec(cookie);
    return m ? m[1] : null;
  }

  isAdmin(req) {
    const tok = this._adminToken(req);
    if (!tok) return false;
    const exp_ = this.sessions.get(sha256(tok));
    if (!exp_) return false;
    if (exp_ < Date.now()) { this.sessions.delete(sha256(tok)); return false; }
    return true;
  }

  /** true se a conexão veio de um túnel/proxy local (socket loopback com cabeçalhos de encaminhamento). */
  _viaProxy(req) {
    const a = req.socket.remoteAddress || '';
    const loop = /^(::1|127\.|::ffff:127\.)/.test(a);
    return loop && !!(req.headers['x-forwarded-for'] || req.headers['cf-connecting-ip'] || req.headers['cf-ray'] || req.headers['x-forwarded-proto']);
  }

  /** IP real do cliente: só confia em cabeçalhos de encaminhamento quando a conexão vem do próprio computador (túnel). */
  clientIp(req) {
    if (this._viaProxy(req)) {
      const f = String(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || '').split(',')[0].trim();
      if (f && f.length < 64) return f;
    }
    return req.socket.remoteAddress || '?';
  }

  _rateLimit(map, key, max, windowMs) {
    const now = Date.now();
    const arr = (map.get(key) || []).filter((t) => now - t < windowMs);
    if (arr.length >= max) { map.set(key, arr); return false; }
    arr.push(now); map.set(key, arr);
    if (map.size > 5000) for (const [k, v] of map) if (!v.length || now - v[v.length - 1] > windowMs) map.delete(k);
    return true;
  }

  // ------------------------------------------------------------------ HTTP
  _headers(extra = {}) {
    return {
      'X-Content-Type-Options': 'nosniff',
      'Referrer-Policy': 'no-referrer',
      'X-Frame-Options': 'DENY',
      'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' ws: wss:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
      ...extra,
    };
  }

  _json(res, status, obj, extra = {}) {
    const body = JSON.stringify(obj);
    res.writeHead(status, this._headers({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extra }));
    res.end(body);
  }

  _text(res, status, body, type, filename = null) {
    const h = { 'Content-Type': type, 'Cache-Control': 'no-store' };
    if (filename) {
      const ascii = filename.normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w.\- ]/g, '_');
      h['Content-Disposition'] = `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(filename)}`;
    }
    res.writeHead(status, this._headers(h));
    res.end(body);
  }

  _readBody(req, limit) {
    return new Promise((resolve, reject) => {
      const chunks = []; let size = 0;
      req.on('data', (c) => {
        size += c.length;
        if (size > limit) { reject(new HttpError(413, 'too_large', 'Requisição grande demais.')); req.destroy(); return; }
        chunks.push(c);
      });
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', reject);
    });
  }

  async _handle(req, res) {
    const started = Date.now();
    try {
      const url = new URL(req.url, 'http://x');
      const p = url.pathname;
      if (p.startsWith('/api/')) await this._api(req, res, url, p);
      else this._static(req, res, p);
    } catch (e) {
      if (e instanceof HttpError || e instanceof TournamentError || e instanceof OnlineError) {
        const status = e.status || 400;
        if (!res.headersSent) this._json(res, status, { error: { code: e.code, message: e.message } });
      } else if (e instanceof SyntaxError) {
        if (!res.headersSent) this._json(res, 400, { error: { code: 'bad_json', message: 'JSON inválido.' } });
      } else {
        this.log('erro', `${req.method} ${req.url}: ${e.stack || e.message}`);
        if (!res.headersSent) this._json(res, 500, { error: { code: 'internal', message: 'Erro interno do servidor.' } });
        else res.end();
      }
    }
    if (req.url.startsWith('/api/') && req.method !== 'GET') this.log('info', `${req.method} ${req.url.split('?')[0]} ${res.statusCode} ${Date.now() - started}ms`);
  }

  _static(req, res, p) {
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); res.end(); return; }
    let rel = decodeURIComponent(p);
    if (rel === '/' || rel === '/admin' || rel === '/admin/') rel = '/index.html';
    const file = path.normalize(path.join(this.webDir, rel));
    if (!file.startsWith(path.normalize(this.webDir + path.sep)) && file !== path.normalize(this.webDir)) { res.writeHead(403); res.end(); return; }
    let st;
    try { st = fs.statSync(file); } catch (_) { st = null; }
    if (!st || !st.isFile()) { res.writeHead(404, this._headers({ 'Content-Type': 'text/plain; charset=utf-8' })); res.end('Página não encontrada'); return; }
    const ext = path.extname(file);
    res.writeHead(200, this._headers({ 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300' }));
    if (req.method === 'HEAD') res.end(); else fs.createReadStream(file).pipe(res);
  }

  async _api(req, res, url, p) {
    const method = req.method;
    const svc = this.svc;
    const ip = this.clientIp(req);

    // ---- controle local (CLI): só loopback + token de controle
    if (p.startsWith('/api/control/')) {
      const loop = /^(::1|127\.|::ffff:127\.)/.test(req.socket.remoteAddress || '') && !this._viaProxy(req);
      const ok = loop && this.controlToken && req.headers['x-control-token'] === this.controlToken;
      if (!ok) throw new HttpError(403, 'forbidden', 'Acesso negado.');
      if (p === '/api/control/status' && method === 'GET') return this._json(res, 200, this.getStatus());
      if (p === '/api/control/stop' && method === 'POST') {
        this._json(res, 200, { ok: true });
        setTimeout(() => this.requestStop && this.requestStop(), 50);
        return;
      }
      throw new HttpError(404, 'not_found', 'Rota não encontrada.');
    }

    // ---- proteção CSRF: ações que alteram dados exigem JSON e mesma origem
    if (method !== 'GET' && method !== 'HEAD') {
      const origin = req.headers.origin;
      if (origin) { let ok = false; try { ok = new URL(origin).host === req.headers.host; } catch (_) { /* inválida */ } if (!ok) throw new HttpError(403, 'bad_origin', 'Origem não permitida.'); }
      const ct = String(req.headers['content-type'] || '');
      const hasBody = Number(req.headers['content-length'] || 0) > 0 || req.headers['transfer-encoding'];
      if (hasBody && !ct.startsWith('application/json') && !ct.startsWith('text/plain')) throw new HttpError(415, 'bad_type', 'Tipo de conteúdo não suportado.');
    }
    if (p.startsWith('/api/admin/') && !this.remoteAdmin && this._viaProxy(req)) {
      throw new HttpError(403, 'admin_local_only', 'O painel do organizador não está liberado pela internet. Abra-o pelo endereço local do computador que hospeda (ou inicie com --remote-admin).');
    }
    const isAdminRoute = p.startsWith('/api/admin/') && p !== '/api/admin/login';
    if (isAdminRoute && !this.isAdmin(req)) throw new HttpError(401, 'unauthorized', 'Acesso restrito ao organizador. Entre com a chave do organizador.');
    const body = (method === 'POST' || method === 'PUT' || method === 'PATCH')
      ? await this._readBody(req, p === '/api/admin/import-pgn' ? 4 * 1024 * 1024 : 64 * 1024)
      : '';
    const json = () => { if (!body.trim()) return {}; const v = JSON.parse(body); if (v === null || typeof v !== 'object') throw new HttpError(400, 'bad_json', 'Corpo inválido.'); return v; };
    const id = (s) => { const n = Number(s); if (!Number.isInteger(n) || n < 1) throw new HttpError(400, 'invalid_id', 'Identificador inválido.'); return n; };
    const reply = (obj, status = 200) => this._json(res, status, obj);
    let m;

    // =========================================================== públicas
    if (p === '/api/tournament' && method === 'GET') {
      return reply({ ...svc.publicInfo(), online_now: this.connectedPlayers().length });
    }
    if (p === '/api/players' && method === 'GET') {
      const conn = new Set(this.connectedPlayers());
      const anims = svc.playerAnims();
      return reply({ players: svc.players().map((pl) => ({ ...pl, connected: conn.has(pl.id), anim: anims.get(pl.id) || null })) });
    }
    if (p === '/api/animations' && method === 'GET') return reply({ animations: svc.animCatalog() });
    if (p === '/api/join' && method === 'POST') {
      if (!this._rateLimit(this.joinAttempts, ip, 20, 60000)) throw new HttpError(429, 'rate_limited', 'Muitas tentativas. Aguarde um minuto.');
      const b = json();
      if (!svc.checkAccess(b.access_code)) {
        this.log('aviso', `Entrada recusada: código de acesso ${b.access_code ? 'incorreto' : 'ausente'} (${ip})`);
        throw new HttpError(403, 'invalid_access_code', b.access_code ? 'Código de acesso incorreto.' : 'Este torneio é privado: informe o código de acesso que o organizador enviou.');
      }
      const r = svc.addPlayer(b.name, b.elo, { actor: 'participante' });
      return reply(r, 201);
    }
    if (p === '/api/me' && method === 'GET') {
      const pl = svc.authPlayer(req.headers['x-player-token']);
      if (!pl) throw new HttpError(401, 'unauthorized', 'Participante não reconhecido. Entre novamente.');
      const gameId = this.online.currentGameFor(pl.id);
      const mine = svc.games().filter((g) => g.white_id === pl.id || g.black_id === pl.id);
      const st = svc.standings().find((r) => r.id === pl.id) || null;
      return reply({ player: pl, anim: svc.animOf(pl.id), currentGame: gameId, games: mine, standing: st, position: st ? svc.standings().findIndex((r) => r.id === pl.id) + 1 : null });
    }
    if (p === '/api/leave' && method === 'POST') {
      const pl = svc.authPlayer(req.headers['x-player-token']);
      if (!pl) throw new HttpError(401, 'unauthorized', 'Participante não reconhecido.');
      const t = svc.tournament();
      if (t.status === 'finished') throw new HttpError(409, 'finished', 'O torneio já terminou.');
      svc.removePlayer(pl.id, 'participante');
      return reply({ ok: true });
    }
    if (p === '/api/rounds' && method === 'GET') {
      return reply({ rounds: svc.rounds(), games: svc.games(), current_round: svc.tournament().current_round });
    }
    if (p === '/api/standings' && method === 'GET') return reply({ standings: svc.standings(), tiebreaks: svc.tournament().tiebreaks });
    if (p === '/api/stats' && method === 'GET') return reply(svc.stats());
    if ((m = /^\/api\/games\/(\d+)$/.exec(p)) && method === 'GET') {
      const gid = id(m[1]);
      const row = svc.game(gid);
      if (!row) throw new HttpError(404, 'not_found', 'Partida não encontrada.');
      const pl = svc.authPlayer(req.headers['x-player-token']);
      let live = null;
      if (row.kind === 'online' && row.black_id != null) { try { live = this.online.snapshot(gid, pl ? pl.id : null); } catch (_) { live = null; } }
      return reply({ game: svc.games().find((g) => g.id === gid), replay: svc.replay(gid), live });
    }
    if ((m = /^\/api\/games\/(\d+)\/pgn$/.exec(p)) && method === 'GET') {
      const r = exp.gameToPgn(svc, id(m[1]));
      if (!r) throw new HttpError(404, 'not_found', 'Partida não encontrada.');
      if (url.searchParams.get('download') === '1') return this._text(res, 200, r.pgn, 'application/x-chess-pgn; charset=utf-8', `partida_${m[1]}.pgn`);
      return this._text(res, 200, r.pgn, 'text/plain; charset=utf-8');
    }
    if (p === '/api/pgn' && method === 'GET') {
      const all = tournamentPgnSafe(svc, url.searchParams.get('todas') === '1');
      if (url.searchParams.get('download') === '1') return this._text(res, 200, all, 'application/x-chess-pgn; charset=utf-8', exp.safeFileName(svc.tournament().name) + '.pgn');
      return this._text(res, 200, all, 'text/plain; charset=utf-8');
    }
    if (p === '/api/results.txt' && method === 'GET') {
      return this._text(res, 200, exp.buildResultsTxt(svc), 'text/plain; charset=utf-8', url.searchParams.get('download') === '0' ? null : exp.resultsFileName(svc));
    }
    if (p === '/api/imported' && method === 'GET') return reply({ games: svc.importedList() });
    if ((m = /^\/api\/imported\/(\d+)$/.exec(p)) && method === 'GET') return reply(svc.importedGame(id(m[1])));
    if (p === '/api/qr.svg' && method === 'GET') {
      const text = String(url.searchParams.get('text') || '');
      if (!text || text.length > 200) throw new HttpError(400, 'invalid', 'Texto inválido para o QR Code.');
      res.writeHead(200, this._headers({ 'Content-Type': 'image/svg+xml', 'Cache-Control': 'public, max-age=3600' }));
      return res.end(qrSvg(text));
    }

    // =========================================================== login do organizador
    if (p === '/api/admin/login' && method === 'POST') {
      if (!this._rateLimit(this.loginAttempts, ip, 8, 60000)) throw new HttpError(429, 'rate_limited', 'Muitas tentativas de entrada. Aguarde um minuto.');
      const key = String(json().key || '');
      const a = Buffer.from(sha256(key)), b2 = Buffer.from(sha256(this.adminKey || ''));
      if (!this.adminKey || !crypto.timingSafeEqual(a, b2)) {
        this.log('aviso', `Tentativa de login do organizador recusada (${ip})`);
        throw new HttpError(401, 'bad_key', 'Chave do organizador incorreta.');
      }
      const token = newToken() + newToken();
      this.sessions.set(sha256(token), Date.now() + SESSION_MS);
      this.log('info', `Organizador autenticado (${ip})`);
      return this._json(res, 200, { ok: true, token }, { 'Set-Cookie': `oc_admin=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_MS / 1000}` });
    }
    if (p === '/api/admin/logout' && method === 'POST') {
      const tok = this._adminToken(req);
      if (tok) this.sessions.delete(sha256(tok));
      return this._json(res, 200, { ok: true }, { 'Set-Cookie': 'oc_admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' });
    }

    // =========================================================== administração
    if (p === '/api/admin/session' && method === 'GET') return reply({ ok: true, status: this.getStatus() });
    if (p === '/api/admin/audit' && method === 'GET') return reply({ audit: svc.auditLog(Math.min(500, Number(url.searchParams.get('limit')) || 200)) });
    if (p === '/api/admin/registration' && method === 'POST') { svc.setRegistration(json().state); return reply({ ok: true, tournament: svc.publicInfo() }); }
    if (p === '/api/admin/config' && method === 'POST') { svc.updateConfig(json()); return reply({ ok: true, tournament: svc.publicInfo() }); }
    if (p === '/api/admin/players' && method === 'POST') {
      const b = json();
      const r = svc.addPlayer(b.name, b.elo, { force: !!b.force, actor: 'organizador' });
      return reply({ player: r.player }, 201);
    }
    if (p === '/api/admin/anim' && method === 'GET') return reply({ codes: svc.animList(), catalog: svc.animCatalog(), players: svc.players() });
    if (p === '/api/admin/anim/codes' && method === 'POST') return reply({ code: svc.animCreate(json()) }, 201);
    if ((m = /^\/api\/admin\/anim\/codes\/(\d+)$/.exec(p)) && method === 'POST') return reply({ code: svc.animUpdate(id(m[1]), json()) });
    if ((m = /^\/api\/admin\/anim\/codes\/(\d+)$/.exec(p)) && method === 'DELETE') { svc.animDelete(id(m[1])); return reply({ ok: true }); }
    if (p === '/api/admin/invite' && method === 'GET') return reply(this.inviteInfo());
    if (p === '/api/admin/invite' && method === 'POST') { svc.setInvite(json()); return reply(this.inviteInfo()); }
    if (p === '/api/admin/connections' && method === 'GET') return reply(this.connectionsInfo());
    if ((m = /^\/api\/admin\/connections\/(\d+)\/reset$/.exec(p)) && method === 'POST') {
      const pid = id(m[1]); let n = 0;
      for (const c of [...this.ws.connections]) if (!c.closed && c.data.player && c.data.player.id === pid) { c.close(1012, 'reiniciada pelo organizador'); n++; }
      svc.store.audit('organizador', 'conexao_reiniciada', 'participante', pid, { conexoes: n });
      return reply({ ok: true, closed: n });
    }
    if ((m = /^\/api\/admin\/players\/(\d+)$/.exec(p)) && method === 'DELETE') { svc.removePlayer(id(m[1])); return reply({ ok: true }); }
    if (p === '/api/admin/start' && method === 'POST') { svc.start(); return reply({ ok: true, tournament: svc.publicInfo() }); }
    if (p === '/api/admin/next-round' && method === 'POST') { const n = svc.nextRound(); return reply({ ok: true, round: n }); }
    if (p === '/api/admin/round/start' && method === 'POST') { const r = svc.startRound(json().number ?? null); return reply({ ok: true, round: r }); }
    if (p === '/api/admin/round/finish' && method === 'POST') { const r = svc.finishRound(json().number ?? null); return reply({ ok: true, round: r }); }
    if (p === '/api/admin/finish' && method === 'POST') { svc.finish(); return reply({ ok: true, tournament: svc.publicInfo() }); }
    if (p === '/api/admin/pairings' && method === 'POST') { return reply({ ok: true, games: svc.editPairings(json().edits) }); }
    if ((m = /^\/api\/admin\/games\/(\d+)\/result$/.exec(p)) && method === 'POST') {
      const b = json();
      const g = svc.recordResult(id(m[1]), b.result, { actor: 'organizador', correction: !!b.correction, reason: b.reason });
      return reply({ ok: true, game: g });
    }
    if ((m = /^\/api\/admin\/games\/(\d+)\/state$/.exec(p)) && method === 'POST') { return reply({ ok: true, game: svc.setGameState(id(m[1]), json().state) }); }
    if ((m = /^\/api\/admin\/games\/(\d+)\/moves$/.exec(p)) && method === 'POST') {
      const b = json();
      let sans = b.moves;
      if (typeof b.pgn === 'string') {
        const parsed = require('../chess/pgn').parsePgn(b.pgn);
        if (!parsed.length || parsed[0].error) throw new HttpError(400, 'invalid_pgn', parsed[0] && parsed[0].error ? parsed[0].error : 'PGN inválido.');
        sans = parsed[0].moves;
      }
      return reply({ ok: true, ...svc.attachMoves(id(m[1]), sans) });
    }
    if (p === '/api/admin/import-pgn' && method === 'POST') {
      const b = json();
      if (typeof b.pgn !== 'string' || !b.pgn.trim()) throw new HttpError(400, 'invalid_pgn', 'Envie o texto do PGN.');
      return reply({ ok: true, ...svc.importPgn(b.pgn) });
    }
    if (p === '/api/admin/export/txt' && method === 'POST') {
      const file = exp.writeResultsTxt(svc, this.dir);
      return reply({ ok: true, file, name: path.basename(file) });
    }
    if (p === '/api/admin/backup' && method === 'POST') {
      const f = await this._backupNow('manual');
      if (!f) throw new HttpError(500, 'backup_failed', 'Não foi possível criar o backup.');
      return reply({ ok: true, file: f, name: path.basename(f) });
    }
    if (p === '/api/admin/backups' && method === 'GET') {
      const dir = path.join(this.dir, 'backups');
      const list = fs.existsSync(dir) ? fs.readdirSync(dir).filter((f) => f.endsWith('.db')).sort().reverse().map((f) => ({ name: f, size: fs.statSync(path.join(dir, f)).size })) : [];
      return reply({ backups: list, dir });
    }
    if ((m = /^\/api\/admin\/backups\/([\w.\-]+\.db)$/.exec(p)) && method === 'GET') {
      const f = path.join(this.dir, 'backups', path.basename(m[1]));
      if (!fs.existsSync(f)) throw new HttpError(404, 'not_found', 'Backup não encontrado.');
      return this._text(res, 200, fs.readFileSync(f), 'application/octet-stream', path.basename(f));
    }
    if (p === '/api/admin/integrity' && method === 'GET') return reply(this.store.integrityCheck());
    throw new HttpError(404, 'not_found', 'Rota não encontrada.');
  }
}

function tournamentPgnSafe(svc, includeResultOnly) { return exp.tournamentPgn(svc, { includeResultOnly }); }

module.exports = { OpenChessServer, lanAddresses, explainListenError, HttpError };
