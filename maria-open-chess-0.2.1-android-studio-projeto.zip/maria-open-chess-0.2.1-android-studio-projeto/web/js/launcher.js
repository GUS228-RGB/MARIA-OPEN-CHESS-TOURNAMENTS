// Tela do aplicativo: CRIAR TORNEIO e INICIAR HOSPEDAGEM (roda no navegador do próprio aparelho).
import { h, toast, copyText, LABELS, confirmDialog } from './dom.js';

const app = document.getElementById('app');
async function api(method, path, body) {
  const r = await fetch(path, method === 'GET' ? {} : { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((data.error && data.error.message) || `Erro ${r.status}`);
  return data;
}

let state = null, hostSig = '';
const idle = h('div'), hosting = h('div', { class: 'hidden' });
app.append(
  h('header', { class: 'topbar' }, h('div', { class: 'topbar-in' }, h('span', { class: 'brand' }, h('img', { src: '/logo.svg', alt: '' }), h('span', null, 'maria open '), h('b', null, 'CHESS')), h('span', { class: 'spacer' }), h('span', { class: 'chip warn' }, 'Organizador'))),
  h('main', { id: 'main', tabindex: '-1' }, idle, hosting));

// ------------------------------------------------------------ formulário
const F = {};
function field(label, input, hint) { return h('div', { class: 'field' }, h('label', { for: input.id }, label), input, hint ? h('div', { class: 'hint' }, hint) : null); }
const num = (id, value, attrs = {}) => (F[id] = h('input', { id, type: 'number', value, inputmode: 'decimal', step: 'any', ...attrs }));
const sel = (id, opts, value) => (F[id] = h('select', { id }, opts.map(([v, l]) => h('option', { value: v, selected: v === value }, l))));

function buildIdle() {
  F.name = h('input', { id: 'name', type: 'text', maxlength: 80, placeholder: 'Ex.: Campeonato da Escola 2026', autocomplete: 'off' });
  F.description = h('textarea', { id: 'description', rows: 2, maxlength: 500, style: 'min-height:70px' });
  F.max = h('input', { id: 'max', type: 'range', min: 2, max: 256, value: 16 });
  const maxOut = h('b', null, '16');
  F.max.addEventListener('input', () => { maxOut.textContent = F.max.value; });
  sel('modality', [['presencial', 'Presencial (tabuleiros reais)'], ['online', 'Online (no navegador)'], ['hibrido', 'Híbrida']], 'presencial');
  sel('system', [['suico', 'Sistema Suíço'], ['round_robin', 'Round Robin (todos contra todos)'], ['eliminatoria_simples', 'Eliminatória simples'], ['eliminatoria_dupla', 'Eliminatória dupla']], 'suico');
  num('rounds', '', { min: 1, max: 99, placeholder: 'automático' });
  F.rr = h('input', { id: 'rr', type: 'checkbox' });
  num('time', 10, { min: 1 }); num('inc', 0, { min: 0 });
  num('win', 1); num('draw', 0.5); num('loss', 0); num('tables', 0, { min: 0 });
  sel('visibility', [['private', 'Privado — só entra quem tem o código de acesso (recomendado)'], ['public', 'Público — quem tiver o link entra']], 'private');
  F.tunnel = h('input', { id: 'tunnel', type: 'checkbox' });

  const rowRounds = field('Quantidade de rodadas (vazio = automático)', F.rounds);
  const rowRR = h('div', { class: 'field' }, h('label', { class: 'check', for: 'rr' }, F.rr, 'Turno e returno (2 partidas por par)'));
  const rowTime = h('div', { class: 'grid cols-2' }, field('Tempo por jogador (minutos)', F.time), field('Incremento por lance (segundos)', F.inc));
  const rowTables = field('Mesas físicas (0 = sem limite)', F.tables);
  const update = () => {
    rowRounds.classList.toggle('hidden', F.system.value !== 'suico');
    rowRR.classList.toggle('hidden', F.system.value !== 'round_robin');
    rowTime.classList.toggle('hidden', F.modality.value === 'presencial');
    rowTables.classList.toggle('hidden', F.modality.value === 'online');
  };
  F.system.addEventListener('change', update); F.modality.addEventListener('change', update); update();

  const submit = h('button', { class: 'btn primary big', type: 'submit', style: 'width:100%' }, 'INICIAR HOSPEDAGEM');
  const err = h('div', { class: 'err hidden', role: 'alert' });
  const form = h('form', { novalidate: true, class: 'card stack', onsubmit: async (e) => {
    e.preventDefault(); err.classList.add('hidden'); submit.disabled = true; submit.textContent = F.tunnel.checked ? 'Iniciando e abrindo túnel…' : 'Iniciando…';
    try {
      state = await api('POST', '/api/launcher/start', {
        name: F.name.value, description: F.description.value, max_players: Number(F.max.value), modality: F.modality.value, system: F.system.value,
        rounds_total: F.rounds.value || null, rr_double: F.rr.checked, time_min: Number(F.time.value), time_inc_s: Number(F.inc.value),
        pts_win: Number(String(F.win.value).replace(',', '.')), pts_draw: Number(String(F.draw.value).replace(',', '.')), pts_loss: Number(String(F.loss.value).replace(',', '.')), tables_count: Number(F.tables.value), visibility: F.visibility.value, tunnel: F.tunnel.checked,
      });
      render(true);
    } catch (ex) { err.textContent = ex.message; err.classList.remove('hidden'); err.scrollIntoView({ block: 'center' }); }
    submit.disabled = false; submit.textContent = 'INICIAR HOSPEDAGEM';
  } },
  h('h1', { style: 'font-size:1.5rem' }, 'Criar torneio'),
  field('Nome do torneio', F.name), field('Descrição (opcional)', F.description),
  h('div', { class: 'field' }, h('label', { for: 'max' }, 'Máximo de participantes: ', maxOut), F.max, h('div', { class: 'hint' }, 'Deslize para escolher de 2 a 256.')),
  field('Modalidade', F.modality), field('Acesso ao torneio', F.visibility, 'Privado: o convite leva um código de acesso. Você pode mudar depois no painel.'), field('Sistema de disputa', F.system), rowRounds, rowRR, rowTime, rowTables,
  h('div', { class: 'grid', style: 'grid-template-columns:repeat(3,1fr)' }, field('Pts vitória', F.win), field('Pts empate', F.draw), field('Pts derrota', F.loss)),
  h('div', { class: 'field' }, h('label', { class: 'check', for: 'tunnel' }, F.tunnel, 'Permitir jogadores de outras redes (internet)'), h('div', { class: 'hint', id: 'tunnel-hint' })),
  err, submit);
  return { form, update };
}

/** Ferramentas do aplicativo Android (ponte nativa window.OpenChessAndroid, injetada pelo app). */
function androidTools() {
  const A = window.OpenChessAndroid;
  return h('div', { class: 'card', style: 'margin-top:16px' }, h('h2', null, 'Aplicativo'),
    h('p', { class: 'note' }, 'Os torneios ficam guardados neste aparelho. Salve uma cópia na pasta Downloads para não perder se desinstalar o aplicativo.'),
    h('div', { class: 'row' },
      h('button', { class: 'btn small', onclick: () => { try { const r = String(A.exportAll()); toast(r.replace(/^(OK|ERRO): /, ''), r.startsWith('OK') ? 'ok' : 'error', 8000); } catch (e) { toast('Não foi possível salvar a cópia.', 'error'); } } }, 'Salvar cópia dos torneios em Downloads'),
      h('button', { class: 'btn danger small', onclick: async () => { if (await confirmDialog({ title: 'Encerrar o aplicativo?', message: 'A hospedagem em andamento será encerrada com segurança e os dados ficam salvos.', confirmLabel: 'Encerrar', danger: true })) A.quit(); } }, 'Encerrar aplicativo')));
}

let built = null;
function renderIdle() {
  if (!built) { built = buildIdle(); }
  const tools = state.tunnel_tools, any = tools.cloudflared || tools.ssh || tools.lt;
  F.tunnel.disabled = !any;
  const hint = document.getElementById('tunnel-hint');
  if (hint) hint.textContent = any ? 'Abre um túnel gratuito e gera um link público (https) válido em qualquer rede, sem instalar nada. Sem isso, só entra quem está no mesmo Wi-Fi.'
    : state.platform.android_app ? 'Indisponível nesta versão do aplicativo. Os participantes entram pelo mesmo Wi-Fi ou pelo ponto de acesso (hotspot) deste celular.'
    : 'Indisponível: instale o cloudflared ou o OpenSSH neste aparelho' + (state.platform.termux ? ' (no Termux: pkg install openssh)' : '') + '. Sem isso, só entra quem está no mesmo Wi-Fi.';
  idle.replaceChildren(built.form);
  if (state.platform.termux) idle.append(h('div', { class: 'banner warn', style: 'margin-top:14px' }, h('span', null, 'Android: o servidor só funciona enquanto o Termux estiver aberto (mantenha a notificação do Termux e desative a economia de bateria para ele). Ao bloquear a tela, o torneio pode parar.')));
  if (state.platform.android_app) idle.append(h('div', { class: 'banner warn', style: 'margin-top:14px' }, h('span', null, 'Durante o torneio, mantenha a notificação "maria open CHESS" ativa e desative a economia de bateria para este aplicativo. Se o Android o fechar, o torneio para (mas fica salvo e pode ser retomado).')));
  if (window.OpenChessAndroid) idle.append(androidTools());
  if (state.platform.os === 'ios') idle.append(h('div', { class: 'banner danger' }, 'iOS não permite hospedar em segundo plano. Use um computador.'));
  if (state.saved.length) {
    idle.append(h('div', { class: 'card', style: 'margin-top:16px' }, h('h2', null, 'Torneios salvos'),
      state.saved.map((t) => h('div', { class: 'row between', style: 'padding:8px 0;border-top:1px solid var(--border)' },
        h('span', null, h('b', null, t.name), h('span', { class: 'muted' }, ` · ${LABELS.status[t.status]} · ${t.players} participantes`)),
        h('button', { class: 'btn small', onclick: async () => { try { state = await api('POST', '/api/launcher/resume', { dir: t.dir, tunnel: F.tunnel.checked }); render(true); } catch (e) { toast(e.message, 'error'); } } }, 'Retomar')))));
  }
}

// ------------------------------------------------------------ hospedagem
let manualIp = '';
function renderHosting() {
  const s = state.hosting;
  const lan = s.urls.lan.map((a) => a.url);
  const manual = manualIp ? [`http://${manualIp}:${s.port}/`] : [];
  const inv = s.invite, q = inv ? '?c=' + inv.access_code : '';
  const urls = inv ? [...inv.links.filter((l) => l.scope !== 'local').map((l) => l.url), ...manual.map((u) => u + q)] : [...(s.public_url ? [s.public_url] : []), ...lan, ...manual];
  const main = urls[0] || s.urls.local;
  const pct = Math.min(100, Math.round((s.players / s.max_players) * 100));
  const stat = (v, l) => h('div', { class: 'stat' }, h('b', null, String(v)), h('span', null, l));
  hosting.replaceChildren(h('div', { class: 'stack' },
    h('section', { class: 'card hero stack' },
      h('div', { class: 'row' }, h('span', { class: 'chip ok live' }, 'Hospedando'), h('span', { class: 'chip' }, LABELS.modality[s.modality]), h('span', { class: 'chip' }, LABELS.system[s.system])),
      h('h1', null, s.name),
      h('div', null, h('div', { class: 'row between' }, h('span', null, h('b', null, s.players), ` de ${s.max_players} participantes`), h('b', { style: s.full ? 'color:var(--danger)' : '' }, s.full ? 'Lotado' : `${s.slots_left} vagas restantes`)), h('div', { class: 'bar', style: 'margin-top:8px' }, h('i', { style: `width:${pct}%` })))),
    h('div', { class: 'stats' }, stat(s.connected, 'conectados agora'), stat(s.current_round ? `${s.current_round}${s.rounds_total ? '/' + s.rounds_total : ''}` : '—', 'rodada atual'), stat(s.games_playing, 'partidas em andamento'), stat(s.results_recorded, 'resultados registrados')),
    h('div', { class: 'card' }, h('h2', null, 'Convide os participantes'),
      h('div', { class: 'share' },
        h('img', { src: '/api/launcher/qr.svg?text=' + encodeURIComponent(main), alt: 'QR Code: ' + main, width: 168, height: 168 }),
        h('div', { class: 'stack' },
          s.public_url ? h('span', { class: 'chip ok' }, '● Link público ativo: funciona em qualquer rede') : null,
          inv ? h('div', { class: 'row' }, h('span', { class: 'chip ' + (inv.visibility === 'private' ? 'warn' : '') }, inv.visibility === 'private' ? 'Torneio privado' : 'Torneio público'), h('span', null, 'Código de acesso: ', h('b', { class: 'mono' }, inv.access_code_display))) : null,
          urls.length ? urls.map((u) => h('div', { class: 'row' }, h('div', { class: 'urlbox', style: 'flex:1' }, u), h('button', { class: 'btn small', onclick: async () => toast((await copyText(u)) ? 'Endereço copiado.' : 'Não foi possível copiar.', 'ok') }, 'Copiar'), navigator.share ? h('button', { class: 'btn small', onclick: () => navigator.share({ title: s.name, text: 'Participe do torneio de xadrez: ' + s.name, url: u }).catch(() => {}) }, 'Compartilhar') : null))
            : h('div', { class: 'banner warn' }, 'Não foi possível detectar o IP deste aparelho. Veja-o em Configurações > Wi-Fi e digite abaixo.'),
          !lan.length && !s.public_url ? h('input', { type: 'text', inputmode: 'decimal', placeholder: 'IP do Wi-Fi, ex.: 192.168.0.15', value: manualIp, 'aria-label': 'IP do aparelho', onchange: (e) => { manualIp = e.target.value.trim().replace(/[^0-9.]/g, ''); hostSig = ''; render(true); } }) : null,
          s.tunnel_error ? h('div', { class: 'err' }, 'Link público indisponível: ' + s.tunnel_error.split('\n')[0]) : null,
          h('p', { class: 'note', style: 'margin:0' }, s.public_url ? 'O link https funciona de qualquer rede. Os endereços com números (IP) só funcionam no mesmo Wi-Fi.' : 'Endereços com IP só funcionam para quem está no MESMO Wi-Fi/rede deste aparelho — não pela internet.')))),
    h('div', { class: 'row' },
      h('a', Object.assign({ class: 'btn primary big', href: s.admin_url }, state.platform.android_app ? {} : { target: '_blank', rel: 'noopener' }), 'Abrir painel do organizador'),
      h('button', { class: 'btn danger', onclick: async () => { if (await confirmDialog({ title: 'Encerrar a hospedagem?', message: 'Os participantes serão desconectados. Os dados do torneio ficam salvos e você pode retomá-lo depois.', confirmLabel: 'Encerrar', danger: true })) { try { state = await api('POST', '/api/launcher/stop'); render(true); } catch (e) { toast(e.message, 'error'); } } } }, 'Encerrar hospedagem')),
    h('p', { class: 'note' }, 'Mantenha este aplicativo aberto durante o torneio: o servidor roda neste aparelho. Dados salvos em: ', h('span', { class: 'mono' }, s.dir))));
}

function render(force = false) {
  if (!state) return;
  const hs = state.hosting;
  idle.classList.toggle('hidden', !!hs); hosting.classList.toggle('hidden', !hs);
  if (!hs) { if (force || !idle.firstChild) renderIdle(); hostSig = ''; return; }
  const sig = JSON.stringify([hs.players, hs.connected, hs.current_round, hs.games_playing, hs.results_recorded, hs.public_url, hs.tunnel_error, hs.full, hs.status, manualIp, hs.invite && hs.invite.access_code, hs.invite && hs.invite.visibility]);
  if (force || sig !== hostSig) { hostSig = sig; renderHosting(); }
}

async function poll() {
  try { state = await api('GET', '/api/launcher/state'); render(); } catch (_) { /* servidor do app parou */ }
}
await poll(); render(true);
setInterval(poll, 2000);
