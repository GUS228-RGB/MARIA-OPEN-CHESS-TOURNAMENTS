import { h, svgUse } from './dom.js';

const FILES = 'abcdefgh';
const NAMES = { P: ['peão', 'm'], N: ['cavalo', 'm'], B: ['bispo', 'm'], R: ['torre', 'f'], Q: ['dama', 'f'], K: ['rei', 'm'] };
const pieceLabel = (p) => { const [n, g] = NAMES[p.toUpperCase()]; const white = p === p.toUpperCase(); return `${n} ${white ? (g === 'f' ? 'branca' : 'branco') : (g === 'f' ? 'preta' : 'preto')}`; };

/** Posição FEN → { 'e4': 'P', ... } */
export function fenToMap(fen) {
  const map = {};
  const rows = String(fen).split(' ')[0].split('/');
  rows.forEach((row, i) => {
    let f = 0;
    for (const ch of row) {
      if (/\d/.test(ch)) f += Number(ch);
      else { map[FILES[f] + (8 - i)] = ch; f++; }
    }
  });
  return map;
}
export const turnOfFen = (fen) => String(fen).split(' ')[1] || 'w';
export function kingSquare(map, color) { const k = color === 'w' ? 'K' : 'k'; return Object.keys(map).find((s) => map[s] === k) || null; }

/**
 * Tabuleiro interativo e acessível.
 * update({ map, orientation, last:'e2e4'|null, checkColor:'w'|'b'|null, legal:[{from,to,promotion}], you:'w'|'b'|null })
 */
export function createBoard({ onMove }) {
  const el = h('div', { class: 'board', role: 'grid', 'aria-label': 'Tabuleiro de xadrez' });
  let st = { map: {}, orientation: 'w', last: null, checkColor: null, legal: [], you: null };
  let selected = null, promoFrom = null, focusSq = 'e2';

  const order = () => {
    const out = [];
    const ranks = st.orientation === 'w' ? [8, 7, 6, 5, 4, 3, 2, 1] : [1, 2, 3, 4, 5, 6, 7, 8];
    const files = st.orientation === 'w' ? [0, 1, 2, 3, 4, 5, 6, 7] : [7, 6, 5, 4, 3, 2, 1, 0];
    for (const r of ranks) for (const f of files) out.push(FILES[f] + r);
    return out;
  };
  const isOwn = (sq) => { const p = st.map[sq]; return p && st.you && (p === p.toUpperCase() ? 'w' : 'b') === st.you; };
  const movesFrom = (sq) => st.legal.filter((m) => m.from === sq);

  function render(refocus = false) {
    const hadFocus = el.contains(document.activeElement);
    el.textContent = '';
    const sqs = order();
    const lastFrom = st.last ? st.last.slice(0, 2) : null, lastTo = st.last ? st.last.slice(2, 4) : null;
    const checkSq = st.checkColor ? kingSquare(st.map, st.checkColor) : null;
    const targets = selected ? new Set(movesFrom(selected).map((m) => m.to)) : new Set();
    sqs.forEach((sq, i) => {
      const f = FILES.indexOf(sq[0]), r = Number(sq[1]);
      const dark = (f + r) % 2 === 0;
      const piece = st.map[sq];
      const classes = ['sq', dark ? 'dark' : '', (sq === lastFrom || sq === lastTo) ? 'last' : '', sq === selected ? 'sel' : '', sq === checkSq ? 'check' : '',
        targets.has(sq) ? 'target' : '', targets.has(sq) && piece ? 'cap' : '', (isOwn(sq) && movesFrom(sq).length) ? 'canmove' : ''].filter(Boolean).join(' ');
      const b = h('button', { class: classes, type: 'button', role: 'gridcell', 'data-sq': sq, tabindex: sq === focusSq ? 0 : -1,
        'aria-label': `${sq}, ${piece ? pieceLabel(piece) : 'vazia'}${sq === selected ? ', selecionada' : ''}${targets.has(sq) ? ', destino possível' : ''}`,
        onclick: () => click(sq), onfocus: () => { focusSq = sq; } });
      if (i % 8 === 0) b.append(h('span', { class: 'coord r' }, String(r)));
      if (i >= 56) b.append(h('span', { class: 'coord f' }, sq[0]));
      if (piece) b.append(svgUse('def-' + piece.toUpperCase(), 'pc ' + (piece === piece.toUpperCase() ? 'w' : 'b')));
      el.append(b);
    });
    if (promoFrom) el.append(promoOverlay());
    if (refocus || hadFocus) { const f = el.querySelector(`[data-sq="${focusSq}"]`); if (f) f.focus({ preventScroll: true }); }
  }

  function promoOverlay() {
    const color = st.you || 'w';
    const box = h('div', { class: 'promo', role: 'dialog', 'aria-label': 'Escolha a peça da promoção' });
    for (const p of ['q', 'r', 'b', 'n']) {
      const piece = color === 'w' ? p.toUpperCase() : p;
      box.append(h('button', { type: 'button', 'aria-label': 'Promover para ' + pieceLabel(piece), onclick: () => { const mv = { from: promoFrom.from, to: promoFrom.to, promotion: p }; promoFrom = null; selected = null; render(true); onMove(mv); } }, svgUse('def-' + p.toUpperCase(), 'pc ' + color)));
    }
    box.append(h('button', { type: 'button', style: 'width:auto;padding:0 14px;aspect-ratio:auto;height:48px;font-weight:700', onclick: () => { promoFrom = null; render(true); } }, 'Cancelar'));
    return box;
  }

  function click(sq) {
    if (promoFrom) return;
    if (selected && selected !== sq) {
      const cands = st.legal.filter((m) => m.from === selected && m.to === sq);
      if (cands.length) {
        if (cands.some((m) => m.promotion)) { promoFrom = { from: selected, to: sq }; render(); const first = el.querySelector('.promo button'); if (first) first.focus(); return; }
        selected = null; render(true); onMove({ from: cands[0].from, to: sq }); return;
      }
    }
    if (isOwn(sq) && movesFrom(sq).length) selected = selected === sq ? null : sq; else selected = null;
    render(true);
  }

  el.addEventListener('keydown', (e) => {
    const moves = { ArrowUp: [0, 1], ArrowDown: [0, -1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] }[e.key];
    if (!moves || !document.activeElement || !document.activeElement.dataset.sq) return;
    e.preventDefault();
    const flip = st.orientation === 'w' ? 1 : -1;
    const sq = document.activeElement.dataset.sq;
    const f = FILES.indexOf(sq[0]) + moves[0] * flip, r = Number(sq[1]) + moves[1] * flip;
    if (f < 0 || f > 7 || r < 1 || r > 8) return;
    const next = el.querySelector(`[data-sq="${FILES[f]}${r}"]`);
    if (next) { focusSq = FILES[f] + r; el.querySelectorAll('.sq').forEach((s) => s.setAttribute('tabindex', '-1')); next.setAttribute('tabindex', '0'); next.focus(); }
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && (selected || promoFrom) && el.isConnected) { selected = null; promoFrom = null; render(true); } });

  return {
    el,
    update(patch) {
      const turnChanged = patch.legal !== undefined && JSON.stringify(patch.legal) !== JSON.stringify(st.legal);
      st = { ...st, ...patch };
      if (turnChanged || (patch.map && (!selected || !isOwn(selected)))) { selected = null; promoFrom = null; }
      render();
    },
    clearSelection() { selected = null; promoFrom = null; render(); },
  };
}
