// As 8 animações de vitória. Cada uma é só visual: nada aqui toca no tabuleiro, no relógio ou no resultado.
import { registerAnimation, glow, rand, TAU, ease, clamp01 } from './engine.js';
import { note } from './audio.js';

const GOLD = 'rgba(255,200,60,1)', GOLD_L = 'rgba(255,238,170,1)', WHITE = 'rgba(255,255,255,1)';
const blend = (ctx, mode) => { ctx.globalCompositeOperation = mode; };

/** Partículas simples: {x,y,vx,vy,life,max,size,sprite,grav,drag} */
function emit(list, n, f) { for (let i = 0; i < n; i++) list.push(f(i)); }
function stepDraw(ctx, list, dt, { grav = 0, drag = 0, grow = 0, fade = true } = {}) {
  for (let i = list.length - 1; i >= 0; i--) {
    const p = list[i];
    p.life += dt;
    if (p.life >= p.max) { list[i] = list[list.length - 1]; list.pop(); continue; }
    p.vy += (p.grav ?? grav) * dt;
    const d = 1 - Math.min(1, (p.drag ?? drag) * dt); p.vx *= d; p.vy *= d;
    p.x += p.vx * dt; p.y += p.vy * dt;
    const k = p.life / p.max;
    const a = fade ? (k < 0.15 ? k / 0.15 : 1 - (k - 0.15) / 0.85) : 1;
    const sz = p.size * (grow ? 1 + grow * k : 1 - 0.5 * k);
    ctx.globalAlpha = Math.max(0, a) * (p.alpha ?? 1);
    ctx.drawImage(p.sprite, p.x - sz, p.y - sz, sz * 2, sz * 2);
  }
  ctx.globalAlpha = 1;
}
const fadeInOut = (t, d, a = 300, b = 600) => clamp01(Math.min(t / a, (d - t) / b));

// ================================================================= PADRÃO
registerAnimation('padrao', {
  title: 'VITÓRIA!', duration: 3200,
  setup: (env) => ({ conf: [], t: 0, colors: ['#5eead4', '#f5c451', '#ff7a85', '#8ab4ff', '#ffffff'] }),
  draw(env, s, t, dt) {
    const { ctx, w, h } = env;
    if (s.t < 1200) { const n = Math.round(90 * dt * env.q * 8); emit(s.conf, n, () => ({ x: rand(0, w), y: rand(-40, 0), vx: rand(-60, 60), vy: rand(120, 320), r: rand(0, TAU), vr: rand(-6, 6), c: s.colors[(Math.random() * s.colors.length) | 0], w: rand(6, 11), h: rand(10, 18) })); }
    s.t += dt * 1000;
    blend(ctx, 'source-over');
    for (let i = s.conf.length - 1; i >= 0; i--) {
      const p = s.conf[i]; p.x += p.vx * dt + Math.sin(p.y / 40) * 0.6; p.y += p.vy * dt; p.r += p.vr * dt;
      if (p.y > h + 30) { s.conf[i] = s.conf[s.conf.length - 1]; s.conf.pop(); continue; }
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.scale(1, Math.abs(Math.cos(p.r * 1.7)) * 0.8 + 0.2); ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); ctx.restore();
    }
  },
  sound(a) { a.tone(note(76), 0, 0.5, 'triangle', 0.35); a.tone(note(83), 0.14, 0.7, 'triangle', 0.3); a.tone(note(88), 0.3, 0.9, 'sine', 0.22); },
});

// ================================================================= 001 EXPLOSÃO DOURADA
registerAnimation('ouro', {
  title: 'VITÓRIA!', duration: 4600,
  setup: () => ({ p: [], fired: [false, false, false], wave: 0 }),
  draw(env, s, t, dt) {
    const { ctx, w, h, cx, cy, q } = env;
    const R = Math.max(w, h);
    const burst = (n, x, y, sp) => emit(s.p, Math.round(n * q), () => { const a = rand(0, TAU), v = rand(sp * 0.25, sp); return { x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: 0, max: rand(1.2, 2.6), size: rand(5, 15), sprite: glow(Math.random() < 0.6 ? GOLD : GOLD_L), grav: 380, drag: 0.9 }; });
    [[0, cx, cy, 1000, 200], [1100, cx - w * 0.22, cy - h * 0.12, 650, 90], [1700, cx + w * 0.22, cy - h * 0.1, 650, 90]].forEach(([at, x, y, sp, n], i) => { if (!s.fired[i] && t >= at) { s.fired[i] = true; burst(n, x, y, sp); s.wave = i === 0 ? t : s.wave; } });
    blend(ctx, 'lighter');
    // clarão inicial
    if (t < 700) { const k = 1 - t / 700; ctx.globalAlpha = k * 0.9; ctx.drawImage(glow(GOLD_L), cx - R, cy - R, R * 2, R * 2); ctx.globalAlpha = 1; }
    // onda de choque
    if (t < 1300) { const k = t / 1300, r = ease.out(k) * R * 0.62; ctx.globalAlpha = (1 - k) * 0.8; ctx.strokeStyle = 'rgb(255,214,90)'; ctx.lineWidth = 10 * (1 - k) + 2; ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1; }
    // brilho central pulsante
    const g = fadeInOut(t, 4600, 200, 1200); ctx.globalAlpha = 0.35 * g * (0.8 + 0.2 * Math.sin(t / 160)); const gr = Math.min(w, h) * 0.55; ctx.drawImage(glow(GOLD), cx - gr, cy - gr, gr * 2, gr * 2); ctx.globalAlpha = 1;
    // faíscas contínuas caindo
    if (t > 600 && t < 3200 && Math.random() < 0.6 * q) emit(s.p, 2, () => ({ x: rand(0, w), y: rand(-20, h * 0.2), vx: rand(-20, 20), vy: rand(60, 200), life: 0, max: rand(1.5, 2.6), size: rand(3, 7), sprite: glow(GOLD_L), grav: 40, drag: 0.1 }));
    stepDraw(ctx, s.p, dt, { grav: 380, drag: 0.9 });
    blend(ctx, 'source-over');
  },
  sound(a) {
    a.noise(0, 0.5, { type: 'lowpass', f0: 2400, f1: 200, vol: 0.9 }); a.tone(90, 0, 0.7, 'sine', 0.9, 0.005, 40);
    [72, 76, 79, 84, 88].forEach((n, i) => { a.tone(note(n), 0.18 + i * 0.1, 0.9, 'triangle', 0.3); a.tone(note(n + 12), 0.18 + i * 0.1, 0.6, 'sine', 0.12); });
    for (let i = 0; i < 14; i++) a.tone(rand(2400, 5200), 0.6 + i * 0.12, 0.25, 'sine', 0.06);
  },
});

// ================================================================= 002 RAIOS AZUIS
function bolt(x1, y1, x2, y2, spread, out, depth = 0) {
  const pts = [[x1, y1]];
  const n = 9, dx = (x2 - x1) / n, dy = (y2 - y1) / n;
  for (let i = 1; i < n; i++) pts.push([x1 + dx * i + rand(-spread, spread), y1 + dy * i + rand(-spread * 0.4, spread * 0.4)]);
  pts.push([x2, y2]);
  out.push(pts);
  if (depth < 2) for (let i = 2; i < n - 1; i++) if (Math.random() < 0.28) { const [bx, by] = pts[i]; bolt(bx, by, bx + rand(-1, 1) * (y2 - y1) * 0.35, by + rand(0.15, 0.5) * (y2 - y1), spread * 0.6, out, depth + 1); }
}
registerAnimation('raios', {
  title: 'VITÓRIA!', duration: 4400,
  setup: () => ({ bolts: [], next: 0, flash: 0, sparks: [] }),
  draw(env, s, t, dt) {
    const { ctx, w, h, q } = env;
    const k = fadeInOut(t, 4400, 250, 900);
    blend(ctx, 'source-over'); ctx.fillStyle = `rgba(2,10,40,${0.6 * k})`; ctx.fillRect(0, 0, w, h);
    if (t >= s.next && t < 3700) {
      const segs = []; const x = rand(w * 0.15, w * 0.85), ex = x + rand(-w * 0.18, w * 0.18), ey = rand(h * 0.55, h * 0.92);
      bolt(x, -10, ex, ey, h * 0.05, segs);
      s.bolts.push({ segs, born: t, life: rand(240, 340) }); s.flash = 1; s.next = t + rand(380, 620);
      emit(s.sparks, Math.round(26 * q), () => { const a = rand(0, TAU), v = rand(80, 420); return { x: ex, y: ey, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 60, life: 0, max: rand(0.4, 0.9), size: rand(4, 10), sprite: glow('rgba(130,200,255,1)'), grav: 500, drag: 2 }; });
    }
    if (s.flash > 0) { blend(ctx, 'lighter'); ctx.fillStyle = `rgba(130,180,255,${0.26 * s.flash})`; ctx.fillRect(0, 0, w, h); s.flash = Math.max(0, s.flash - dt * 6); }
    ctx.lineJoin = 'round'; ctx.lineCap = 'round'; blend(ctx, 'lighter');
    for (let i = s.bolts.length - 1; i >= 0; i--) {
      const b = s.bolts[i], age = t - b.born;
      if (age > b.life) { s.bolts.splice(i, 1); continue; }
      const a = (1 - age / b.life) * (Math.random() < 0.25 ? 0.45 : 1);
      for (const [lw, col, al] of [[12, 'rgb(30,110,255)', 0.28], [4.5, 'rgb(120,190,255)', 0.8], [1.8, 'rgb(255,255,255)', 1]]) {
        ctx.strokeStyle = col; ctx.lineWidth = lw; ctx.globalAlpha = a * al;
        for (const pts of b.segs) { ctx.beginPath(); ctx.moveTo(pts[0][0], pts[0][1]); for (let j = 1; j < pts.length; j++) ctx.lineTo(pts[j][0], pts[j][1]); ctx.stroke(); }
      }
    }
    ctx.globalAlpha = 1;
    stepDraw(ctx, s.sparks, dt, { grav: 500, drag: 2 });
    blend(ctx, 'source-over');
  },
  sound(a) {
    for (let i = 0; i < 6; i++) {
      const at = i * 0.5;
      a.noise(at, 0.12, { type: 'highpass', f0: 1800, vol: 0.9 }); a.tone(2400, at, 0.18, 'sawtooth', 0.25, 0.002, 160);
      a.noise(at + 0.08, 1.1, { type: 'lowpass', f0: 420, f1: 60, vol: 0.9 }); a.tone(70, at + 0.05, 0.9, 'sine', 0.5, 0.01, 35);
    }
  },
});

// ================================================================= 003 CORO A DE CAMPEÃO (cinematográfica)
function crown(ctx, cx, cy, S, shine) {
  const bw = S * 1.5, bh = S * 0.34, top = cy - S * 0.62, base = cy + S * 0.16;
  ctx.save(); ctx.translate(cx, cy);
  const grd = ctx.createLinearGradient(0, -S * 0.7, 0, S * 0.35);
  grd.addColorStop(0, '#fff1a8'); grd.addColorStop(0.45, '#f5b82e'); grd.addColorStop(1, '#a8660a');
  ctx.fillStyle = grd; ctx.strokeStyle = '#7a4a05'; ctx.lineWidth = Math.max(2, S * 0.025); ctx.lineJoin = 'round';
  const x0 = -bw / 2, y0 = base - cy, yT = top - cy;
  ctx.beginPath();
  ctx.moveTo(x0, y0); ctx.lineTo(x0 - S * 0.06, yT + S * 0.12);
  ctx.lineTo(x0 + bw * 0.2, y0 - bh * 1.4); ctx.lineTo(x0 + bw * 0.3, yT - S * 0.02);
  ctx.lineTo(x0 + bw * 0.5, y0 - bh * 1.7); ctx.lineTo(x0 + bw * 0.7, yT - S * 0.02);
  ctx.lineTo(x0 + bw * 0.8, y0 - bh * 1.4); ctx.lineTo(x0 + bw + S * 0.06, yT + S * 0.12);
  ctx.lineTo(x0 + bw, y0); ctx.closePath(); ctx.fill(); ctx.stroke();
  // faixa inferior
  ctx.fillStyle = '#d9971b'; ctx.beginPath(); ctx.roundRect(x0, y0 - bh * 0.15, bw, bh, S * 0.06); ctx.fill(); ctx.stroke();
  // joias
  const jewels = [[x0 + bw * 0.2, y0 + bh * 0.3, '#ff4d6d'], [x0 + bw * 0.5, y0 + bh * 0.3, '#4dd2ff'], [x0 + bw * 0.8, y0 + bh * 0.3, '#7dff9a']];
  for (const [jx, jy, jc] of jewels) { ctx.fillStyle = jc; ctx.beginPath(); ctx.arc(jx, jy, S * 0.07, 0, TAU); ctx.fill(); ctx.stroke(); }
  for (const [px, py] of [[x0 - S * 0.06, yT + S * 0.12], [x0 + bw * 0.3, yT - S * 0.02], [x0 + bw * 0.7, yT - S * 0.02], [x0 + bw + S * 0.06, yT + S * 0.12]]) { ctx.fillStyle = '#fff6c9'; ctx.beginPath(); ctx.arc(px, py - S * 0.02, S * 0.055, 0, TAU); ctx.fill(); ctx.stroke(); }
  ctx.fillStyle = '#fff6c9'; ctx.beginPath(); ctx.arc(x0 + bw * 0.5, y0 - bh * 1.7 - S * 0.03, S * 0.07, 0, TAU); ctx.fill(); ctx.stroke();
  // brilho que atravessa a coroa
  if (shine > 0 && shine < 1) { ctx.globalCompositeOperation = 'source-atop'; const sx = x0 + (bw + S * 0.4) * shine - S * 0.2; const sg = ctx.createLinearGradient(sx - S * 0.18, 0, sx + S * 0.18, 0); sg.addColorStop(0, 'rgba(255,255,255,0)'); sg.addColorStop(0.5, 'rgba(255,255,255,.85)'); sg.addColorStop(1, 'rgba(255,255,255,0)'); ctx.fillStyle = sg; ctx.fillRect(x0 - S * 0.2, yT - S * 0.2, bw + S * 0.4, S * 1.2); }
  ctx.restore();
}
registerAnimation('coroa', {
  title: 'CAMPEÃO', duration: 5600, cinematic: true,
  setup: () => ({ motes: [] }),
  draw(env, s, t, dt) {
    const { ctx, w, h, cx, cy, q } = env;
    const k = fadeInOut(t, 5600, 500, 900);
    blend(ctx, 'source-over'); ctx.fillStyle = `rgba(4,3,10,${0.82 * k})`; ctx.fillRect(0, 0, w, h);
    const S = Math.min(w, h) * 0.34;
    const ky = cy - Math.min(w, h) * 0.12;
    // feixe de luz do alto
    blend(ctx, 'lighter'); const sp = ctx.createRadialGradient(cx, -h * 0.1, 10, cx, ky, h * 0.9); sp.addColorStop(0, `rgba(255,222,140,${0.55 * k})`); sp.addColorStop(0.5, `rgba(255,190,80,${0.16 * k})`); sp.addColorStop(1, 'rgba(255,190,80,0)'); ctx.fillStyle = sp; ctx.fillRect(0, 0, w, h);
    // raios giratórios atrás da coroa
    const rayK = clamp01((t - 700) / 900) * k; ctx.save(); ctx.translate(cx, ky); ctx.rotate(t / 4200); ctx.globalAlpha = 0.17 * rayK; ctx.fillStyle = 'rgb(255,214,120)';
    for (let i = 0; i < 14; i++) { ctx.rotate(TAU / 14); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(h, -h * 0.06); ctx.lineTo(h, h * 0.06); ctx.closePath(); ctx.fill(); } ctx.restore(); ctx.globalAlpha = 1;
    // poeira de luz
    if (Math.random() < 0.7 * q) emit(s.motes, 1, () => ({ x: rand(0, w), y: h + 10, vx: rand(-10, 10), vy: rand(-70, -25), life: 0, max: rand(3, 5), size: rand(2, 6), sprite: glow(GOLD_L), alpha: 0.7 }));
    stepDraw(ctx, s.motes, dt, {});
    blend(ctx, 'source-over');
    // coroa: desce e assenta, com leve flutuação
    const enter = ease.back(clamp01((t - 500) / 1500)), a = clamp01((t - 400) / 700);
    const y = ky - (1 - ease.out(clamp01((t - 500) / 1500))) * h * 0.45 + Math.sin(t / 600) * S * 0.015;
    ctx.globalAlpha = a * k; ctx.save(); ctx.translate(cx, y); ctx.scale(0.55 + 0.45 * enter, 0.55 + 0.45 * enter); ctx.rotate((1 - enter) * -0.25); ctx.translate(-cx, -y);
    crown(ctx, cx, y, S, (t - 2100) / 1100); ctx.restore(); ctx.globalAlpha = 1;
    // clarão do pouso
    if (t > 1900 && t < 2600) { blend(ctx, 'lighter'); ctx.globalAlpha = (1 - (t - 1900) / 700) * 0.7; const r = S * 1.6; ctx.drawImage(glow(GOLD_L), cx - r, ky - r, r * 2, r * 2); ctx.globalAlpha = 1; blend(ctx, 'source-over'); }
  },
  sound(a) {
    a.tone(note(36), 0, 2.6, 'sawtooth', 0.12, 1.2); a.tone(note(43), 0, 2.6, 'sawtooth', 0.1, 1.2); a.tone(note(48), 0.2, 2.8, 'triangle', 0.2, 1.4); a.tone(note(52), 0.2, 2.8, 'triangle', 0.18, 1.4); a.tone(note(55), 0.2, 2.8, 'triangle', 0.18, 1.4);
    a.tone(110, 1.9, 0.9, 'sine', 0.9, 0.005, 38); a.noise(1.9, 0.6, { type: 'lowpass', f0: 1500, f1: 120, vol: 0.5 });
    [84, 88, 91, 96].forEach((n, i) => a.tone(note(n), 2.1 + i * 0.12, 1.4, 'sine', 0.22));
  },
});

// ================================================================= 004 EXPLOSÃO DE FOGO
const FIRE = ['rgba(255,250,200,1)', 'rgba(255,190,50,1)', 'rgba(255,100,20,1)', 'rgba(150,30,10,1)'];
registerAnimation('fogo', {
  title: 'VITÓRIA!', duration: 4400,
  setup: () => ({ p: [], embers: [], boom: false }),
  draw(env, s, t, dt) {
    const { ctx, w, h, cx, q } = env;
    const k = fadeInOut(t, 4400, 200, 900);
    const mk = (x, y, vx, vy, max, size, col) => ({ x, y, vx, vy, life: 0, max, size, sprite: glow(col), drag: 0.6 });
    if (!s.boom) { s.boom = true; emit(s.p, Math.round(170 * q), () => { const a = rand(-Math.PI * 0.95, -Math.PI * 0.05), v = rand(250, 1100); return mk(cx + rand(-30, 30), h, Math.cos(a) * v, Math.sin(a) * v, rand(0.7, 1.6), rand(26, 60), FIRE[(Math.random() * 3) | 0]); }); }
    if (t < 3400) emit(s.p, Math.round(7 * q * (dt * 60)), () => mk(rand(0, w), h + 10, rand(-40, 40), rand(-420, -160) * (1 + 0.5 * Math.sin(t / 500)), rand(0.8, 1.5), rand(24, 54), FIRE[(Math.random() * 3) | 0]));
    if (t < 3600 && Math.random() < 0.8 * q) emit(s.embers, 2, () => ({ x: rand(0, w), y: h, vx: rand(-60, 60), vy: rand(-520, -200), life: 0, max: rand(1.4, 2.6), size: rand(2, 5), sprite: glow('rgba(255,210,90,1)'), drag: 0.1 }));
    blend(ctx, 'source-over');
    const bg = ctx.createLinearGradient(0, h, 0, h * 0.2); bg.addColorStop(0, `rgba(255,70,10,${0.5 * k})`); bg.addColorStop(0.5, `rgba(120,20,5,${0.28 * k})`); bg.addColorStop(1, 'rgba(0,0,0,0)'); ctx.fillStyle = bg; ctx.fillRect(0, 0, w, h);
    blend(ctx, 'lighter');
    // cor muda com a idade: branco-amarelo → laranja → vermelho
    for (let i = s.p.length - 1; i >= 0; i--) { const p = s.p[i], a = p.life / p.max; p.sprite = glow(FIRE[Math.min(3, (a * 4) | 0)]); p.vx += Math.sin(p.y / 60 + p.x) * 30 * dt; }
    stepDraw(ctx, s.p, dt, { grav: -90, drag: 0.6, grow: -0.2 });
    stepDraw(ctx, s.embers, dt, { grav: -30, drag: 0.1 });
    blend(ctx, 'source-over');
  },
  sound(a) {
    a.tone(80, 0, 0.9, 'sine', 1, 0.005, 30); a.noise(0, 0.9, { type: 'lowpass', f0: 3000, f1: 150, vol: 1 });
    a.noise(0.1, 2.6, { type: 'bandpass', f0: 300, f1: 1500, q: 0.6, vol: 0.3, attack: 0.6 });
    for (let i = 0; i < 18; i++) a.noise(0.5 + Math.random() * 2.8, 0.05, { type: 'highpass', f0: 3000, vol: 0.5 });
  },
});

// ================================================================= 005 ESPACIAL
registerAnimation('cosmos', {
  title: 'VITÓRIA!', duration: 4800,
  setup: (env) => ({ stars: Array.from({ length: Math.round(260 * env.q) }, () => ({ a: rand(0, TAU), r: rand(0, 1), z: rand(0.2, 1) })), rings: [], nextRing: 0, shoot: [], neb: [[0.3, 0.35, 'rgba(140,80,255,1)'], [0.72, 0.6, 'rgba(60,140,255,1)'], [0.5, 0.2, 'rgba(255,90,200,1)']] }),
  draw(env, s, t, dt) {
    const { ctx, w, h, cx, cy, q } = env;
    const k = fadeInOut(t, 4800, 400, 1000), D = Math.hypot(w, h) / 2;
    blend(ctx, 'source-over'); ctx.fillStyle = `rgba(3,3,22,${0.78 * k})`; ctx.fillRect(0, 0, w, h);
    blend(ctx, 'lighter');
    s.neb.forEach(([nx, ny, col], i) => { const r = Math.min(w, h) * (0.55 + 0.08 * Math.sin(t / 900 + i)); ctx.globalAlpha = 0.33 * k; ctx.drawImage(glow(col), w * nx + Math.sin(t / 1500 + i * 2) * 40 - r, h * ny + Math.cos(t / 1300 + i) * 30 - r, r * 2, r * 2); });
    ctx.globalAlpha = 1;
    // estrelas em velocidade de dobra
    const speed = 0.25 + ease.inOut(clamp01(t / 2500)) * 2.4; ctx.lineCap = 'round';
    for (const st of s.stars) {
      const r0 = st.r; st.r += dt * speed * (0.3 + st.z) * (0.2 + st.r * 1.6); if (st.r > 1.05) { st.r = rand(0, 0.08); st.a = rand(0, TAU); st.z = rand(0.2, 1); }
      const x1 = cx + Math.cos(st.a) * st.r * D, y1 = cy + Math.sin(st.a) * st.r * D, x0 = cx + Math.cos(st.a) * r0 * D, y0 = cy + Math.sin(st.a) * r0 * D;
      ctx.strokeStyle = st.z > 0.7 ? 'rgba(200,225,255,.95)' : 'rgba(170,150,255,.8)'; ctx.globalAlpha = Math.min(1, st.r * 2) * k; ctx.lineWidth = 0.6 + st.z * 1.8 * Math.min(1.5, st.r * 2);
      ctx.beginPath(); ctx.moveTo(x0 - (x1 - x0) * 2 * speed * 0.3, y0 - (y1 - y0) * 2 * speed * 0.3); ctx.lineTo(x1, y1); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    // anéis de energia
    if (t >= s.nextRing && t < 3800) { s.rings.push({ born: t, col: s.rings.length % 2 ? 'rgb(120,220,255)' : 'rgb(190,120,255)' }); s.nextRing = t + 650; }
    for (let i = s.rings.length - 1; i >= 0; i--) { const r = s.rings[i], a = (t - r.born) / 1900; if (a >= 1) { s.rings.splice(i, 1); continue; } ctx.globalAlpha = (1 - a) * 0.8; ctx.strokeStyle = r.col; ctx.lineWidth = 6 * (1 - a) + 1; ctx.beginPath(); ctx.arc(cx, cy, ease.out(a) * D * 0.85, 0, TAU); ctx.stroke(); }
    ctx.globalAlpha = 1;
    // estrelas cadentes
    if (Math.random() < 0.025 * q * (dt * 60)) s.shoot.push({ x: rand(w * 0.3, w), y: rand(0, h * 0.4), vx: -rand(700, 1100), vy: rand(300, 500), life: 0, max: 0.7 });
    for (let i = s.shoot.length - 1; i >= 0; i--) { const m = s.shoot[i]; m.life += dt; if (m.life > m.max) { s.shoot.splice(i, 1); continue; } m.x += m.vx * dt; m.y += m.vy * dt; const g = ctx.createLinearGradient(m.x, m.y, m.x - m.vx * 0.18, m.y - m.vy * 0.18); g.addColorStop(0, 'rgba(255,255,255,.95)'); g.addColorStop(1, 'rgba(120,180,255,0)'); ctx.strokeStyle = g; ctx.lineWidth = 2.5; ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.x - m.vx * 0.18, m.y - m.vy * 0.18); ctx.stroke(); }
    // núcleo de energia atrás do texto
    const pr = Math.min(w, h) * (0.3 + 0.03 * Math.sin(t / 220)); ctx.globalAlpha = 0.55 * k; ctx.drawImage(glow('rgba(150,170,255,1)'), cx - pr, cy - pr, pr * 2, pr * 2); ctx.globalAlpha = 1;
    blend(ctx, 'source-over');
  },
  sound(a) {
    a.tone(90, 0, 2.6, 'sine', 0.5, 1.4, 700); a.tone(135, 0, 2.6, 'triangle', 0.18, 1.4, 1050);
    a.noise(0, 2.6, { type: 'bandpass', f0: 200, f1: 3500, q: 1.2, vol: 0.25, attack: 1.4 });
    a.tone(note(60), 2.4, 2, 'sine', 0.28, 0.3); a.tone(note(67), 2.4, 2, 'sine', 0.22, 0.3); a.tone(note(72), 2.4, 2, 'sine', 0.2, 0.3);
    for (let i = 0; i < 10; i++) a.tone(note(84 + [0, 3, 7, 10][i % 4] + (i > 5 ? 12 : 0)), 2.5 + i * 0.13, 0.5, 'sine', 0.1);
  },
});

// ================================================================= 006 GLITCH NEON
const NEON = ['rgba(0,255,240,1)', 'rgba(255,0,200,1)', 'rgba(190,255,0,1)', 'rgba(120,80,255,1)'];
let scan = null;
registerAnimation('glitch', {
  title: 'VITÓRIA!', duration: 4000,
  setup: () => { if (!scan) { scan = document.createElement('canvas'); scan.width = 4; scan.height = 4; const g = scan.getContext('2d'); g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(0, 2, 4, 2); } return { rects: [], inv: 0 }; },
  draw(env, s, t, dt) {
    const { ctx, w, h, q } = env;
    const k = fadeInOut(t, 4000, 200, 500);
    blend(ctx, 'source-over'); ctx.fillStyle = `rgba(2,0,14,${0.68 * k})`; ctx.fillRect(0, 0, w, h);
    // grade neon
    ctx.strokeStyle = 'rgba(0,255,240,.12)'; ctx.lineWidth = 1; ctx.beginPath(); const off = (t / 40) % 60; for (let x = -off; x < w; x += 60) { ctx.moveTo(x, 0); ctx.lineTo(x, h); } for (let y = off; y < h; y += 60) { ctx.moveTo(0, y); ctx.lineTo(w, y); } ctx.stroke();
    // blocos e fatias de glitch
    const nSpawn = Math.round((1 + Math.random() * 3) * q); for (let i = 0; i < nSpawn; i++) { const full = Math.random() < 0.2; s.rects.push({ x: full ? 0 : rand(-40, w), y: rand(0, h), w: full ? w : rand(40, 420), h: full ? rand(2, 14) : rand(4, 38), c: NEON[(Math.random() * NEON.length) | 0], life: 0, max: rand(0.06, 0.22), dx: rand(-30, 30) }); }
    blend(ctx, 'lighter');
    for (let i = s.rects.length - 1; i >= 0; i--) { const r = s.rects[i]; r.life += dt; if (r.life > r.max) { s.rects.splice(i, 1); continue; } ctx.globalAlpha = (1 - r.life / r.max) * 0.55 * k; ctx.fillStyle = r.c; ctx.fillRect(r.x + r.dx * (r.life / r.max), r.y, r.w, r.h); }
    // separação RGB em linhas verticais
    ctx.globalAlpha = 0.5 * k; for (let i = 0; i < 3 * q; i++) { const x = rand(0, w); ctx.fillStyle = 'rgba(255,0,60,1)'; ctx.fillRect(x - 3, 0, 2, h); ctx.fillStyle = 'rgba(0,200,255,1)'; ctx.fillRect(x + 3, 0, 2, h); }
    ctx.globalAlpha = 1;
    if (Math.random() < 0.012 * (dt * 60) && s.inv <= 0) s.inv = 0.07; if (s.inv > 0) { ctx.fillStyle = 'rgba(255,255,255,.22)'; ctx.fillRect(0, 0, w, h); s.inv -= dt; }
    blend(ctx, 'source-over'); ctx.fillStyle = ctx.createPattern(scan, 'repeat'); ctx.globalAlpha = k; ctx.fillRect(0, 0, w, h); ctx.globalAlpha = 1;
  },
  sound(a) {
    for (let i = 0; i < 26; i++) a.tone(rand(120, 1800), i * 0.1 + Math.random() * 0.05, 0.06, 'square', 0.12);
    for (let i = 0; i < 9; i++) a.noise(i * 0.4, 0.09, { type: 'bandpass', f0: rand(800, 5000), q: 4, vol: 0.5 });
    a.tone(800, 0.1, 1.2, 'sawtooth', 0.12, 0.01, 60); a.tone(note(60), 2.2, 1.4, 'square', 0.12, 0.02); a.tone(note(67), 2.2, 1.4, 'square', 0.1, 0.02);
  },
});

// ================================================================= 007 AURA LENDÁRIA
registerAnimation('aura', {
  title: 'VITÓRIA!', duration: 5000,
  setup: () => ({ orbs: [], rings: [], nextRing: 0 }),
  draw(env, s, t, dt) {
    const { ctx, w, h, cx, cy, q } = env;
    const k = fadeInOut(t, 5000, 500, 1000), M = Math.min(w, h);
    blend(ctx, 'source-over'); ctx.fillStyle = `rgba(8,4,24,${0.62 * k})`; ctx.fillRect(0, 0, w, h);
    blend(ctx, 'lighter');
    // aura pulsante em duas camadas
    const pulse = 1 + 0.08 * Math.sin(t / 260);
    for (const [col, sz, al] of [['rgba(150,90,255,1)', 1.25, 0.5], ['rgba(255,225,150,1)', 0.8, 0.55], ['rgba(255,255,255,1)', 0.38, 0.5]]) { const r = M * sz * pulse * (0.6 + 0.4 * ease.out(clamp01(t / 1400))); ctx.globalAlpha = al * k; ctx.drawImage(glow(col), cx - r, cy - r, r * 2, r * 2); }
    ctx.globalAlpha = 1;
    // colunas de luz
    for (let i = -2; i <= 2; i++) { const x = cx + i * M * 0.22, gw = M * (0.05 + 0.03 * Math.sin(t / 400 + i)), g = ctx.createLinearGradient(0, h, 0, 0); g.addColorStop(0, 'rgba(255,230,160,.0)'); g.addColorStop(0.35, `rgba(255,230,160,${0.2 * k * (1 - Math.abs(i) * 0.25)})`); g.addColorStop(1, 'rgba(255,230,160,0)'); ctx.fillStyle = g; ctx.fillRect(x - gw, 0, gw * 2, h); }
    // ondas de luz
    if (t >= s.nextRing && t < 4000) { s.rings.push(t); s.nextRing = t + 800; }
    for (let i = s.rings.length - 1; i >= 0; i--) { const a = (t - s.rings[i]) / 2200; if (a >= 1) { s.rings.splice(i, 1); continue; } ctx.globalAlpha = (1 - a) * 0.7; ctx.strokeStyle = 'rgb(255,235,180)'; ctx.lineWidth = 3 + 5 * (1 - a); ctx.beginPath(); ctx.arc(cx, cy, ease.out(a) * M * 0.75, 0, TAU); ctx.stroke(); }
    ctx.globalAlpha = 1;
    // partículas brilhantes em espiral subindo
    if (t < 4200) emit(s.orbs, Math.round(4 * q * (dt * 60)), () => ({ ang: rand(0, TAU), rad: rand(M * 0.05, M * 0.3), y: cy + rand(-M * 0.05, M * 0.3), vy: rand(60, 220), w: rand(0.6, 1.8) * (Math.random() < 0.5 ? -1 : 1), life: 0, max: rand(1.6, 3), size: rand(3, 9), sprite: glow([GOLD_L, 'rgba(200,160,255,1)', WHITE][(Math.random() * 3) | 0]) }));
    for (let i = s.orbs.length - 1; i >= 0; i--) {
      const o = s.orbs[i]; o.life += dt; if (o.life >= o.max) { s.orbs[i] = s.orbs[s.orbs.length - 1]; s.orbs.pop(); continue; }
      o.ang += o.w * dt; o.y -= o.vy * dt; o.rad += 18 * dt; const a = o.life / o.max, x = cx + Math.cos(o.ang) * o.rad * 1.4, sz = o.size * (1 - a * 0.4);
      ctx.globalAlpha = Math.sin(a * Math.PI) * k; ctx.drawImage(o.sprite, x - sz, o.y - sz, sz * 2, sz * 2);
    }
    ctx.globalAlpha = 1; blend(ctx, 'source-over');
  },
  sound(a) {
    [48, 55, 60, 64, 67, 72].forEach((n, i) => { a.tone(note(n), i * 0.08, 3.4, 'sine', 0.17, 1.1); a.tone(note(n), i * 0.08, 3.4, 'sine', 0.1, 1.2, null, 8); });
    [84, 88, 91, 96, 100].forEach((n, i) => { a.tone(note(n), 0.9 + i * 0.22, 1.5, 'sine', 0.16); a.tone(note(n + 12), 0.9 + i * 0.22, 0.9, 'sine', 0.06); });
    a.noise(0.2, 2.8, { type: 'highpass', f0: 4500, vol: 0.05, attack: 1.2 });
  },
});
