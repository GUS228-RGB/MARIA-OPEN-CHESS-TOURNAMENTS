// Detecta vitórias a partir do estado compartilhado (S.games) e dispara a animação certa.
// A animação sai do servidor (S.players[].anim): o navegador nunca decide qual animação um jogador "merece".
import { h, openDialog, toast } from '../dom.js';
import { S, subscribe, api } from '../net.js';
import './effects.js';
import { playVictory, prefs, stopVictory } from './engine.js';

let catalog = null;
export async function loadCatalog() {
  if (catalog) return catalog;
  try { catalog = (await api('GET', '/api/animations')).animations; } catch (_) { catalog = [{ id: 'padrao', num: null, nome: 'Padrão (troféu)' }]; }
  S.animCatalog = catalog;
  return catalog;
}

const known = new Map();      // id da partida -> último estado visto
let baseline = false, queue = [];
const shown = (id) => { try { return sessionStorage.getItem('oc.vic.' + id) === '1'; } catch (_) { return false; } };
const markShown = (id) => { try { sessionStorage.setItem('oc.vic.' + id, '1'); } catch (_) { /* ok */ } };

function viewingGame() { const m = /^#\/(?:jogo)\/(\d+)/.exec(location.hash); return m ? Number(m[1]) : null; }

function shouldPlay(g, winnerId) {
  const me = S.me && S.me.player ? S.me.player.id : null;
  if (me != null && me === winnerId) return true;                      // o vencedor sempre vê a sua vitória
  const isPlayer = me != null && (g.white_id === me || g.black_id === me);
  if (isPlayer) return false;                                          // o derrotado não vê animação de vitória do adversário
  if (prefs.telao) return true;                                        // modo telão
  return prefs.others && viewingGame() === g.id;                       // espectador olhando aquela partida
}

function check() {
  if (!S.loaded) return;
  const cur = new Map();
  for (const g of S.games) {
    cur.set(g.id, g.state);
    if (!baseline) continue;
    const prev = known.get(g.id);
    if (prev && prev !== 'finished' && g.state === 'finished' && g.black_id != null && (g.result === '1-0' || g.result === '0-1') && !shown(g.id)) {
      const winnerId = g.result === '1-0' ? g.white_id : g.black_id;
      if (shouldPlay(g, winnerId)) queue.push({ id: g.id, winnerId });
    }
  }
  for (const [id, st] of cur) known.set(id, st);
  baseline = true;
  flush();
}

function flush() {
  if (!queue.length || document.hidden || !prefs.on) { if (!prefs.on) queue = []; return; }
  const { id, winnerId } = queue.shift();
  markShown(id);
  const p = S.players.find((x) => x.id === winnerId);
  playVictory({ animation: (p && p.anim) || 'padrao', name: p ? p.name : '', onEnd: flush });
}

export function initVictories() {
  subscribe(check);
  loadCatalog().then(() => window.dispatchEvent(new Event('oc-rerender')));
  document.addEventListener('visibilitychange', () => { if (!document.hidden) flush(); });
}

/** Janela "Efeitos": liga/desliga animações e sons, modo telão e pré-visualização de qualquer animação. */
export async function openEffectsDialog() {
  const cat = await loadCatalog();
  const chk = (key, label, hint) => {
    const input = h('input', { type: 'checkbox', id: 'fx-' + key, checked: prefs[key] });
    input.addEventListener('change', () => { prefs[key] = input.checked; if (key === 'on' && !input.checked) stopVictory(); });
    return h('div', { class: 'field' }, h('label', { class: 'check', for: 'fx-' + key }, input, label), hint && h('div', { class: 'hint' }, hint));
  };
  const sel = h('select', { id: 'fx-test', 'aria-label': 'Animação para testar' }, cat.map((a) => h('option', { value: a.id }, (a.num ? `<${a.num}> ` : '') + a.nome)));
  openDialog({
    title: 'Efeitos de vitória',
    build(body, close) {
      body.append(
        chk('on', 'Animações de vitória', 'Tocam só quando alguém vence uma partida, nunca em derrota ou empate. Não alteram o jogo.'),
        chk('sound', 'Efeitos sonoros', 'Sons sintetizados no seu aparelho. Alguns navegadores só liberam o som depois de um toque na tela.'),
        chk('others', 'Ver vitórias de quem eu assisto', 'Ao acompanhar uma partida de outras pessoas, mostra a animação do vencedor.'),
        chk('telao', 'Modo telão', 'Mostra a animação de todas as vitórias do torneio nesta tela (bom para um projetor ou TV).'),
        h('div', { class: 'field' }, h('label', { for: 'fx-test' }, 'Testar uma animação'), h('div', { class: 'row' }, sel,
          h('button', { class: 'btn primary', type: 'button', onclick: () => { close(null); setTimeout(() => playVictory({ animation: sel.value, name: (S.me && S.me.player.name) || 'Seu nome', force: true }), 150); } }, '▶ Testar'))));
    },
    actions: [{ label: 'Fechar', onClick: (c) => c(null) }],
  });
}

/** Nome legível de uma animação (catálogo já carregado). */
export function previewFromCatalog(id) { const a = (S.animCatalog || []).find((x) => x.id === id); return a ? a.nome : id; }
export function animName(id) { return previewFromCatalog(id); }
