// Efeitos sonoros sintetizados com Web Audio (nenhum arquivo de áudio: nada para baixar e funciona offline).
let ctx = null;
export function audioCtx() {
  if (ctx) return ctx;
  try { const AC = window.AudioContext || window.webkitAudioContext; if (AC) ctx = new AC(); } catch (_) { ctx = null; }
  return ctx;
}

/** Cria o "palco" de som de uma animação. Todos os métodos são seguros se o áudio estiver indisponível/bloqueado. */
export function makeAudio(volume = 0.22) {
  const c = audioCtx();
  if (!c) return null;
  try { if (c.state === 'suspended') c.resume(); } catch (_) { /* bloqueado até haver toque do usuário */ }
  const master = c.createGain(); master.gain.value = volume;
  const comp = c.createDynamicsCompressor();
  master.connect(comp); comp.connect(c.destination);
  const t0 = c.currentTime + 0.03;
  const nodes = [];
  const keep = (n) => { nodes.push(n); return n; };
  const noiseBuf = (() => { const b = c.createBuffer(1, c.sampleRate * 1.5, c.sampleRate); const d = b.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; return b; })();
  const api = {
    now: () => t0,
    /** nota: freq (Hz), início (s), duração (s), tipo de onda, volume, ataque, deslizar até freq2 */
    tone(freq, at, dur, type = 'sine', vol = 0.4, attack = 0.01, freq2 = null, detune = 0) {
      const o = keep(c.createOscillator()), g = keep(c.createGain());
      o.type = type; o.frequency.setValueAtTime(freq, t0 + at); o.detune.value = detune;
      if (freq2) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq2), t0 + at + dur);
      g.gain.setValueAtTime(0.0001, t0 + at);
      g.gain.exponentialRampToValueAtTime(vol, t0 + at + attack);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + dur);
      o.connect(g); g.connect(master); o.start(t0 + at); o.stop(t0 + at + dur + 0.05);
    },
    /** rajada de ruído filtrado (explosões, trovões, chamas) */
    noise(at, dur, { type = 'lowpass', f0 = 800, f1 = null, q = 0.7, vol = 0.5, attack = 0.005 } = {}) {
      const s = keep(c.createBufferSource()), f = keep(c.createBiquadFilter()), g = keep(c.createGain());
      s.buffer = noiseBuf; f.type = type; f.Q.value = q; f.frequency.setValueAtTime(f0, t0 + at);
      if (f1) f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + at + dur);
      g.gain.setValueAtTime(0.0001, t0 + at); g.gain.exponentialRampToValueAtTime(vol, t0 + at + attack); g.gain.exponentialRampToValueAtTime(0.0001, t0 + at + dur);
      s.connect(f); f.connect(g); g.connect(master); s.start(t0 + at, Math.random()); s.stop(t0 + at + dur + 0.05);
    },
    stop() { try { master.gain.cancelScheduledValues(c.currentTime); master.gain.setTargetAtTime(0, c.currentTime, 0.05); } catch (_) { /* ok */ } setTimeout(() => { try { master.disconnect(); } catch (_) { /* ok */ } }, 400); },
  };
  return api;
}
export const note = (n) => 440 * 2 ** ((n - 69) / 12); // número MIDI → Hz
