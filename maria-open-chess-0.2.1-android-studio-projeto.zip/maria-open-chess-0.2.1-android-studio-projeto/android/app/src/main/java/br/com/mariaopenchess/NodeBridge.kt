package br.com.mariaopenchess

/** Ponte JNI para o Node.js (nodejs-mobile). Implementação em src/main/cpp/native-lib.cpp. */
class NodeBridge {
    /** Bloqueia até o Node terminar. [arguments] começa com "node", como em argv. */
    external fun startNodeWithArguments(arguments: Array<String>): Int

    companion object {
        init {
            System.loadLibrary("node")
            System.loadLibrary("native-lib")
        }
    }
}
