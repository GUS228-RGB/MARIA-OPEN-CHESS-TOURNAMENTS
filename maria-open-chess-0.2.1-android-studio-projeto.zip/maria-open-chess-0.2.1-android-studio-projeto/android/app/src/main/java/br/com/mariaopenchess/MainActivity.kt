package br.com.mariaopenchess

import android.Manifest
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Tela única: um WebView que mostra a interface do maria open CHESS servida pelo Node embutido
 * (http://localhost:PORTA/). Participantes entram pelo navegador deles; esta tela é do organizador.
 */
class MainActivity : ComponentActivity() {
    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private lateinit var overlay: LinearLayout
    private lateinit var overlayText: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var retry: Button

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var pageIsLocal = false
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCallback = null
    }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val finishReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { finishAndRemoveTask() }
    }

    /** Acompanha a cor de fundo da página (tema claro/escuro da interface) nas barras do sistema. */
    private val syncBars = object : Runnable {
        override fun run() {
            if (web.visibility == View.VISIBLE) {
                web.evaluateJavascript("(function(){return getComputedStyle(document.body).backgroundColor})()") { v ->
                    parseRgb(v)?.let { applyBarColor(it) }
                }
            }
            ui.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()
        ContextCompat.registerReceiver(this, finishReceiver, IntentFilter(NodeService.ACTION_FINISH_UI), ContextCompat.RECEIVER_NOT_EXPORTED)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.visibility == View.VISIBLE && web.canGoBack()) web.goBack() else moveTaskToBack(true)
            }
        })
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        startEverything()
    }

    override fun onStart() {
        super.onStart()
        ui.post(syncBars)
    }

    override fun onStop() {
        ui.removeCallbacks(syncBars)
        super.onStop()
    }

    override fun onDestroy() {
        try { unregisterReceiver(finishReceiver) } catch (_: Exception) { }
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        root.removeAllViews()
        web.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ início

    private fun startEverything() {
        showOverlay(getString(R.string.loading), retryVisible = false)
        try {
            ContextCompat.startForegroundService(this, Intent(this, NodeService::class.java))
        } catch (e: Exception) {
            Log.w(TAG, "Não foi possível iniciar o serviço em primeiro plano", e)
        }
        Thread {
            NodeRuntime.ensureStarted(applicationContext)
            val port = NodeRuntime.waitReady(applicationContext, 120_000)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (port != null) {
                    overlay.visibility = View.GONE
                    web.visibility = View.VISIBLE
                    web.loadUrl("http://localhost:$port/")
                } else {
                    showOverlay(NodeRuntime.errorText(applicationContext), retryVisible = true)
                }
            }
        }.start()
    }

    private fun showOverlay(text: String, retryVisible: Boolean) {
        root.setBackgroundColor(Color.parseColor(DARK_BG))
        web.visibility = View.INVISIBLE
        overlayText.text = text
        spinner.visibility = if (retryVisible) View.GONE else View.VISIBLE
        retry.visibility = if (retryVisible) View.VISIBLE else View.GONE
        overlay.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------------ interface

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.parseColor(DARK_BG)) }

        web = WebView(this).apply {
            visibility = View.INVISIBLE
            setBackgroundColor(Color.TRANSPARENT)
        }
        configureWebView()

        spinner = ProgressBar(this)
        overlayText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(16))
        }
        retry = Button(this).apply {
            text = getString(R.string.retry)
            visibility = View.GONE
            setOnClickListener { startEverything() }
        }
        overlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            addView(spinner)
            addView(overlayText)
            addView(retry)
        }

        root.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(overlay, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
    }

    private fun configureWebView() {
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportMultipleWindows(false) // target="_blank" abre na própria tela
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        web.addJavascriptInterface(AndroidBridge(), "OpenChessAndroid")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                val scheme = u.scheme ?: ""
                val host = u.host ?: ""
                if ((scheme == "http" || scheme == "https") && host in LOCAL_HOSTS) return false
                if (scheme == "http" || scheme == "https") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: ActivityNotFoundException) { }
                }
                return true // nunca navega para fora do servidor local dentro do WebView
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                pageIsLocal = (Uri.parse(url ?: "").host ?: "") in LOCAL_HOSTS
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                maybeAskBattery()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    showOverlay("Não foi possível carregar a tela (${error?.description}).", retryVisible = true)
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?
            ): Boolean {
                if (filePathCallback == null || fileChooserParams == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileChooser.launch(fileChooserParams.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onConsoleMessage(m: ConsoleMessage?): Boolean {
                if (BuildConfig.DEBUG && m != null) Log.d(TAG, "web: ${m.message()} (${m.sourceId()}:${m.lineNumber()})")
                return true
            }
        }

        web.setDownloadListener { url, _, contentDisposition, mime, _ ->
            Thread {
                val msg = try {
                    Downloads.saveFromUrl(applicationContext, url, contentDisposition, mime)
                } catch (e: Exception) {
                    Log.w(TAG, "download falhou", e)
                    getString(R.string.download_failed)
                }
                runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
            }.start()
        }
    }

    /** Ponte exposta à página como window.OpenChessAndroid (só para páginas do servidor local). */
    inner class AndroidBridge {
        @JavascriptInterface
        fun exportAll(): String {
            if (!pageIsLocal) return "ERRO: não permitido"
            return try {
                "OK: " + Downloads.exportAll(applicationContext)
            } catch (e: Exception) {
                "ERRO: " + (e.message ?: "não foi possível salvar")
            }
        }

        @JavascriptInterface
        fun quit() {
            if (!pageIsLocal) return
            startService(Intent(applicationContext, NodeService::class.java).setAction(NodeService.ACTION_QUIT))
        }
    }

    // ------------------------------------------------------------------ detalhes

    private fun applyBarColor(color: Int) {
        root.setBackgroundColor(color)
        val light = ColorUtils.calculateLuminance(color) > 0.5
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
    }

    private fun parseRgb(js: String?): Int? {
        val m = Regex("(\\d+)\\D+(\\d+)\\D+(\\d+)").find(js ?: return null) ?: return null
        val (r, g, b) = m.destructured
        return Color.rgb(r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), b.toInt().coerceIn(0, 255))
    }

    private fun maybeAskBattery() {
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        if (prefs.getBoolean("battery_asked", false)) return
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs.edit().putBoolean("battery_asked", true).apply()
        AlertDialog.Builder(this)
            .setTitle(R.string.battery_title)
            .setMessage(R.string.battery_message)
            .setPositiveButton(R.string.battery_open) { _, _ ->
                try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { }
            }
            .setNegativeButton(R.string.battery_later, null)
            .show()
    }

    companion object {
        private const val TAG = "MariaOpenChess"
        private const val DARK_BG = "#0E1116"
        private val LOCAL_HOSTS = setOf("localhost", "127.0.0.1")
    }
}
