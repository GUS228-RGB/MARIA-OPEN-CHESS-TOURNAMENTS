package br.com.mariaopenchess

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Fala com a tela do aplicativo (servidor Node em 127.0.0.1) a partir do lado nativo. */
object LauncherClient {
    fun state(ctx: Context): JSONObject? = request(ctx, "GET", "/api/launcher/state", 2000)

    /** Encerra a hospedagem com segurança (backup final). Retorna false se o servidor não respondeu. */
    fun stopHosting(ctx: Context): Boolean = request(ctx, "POST", "/api/launcher/stop", 20000) != null

    private fun request(ctx: Context, method: String, path: String, timeoutMs: Int): JSONObject? {
        val port = NodeRuntime.readPort(ctx) ?: return null
        var c: HttpURLConnection? = null
        return try {
            c = (URL("http://127.0.0.1:$port$path").openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                if (method == "POST") {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    outputStream.use { it.write("{}".toByteArray()) }
                }
            }
            if (c.responseCode != 200) null else JSONObject(c.inputStream.bufferedReader().readText())
        } catch (_: Exception) {
            null
        } finally {
            c?.disconnect()
        }
    }
}
