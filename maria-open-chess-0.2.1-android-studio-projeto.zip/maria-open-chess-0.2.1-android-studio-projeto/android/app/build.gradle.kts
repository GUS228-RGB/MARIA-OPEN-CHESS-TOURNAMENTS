import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Raiz do projeto maria open CHESS (onde ficam src/, web/ e package.json): a pasta acima de android/
val projectRootDir: File = rootProject.projectDir.parentFile
val appVersion: String = Regex("\"version\"\\s*:\\s*\"([^\"]+)\"")
    .find(File(projectRootDir, "package.json").readText())?.groupValues?.get(1) ?: "0.0.0"

val abis = listOf("arm64-v8a", "armeabi-v7a", "x86_64")

val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "br.com.mariaopenchess"
    compileSdk = 35

    defaultConfig {
        applicationId = "br.com.mariaopenchess"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = appVersion

        ndk { abiFilters += abis }
        externalNativeBuild {
            cmake {
                cppFlags += "-std=c++17"
                arguments += "-DANDROID_STL=c++_shared" // o libnode foi compilado com libc++
            }
        }
    }

    signingConfigs {
        if (keystoreProps.isNotEmpty()) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (keystoreProps.isNotEmpty()) signingConfig = signingConfigs.getByName("release")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    sourceSets["main"].apply {
        jniLibs.srcDirs("libnode/bin")                            // libnode.so de cada ABI
        assets.srcDir(layout.buildDirectory.dir("generated/nodeAssets")) // código Node.js (gerado abaixo)
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.3")
}

// ---- Verifica se os arquivos baixados por "node android/scripts/prepare.js" estão presentes
val checkRuntime = tasks.register("checkRuntime") {
    doLast {
        val missing = mutableListOf<String>()
        for (abi in abis) if (!file("libnode/bin/$abi/libnode.so").exists()) missing += "app/libnode/bin/$abi/libnode.so"
        if (!file("libnode/include/node/node.h").exists()) missing += "app/libnode/include/node/node.h"
        for (f in listOf("sql-wasm.js", "sql-wasm.wasm")) if (!File(rootProject.projectDir, "vendor/sql.js/$f").exists()) missing += "vendor/sql.js/$f"
        if (missing.isNotEmpty()) {
            throw GradleException(
                "Faltam arquivos do runtime:\n  " + missing.joinToString("\n  ") +
                    "\nRode antes (precisa de internet):  node android/scripts/prepare.js"
            )
        }
    }
}

// ---- Copia o código Node.js (src/, web/, package.json) e o sql.js para os assets do APK
val syncNodeProject = tasks.register<Sync>("syncNodeProject") {
    into(layout.buildDirectory.dir("generated/nodeAssets/nodejs-project"))
    from(File(projectRootDir, "src")) { into("src") }
    from(File(projectRootDir, "web")) { into("web") }
    from(File(projectRootDir, "package.json"))
    from(File(rootProject.projectDir, "vendor/sql.js")) { into("vendor/sql.js") }
    exclude("**/*.test.js")
}

tasks.named("preBuild") { dependsOn(checkRuntime, syncNodeProject) }
