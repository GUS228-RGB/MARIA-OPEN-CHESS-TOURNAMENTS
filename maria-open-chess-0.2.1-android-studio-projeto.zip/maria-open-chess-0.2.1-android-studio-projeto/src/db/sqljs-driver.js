'use strict';
/**
 * Adaptador com a mesma interface do node:sqlite que usamos (DatabaseSync, prepare().run/get/all, exec, backup)
 * sobre o sql.js. O banco vive na memória e é gravado em disco de forma atômica (arquivo temporário + rename):
 *  - ao concluir uma transação (COMMIT): gravação imediata e síncrona;
 *  - em escritas avulsas: gravação ao fim do ciclo atual do Node (coalescida);
 *  - ao fechar.
 * O módulo do sql.js precisa estar inicializado em globalThis.__OPEN_CHESS_SQLJS (ver src/mobile/main.js).
 */
const fs = require('node:fs');

function sqlModule() {
  const m = globalThis.__OPEN_CHESS_SQLJS;
  if (!m) throw new Error('O sql.js ainda não foi inicializado.');
  return m;
}

const norm = (v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : typeof v === 'bigint' ? Number(v) : v);

function writeAtomic(file, bytes) {
  const tmp = `${file}.tmp`;
  const fd = fs.openSync(tmp, 'w');
  try { fs.writeFileSync(fd, bytes); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  fs.renameSync(tmp, file);
}

class Statement {
  constructor(db, sql) { this._db = db; this._sql = sql; }

  _open(params) {
    this._db._assertOpen();
    const stmt = this._db._raw.prepare(this._sql);
    try { if (params.length) stmt.bind(params.map(norm)); } catch (e) { stmt.free(); throw e; }
    return stmt;
  }

  get(...params) {
    const stmt = this._open(params);
    try { return stmt.step() ? stmt.getAsObject() : undefined; } finally { stmt.free(); }
  }

  all(...params) {
    const stmt = this._open(params);
    try { const rows = []; while (stmt.step()) rows.push(stmt.getAsObject()); return rows; } finally { stmt.free(); }
  }

  run(...params) {
    const stmt = this._open(params);
    let changes = 0;
    try { stmt.step(); changes = this._db._raw.getRowsModified(); } finally { stmt.free(); }
    const last = this._db._raw.exec('SELECT last_insert_rowid()');
    this._db._wrote();
    return { changes, lastInsertRowid: last.length ? last[0].values[0][0] : 0 };
  }
}

class DatabaseSync {
  constructor(file, opts = {}) {
    const SQL = sqlModule();
    this.file = file;
    this.readOnly = !!opts.readOnly;
    this.memory = file === ':memory:';
    this._inTx = false;
    this._fk = false;
    this._scheduled = false;
    this._dirty = false;
    this._open = true;
    let data;
    if (!this.memory) {
      if (fs.existsSync(file)) data = fs.readFileSync(file);
      else if (this.readOnly) throw new Error('unable to open database file');
    }
    this._raw = new SQL.Database(data);
  }

  get isOpen() { return this._open; }

  _assertOpen() { if (!this._open) throw new Error('database is not open'); }

  exec(sql) {
    this._assertOpen();
    this._raw.run(sql);
    const s = String(sql);
    if (/foreign_keys\s*=\s*(on|1|true)/i.test(s)) this._fk = true;
    if (/^\s*BEGIN\b/i.test(s)) this._inTx = true;
    else if (/^\s*(COMMIT|END)\b/i.test(s)) { this._inTx = false; this._dirty = true; this.flush(); }
    else if (/^\s*ROLLBACK\s*;?\s*$/i.test(s)) this._inTx = false;
    else if (/^\s*(CREATE|DROP|ALTER|INSERT|UPDATE|DELETE|REPLACE|VACUUM)\b/i.test(s)) this._wrote();
  }

  prepare(sql) { this._assertOpen(); return new Statement(this, sql); }

  _wrote() {
    if (this.memory || this.readOnly) return;
    this._dirty = true;
    if (this._inTx || this._scheduled) return;
    this._scheduled = true;
    setImmediate(() => { this._scheduled = false; if (this._open) this.flush(); });
  }

  /** O export() do sql.js reabre o banco internamente: desliga foreign_keys e descarta transações abertas. */
  _bytes() {
    const bytes = this._raw.export();
    if (this._fk) this._raw.run('PRAGMA foreign_keys = ON;');
    return bytes;
  }

  flush() {
    if (this.memory || this.readOnly || !this._open || !this._dirty) return;
    if (this._inTx) return; // nunca exportar no meio de uma transação
    writeAtomic(this.file, this._bytes());
    this._dirty = false;
  }

  close() {
    if (!this._open) return;
    try { this.flush(); } finally { this._open = false; this._raw.close(); }
  }
}

/** Equivalente a backup() do node:sqlite: grava uma cópia consistente do banco. */
async function backup(db, dest) {
  db._assertOpen();
  const bytes = db._inTx ? (() => { throw new Error('backup durante uma transação'); })() : db._bytes();
  writeAtomic(dest, bytes);
  return bytes.length;
}

module.exports = { DatabaseSync, backup };
