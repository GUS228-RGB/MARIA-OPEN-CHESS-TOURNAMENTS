'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync, backup } = require('./driver');

const SCHEMA_VERSION = 1;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS tournament (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  modality TEXT NOT NULL CHECK (modality IN ('presencial','online','hibrido')),
  system TEXT NOT NULL CHECK (system IN ('suico','round_robin','eliminatoria_simples','eliminatoria_dupla')),
  rounds_total INTEGER,
  rr_double INTEGER NOT NULL DEFAULT 0,
  time_base_s INTEGER NOT NULL DEFAULT 600,
  time_inc_s INTEGER NOT NULL DEFAULT 0,
  pts_win REAL NOT NULL DEFAULT 1,
  pts_draw REAL NOT NULL DEFAULT 0.5,
  pts_loss REAL NOT NULL DEFAULT 0,
  bye_points REAL NOT NULL DEFAULT 1,
  max_players INTEGER NOT NULL,
  tables_count INTEGER NOT NULL DEFAULT 0,
  tiebreaks TEXT NOT NULL DEFAULT '["buchholz","sonneborn_berger","wins"]',
  status TEXT NOT NULL DEFAULT 'setup' CHECK (status IN ('setup','running','finished')),
  registration TEXT NOT NULL DEFAULT 'open' CHECK (registration IN ('open','paused','closed')),
  current_round INTEGER NOT NULL DEFAULT 0,
  admin_hash TEXT,
  created_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT
);

CREATE TABLE IF NOT EXISTS players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  number INTEGER NOT NULL UNIQUE,
  name TEXT NOT NULL,
  elo INTEGER,
  token_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','withdrawn')),
  seed INTEGER,
  joined_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS rounds (
  number INTEGER PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','running','finished')),
  created_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT
);

CREATE TABLE IF NOT EXISTS games (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  round INTEGER NOT NULL REFERENCES rounds(number),
  board INTEGER NOT NULL,
  white_id INTEGER NOT NULL REFERENCES players(id),
  black_id INTEGER REFERENCES players(id),
  kind TEXT NOT NULL CHECK (kind IN ('presencial','online')),
  table_no INTEGER,
  state TEXT NOT NULL DEFAULT 'waiting' CHECK (state IN ('waiting','playing','finished','postponed','cancelled')),
  result TEXT CHECK (result IN ('1-0','0-1','1/2-1/2','bye')),
  reason TEXT,
  bracket TEXT,
  replay_of INTEGER,
  fen TEXT,
  white_ms INTEGER,
  black_ms INTEGER,
  turn_started_at INTEGER,
  started_at TEXT,
  finished_at TEXT,
  CHECK (black_id IS NULL OR white_id != black_id),
  CHECK (black_id IS NOT NULL OR result IS NULL OR result = 'bye'),
  CHECK (result IS NOT 'bye' OR black_id IS NULL)
);
CREATE INDEX IF NOT EXISTS idx_games_round ON games(round);

CREATE TABLE IF NOT EXISTS moves (
  game_id INTEGER NOT NULL REFERENCES games(id),
  ply INTEGER NOT NULL,
  san TEXT NOT NULL,
  uci TEXT NOT NULL,
  fen TEXT NOT NULL,
  spent_ms INTEGER,
  PRIMARY KEY (game_id, ply)
);

CREATE TABLE IF NOT EXISTS imported_games (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tags TEXT NOT NULL,
  moves TEXT NOT NULL,
  result TEXT NOT NULL,
  start_fen TEXT,
  created_at TEXT NOT NULL
);

-- Códigos de animação de vitória (<NNN> no fim do nome). O código só vale para o participante a quem está vinculado.
CREATE TABLE IF NOT EXISTS anim_codes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  animation TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1,
  player_id INTEGER UNIQUE REFERENCES players(id) ON DELETE SET NULL,
  reserved_name TEXT,
  created_at TEXT NOT NULL,
  claimed_at TEXT
);

CREATE TABLE IF NOT EXISTS audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  ts TEXT NOT NULL,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  entity TEXT,
  entity_id INTEGER,
  details TEXT
);
`;

class Store {
  constructor(file) {
    this.file = file;
    if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
    this.db = new DatabaseSync(file);
    this.db.exec('PRAGMA foreign_keys = ON;');
    if (file !== ':memory:') {
      this.db.exec('PRAGMA journal_mode = WAL;');
      this.db.exec('PRAGMA synchronous = FULL;'); // resultados não podem se perder em queda de energia
    }
    this.db.exec(SCHEMA);
    const row = this.get("SELECT value FROM meta WHERE key='schema_version'");
    if (!row) this.run("INSERT INTO meta(key,value) VALUES('schema_version', ?)", [String(SCHEMA_VERSION)]);
    this._depth = 0;
  }

  run(sql, params = []) { return this.db.prepare(sql).run(...params); }
  get(sql, params = []) { return this.db.prepare(sql).get(...params); }
  all(sql, params = []) { return this.db.prepare(sql).all(...params); }

  /** Executa fn dentro de uma transação (aninhável via savepoint). Reverte tudo em caso de erro. */
  tx(fn) {
    if (this._depth > 0) {
      const sp = `sp_${this._depth}`;
      this.db.exec(`SAVEPOINT ${sp}`);
      this._depth++;
      try { const r = fn(); this.db.exec(`RELEASE ${sp}`); return r; }
      catch (e) { this.db.exec(`ROLLBACK TO ${sp}`); this.db.exec(`RELEASE ${sp}`); throw e; }
      finally { this._depth--; }
    }
    this.db.exec('BEGIN IMMEDIATE');
    this._depth = 1;
    try {
      const r = fn();
      this.db.exec('COMMIT');
      return r;
    } catch (e) {
      try { this.db.exec('ROLLBACK'); } catch (_) { /* já revertido */ }
      throw e;
    } finally { this._depth = 0; }
  }

  audit(actor, action, entity = null, entityId = null, details = null) {
    this.run('INSERT INTO audit(ts, actor, action, entity, entity_id, details) VALUES (?,?,?,?,?,?)',
      [new Date().toISOString(), actor, action, entity, entityId, details == null ? null : JSON.stringify(details)]);
  }

  /** Verifica integridade física e lógica do arquivo. */
  integrityCheck() {
    const r = this.get('PRAGMA integrity_check');
    const fk = this.all('PRAGMA foreign_key_check');
    return { ok: r.integrity_check === 'ok' && fk.length === 0, integrity: r.integrity_check, foreignKeyViolations: fk.length };
  }

  /** Backup consistente (funciona com o banco em uso). */
  async backupTo(dest) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    await backup(this.db, dest);
    return dest;
  }

  close() { try { this.db.close(); } catch (_) { /* já fechado */ } }
}

/** Valida um arquivo de backup e retorna se pode ser restaurado. */
function validateBackupFile(file) {
  const probe = new DatabaseSync(file, { readOnly: true });
  try {
    const r = probe.prepare('PRAGMA integrity_check').get();
    if (r.integrity_check !== 'ok') throw new Error('Backup corrompido: ' + r.integrity_check);
    const t = probe.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='tournament'").get();
    if (!t) throw new Error('Arquivo não é um backup do maria open CHESS');
    return true;
  } finally { probe.close(); }
}

module.exports = { Store, validateBackupFile, SCHEMA_VERSION };
