'use strict';
/**
 * Escolhe o motor SQLite:
 *  - node:sqlite (Node >= 22.5), usado no computador;
 *  - sql.js (SQLite em WebAssembly), usado onde o Node é mais antigo, como no aplicativo Android (Node 18 embutido).
 * OPEN_CHESS_SQLITE=sqljs força o sql.js; OPEN_CHESS_SQLITE=node exige o node:sqlite.
 */
function pick() {
  const forced = process.env.OPEN_CHESS_SQLITE;
  if (forced !== 'sqljs') {
    try { return { ...require('node:sqlite'), engine: 'node:sqlite' }; } catch (e) { if (forced === 'node') throw e; }
  }
  return { ...require('./sqljs-driver'), engine: 'sql.js' };
}

module.exports = pick();
