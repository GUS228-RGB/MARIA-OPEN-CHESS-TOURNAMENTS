'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { toPgn } = require('../chess/pgn');

const fmtPts = (n) => (Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100).replace('.', ','));
const pad3 = (n) => String(n).padStart(3, '0');
const MODALITY_LABEL = { presencial: 'PRESENCIAL', online: 'ONLINE', hibrido: 'HÍBRIDO' };

function safeFileName(name) {
  const base = String(name).normalize('NFC').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '').replace(/\s+/g, '_').replace(/^\.+/, '').slice(0, 80);
  return base || 'torneio';
}

function displayNames(standings) {
  const count = new Map();
  for (const r of standings) count.set(r.player.name, (count.get(r.player.name) || 0) + 1);
  return (r) => (count.get(r.player.name) > 1 ? `${r.player.name} (ID ${pad3(r.player.number)})` : r.player.name);
}

/** Texto de resultados no formato pedido. Nomes duplicados recebem o identificador. */
function buildResultsTxt(svc) {
  const t = svc.tournament();
  const st = svc.standings();
  const label = displayNames(st);
  const finished = t.status === 'finished';
  const date = (t.finished_at || new Date().toISOString()).slice(0, 10).split('-').reverse().join('/');
  const lines = [];
  lines.push(t.name.toUpperCase(), '');
  lines.push(`MODALIDADE: ${MODALITY_LABEL[t.modality]}`);
  lines.push(`DATA: ${date}`, '');
  lines.push(finished ? 'CLASSIFICAÇÃO FINAL' : 'CLASSIFICAÇÃO PARCIAL (torneio em andamento)', '');
  const withPts = st.length > 0;
  if (withPts) {
    st.forEach((r, i) => {
      const pts = r.points;
      lines.push(`${i + 1}º - ${label(r)} - ${fmtPts(pts)} ${pts === 1 ? 'ponto' : 'pontos'}`);
    });
  }
  lines.push('', `TOTAL DE PARTICIPANTES: ${st.length}`);
  return lines.join('\n') + '\n';
}

function resultsFileName(svc) { return `${safeFileName(svc.tournament().name)}_resultados.txt`; }

/** Grava o TXT na pasta do torneio. Retorna o caminho do arquivo. */
function writeResultsTxt(svc, dir) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, resultsFileName(svc));
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, buildResultsTxt(svc), 'utf8');
  fs.renameSync(tmp, file); // gravação atômica
  return file;
}

// ------------------------------------------------------------------ PGN
function gameToPgn(svc, gameId) {
  const t = svc.tournament();
  const g = svc.games().find((x) => x.id === gameId);
  if (!g || !g.black) return null;
  const moves = svc.moves(gameId).map((m) => m.san);
  const date = (g.finished_at || g.started_at || t.created_at).slice(0, 10).replace(/-/g, '.');
  const result = g.state === 'finished' && g.result && g.result !== 'bye' ? g.result : '*';
  const tags = {
    Event: t.name, Site: 'maria open CHESS', Date: date, Round: `${g.round}.${g.board}`,
    White: g.white.name, Black: g.black.name, WhiteID: pad3(g.white.number), BlackID: pad3(g.black.number),
    Mode: g.kind === 'online' ? 'online' : 'presencial',
  };
  if (!moves.length) tags.Annotator = 'Somente resultado registrado (sem lances)';
  return { pgn: toPgn(tags, moves, result), hasMoves: moves.length > 0 };
}

/** Todas as partidas. Por padrão só as que possuem lances (não fabrica histórico). */
function tournamentPgn(svc, { includeResultOnly = false } = {}) {
  const out = [];
  for (const g of svc.games()) {
    if (!g.black) continue;
    const r = gameToPgn(svc, g.id);
    if (!r) continue;
    if (r.hasMoves || (includeResultOnly && g.state === 'finished')) out.push(r.pgn);
  }
  return out.join('\n');
}

module.exports = { buildResultsTxt, writeResultsTxt, resultsFileName, safeFileName, gameToPgn, tournamentPgn, fmtPts };
