'use strict';
/**
 * Catálogo de animações de vitória. É a ÚNICA lista que o servidor conhece: para criar uma animação nova,
 * acrescente uma entrada aqui e registre o desenho correspondente em web/js/anim/ (registerAnimation).
 * `num` é o número de catálogo (001–007); os códigos de participante são independentes e criados pelo organizador.
 */
const CATALOG = [
  { id: 'padrao', num: null, nome: 'Padrão (troféu)', descricao: 'Animação simples usada por quem não tem código.' },
  { id: 'ouro', num: '001', nome: 'Explosão dourada', descricao: 'Explosão de partículas douradas e o texto VITÓRIA!' },
  { id: 'raios', num: '002', nome: 'Raios azuis', descricao: 'Raios elétricos azuis cruzando a tela.' },
  { id: 'coroa', num: '003', nome: 'Coroa de campeão', descricao: 'Apresentação cinematográfica de uma coroa.' },
  { id: 'fogo', num: '004', nome: 'Explosão de fogo', descricao: 'Chamas e brasas subindo da base da tela.' },
  { id: 'cosmos', num: '005', nome: 'Espacial', descricao: 'Estrelas, nebulosa e energia cósmica.' },
  { id: 'glitch', num: '006', nome: 'Glitch neon', descricao: 'Glitch digital com cores neon.' },
  { id: 'aura', num: '007', nome: 'Aura lendária', descricao: 'Aura brilhante com partículas luminosas.' },
];
const IDS = new Set(CATALOG.map((a) => a.id));
const byNum = (n) => CATALOG.find((a) => a.num === n) || null;

const CODE_RE = /^\d{3,6}$/;
const SUFFIX_RE = /<\s*(\d{1,9})\s*>\s*$/; // só conteúdo numérico é tratado como código; outros <...> seguem sendo apenas removidos do nome

/** Separa "Gustavo<001>" em { name: 'Gustavo', code: '001' }. Sufixo <...> com conteúdo que não seja um código válido é recusado. */
function splitNameCode(raw, fail) {
  const s = String(raw ?? '');
  const m = SUFFIX_RE.exec(s);
  if (!m) return { name: s, code: null };
  if (!CODE_RE.test(m[1])) fail('invalid_code', 'Código de animação inválido. Use de 3 a 6 números entre < >, por exemplo <001>.');
  return { name: s.slice(0, m.index), code: m[1] };
}

/** Normaliza nomes para comparação (sem acento, sem diferença de caixa/espaços). */
function normName(s) {
  let t = String(s ?? '').toLowerCase();
  try { t = t.normalize('NFD').replace(/[̀-ͯ]/g, ''); } catch (_) { /* sem ICU */ }
  return t.replace(/\s+/g, ' ').trim();
}

module.exports = { CATALOG, IDS, byNum, CODE_RE, splitNameCode, normName };
