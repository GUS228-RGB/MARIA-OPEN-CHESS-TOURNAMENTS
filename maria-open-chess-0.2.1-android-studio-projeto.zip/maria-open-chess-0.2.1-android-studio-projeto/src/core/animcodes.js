'use strict';
/**
 * Códigos de animação de vitória e acesso ao torneio (convite). Instalado como métodos de TournamentService.
 *
 * Regras de segurança dos códigos de animação:
 *  - o código fica numa tabela própria e é vinculado ao id do participante (que só é provado pelo token secreto dele);
 *  - digitar <001> no nome só vale se o código existir E estiver livre ou reservado para aquele nome;
 *  - um código já vinculado nunca passa para outra pessoa por inscrição, só pelo organizador;
 *  - o código nunca é enviado a outros participantes: só o id da animação é público.
 */
const crypto = require('node:crypto');
const { CATALOG, IDS, byNum, CODE_RE, splitNameCode, normName } = require('./animations');

const ACCESS_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // sem 0/O/1/I/L
const ACCESS_RE = /^[A-Z0-9]{4,12}$/;
const MAX_CODES = 1000;
const normAccess = (s) => String(s ?? '').toUpperCase().replace(/[\s-]/g, '');
const fmtAccess = (s) => (s.length === 6 ? s.slice(0, 3) + '-' + s.slice(3) : s);
const nowIso = () => new Date().toISOString();

function install(Service, fail) {
  const P = Service.prototype;

  P.animCatalog = () => CATALOG.map((a) => ({ ...a }));

  /** Divide o nome digitado em nome de exibição + código (se houver). */
  P.splitNameCode = (raw) => splitNameCode(raw, fail);

  P._animRow = function (r) {
    const pl = r.player_id ? this.store.get('SELECT id, number, name, status FROM players WHERE id=?', [r.player_id]) : null;
    return {
      id: r.id, code: r.code, animation: r.animation, active: !!r.active, reserved_name: r.reserved_name || null,
      created_at: r.created_at, claimed_at: r.claimed_at || null,
      player: pl ? { id: pl.id, number: pl.number, name: pl.name, status: pl.status } : null,
      status: pl ? 'vinculado' : r.reserved_name ? 'reservado' : 'livre',
    };
  };

  P.animList = function () {
    return this.store.all('SELECT * FROM anim_codes ORDER BY code').map((r) => this._animRow(r));
  };

  /** Mapa id do participante → id da animação (somente códigos ativos). O código em si nunca sai daqui. */
  P.playerAnims = function () {
    const out = new Map();
    for (const r of this.store.all('SELECT player_id, animation FROM anim_codes WHERE player_id IS NOT NULL AND active=1')) out.set(r.player_id, r.animation);
    return out;
  };

  P.animOf = function (playerId) {
    const r = this.store.get('SELECT code, animation, active FROM anim_codes WHERE player_id=?', [playerId]);
    return r ? { code: r.code, animation: r.animation, active: !!r.active } : null;
  };

  P._validAnimation = (a) => { if (!IDS.has(a)) fail('invalid_animation', 'Animação desconhecida.'); return a; };

  P._nextFreeCode = function () {
    const used = new Set(this.store.all('SELECT code FROM anim_codes').map((r) => r.code));
    for (let n = 8; n < 1000000; n++) { const c = String(n).padStart(3, '0'); if (!used.has(c)) return c; }
    fail('invalid_code', 'Não há mais códigos livres.');
  };

  P._checkPlayerFree = function (playerId, exceptCodeId = null) {
    const p = this.store.get('SELECT id, name FROM players WHERE id=?', [playerId]);
    if (!p) fail('not_found', 'Participante não encontrado.', 404);
    const has = this.store.get('SELECT id, code FROM anim_codes WHERE player_id=?', [playerId]);
    if (has && has.id !== exceptCodeId) fail('player_has_code', `${p.name} já tem o código <${has.code}>. Edite ou exclua esse código antes.`, 409);
    return p;
  };

  /**
   * Cria um código. b: { code?|auto?, animation?, player_id?, reserved_name?, active? }
   * Sem animation: usa a animação de catálogo com o mesmo número (001→ouro…) ou a padrão.
   */
  P.animCreate = function (b = {}, actor = 'organizador') {
    return this.store.tx(() => {
      if (this.store.get('SELECT COUNT(*) c FROM anim_codes').c >= MAX_CODES) fail('too_many', 'Limite de códigos atingido.', 409);
      let code;
      if (b.auto) code = this._nextFreeCode();
      else {
        code = String(b.code ?? '').trim();
        if (!CODE_RE.test(code)) fail('invalid_code', 'O código deve ter de 3 a 6 números (ex.: 001).');
      }
      if (this.store.get('SELECT id FROM anim_codes WHERE code=?', [code])) fail('code_exists', `O código <${code}> já existe. Cada código é exclusivo.`, 409);
      const animation = this._validAnimation(b.animation || (byNum(code) ? byNum(code).id : 'padrao'));
      let playerId = null, reserved = null;
      if (b.player_id != null && b.player_id !== '') {
        playerId = Number(b.player_id);
        if (!Number.isInteger(playerId)) fail('invalid', 'Participante inválido.');
        this._checkPlayerFree(playerId);
      } else if (b.reserved_name != null && String(b.reserved_name).trim() !== '') {
        reserved = String(b.reserved_name).trim().slice(0, 40);
      }
      const r = this.store.run('INSERT INTO anim_codes(code,animation,active,player_id,reserved_name,created_at,claimed_at) VALUES (?,?,?,?,?,?,?)',
        [code, animation, b.active === false ? 0 : 1, playerId, reserved, nowIso(), playerId ? nowIso() : null]);
      const id = Number(r.lastInsertRowid);
      this.store.audit(actor, 'codigo_animacao_criado', 'codigo', id, { code, animation, player_id: playerId, reserved_name: reserved });
      this.emit('players', {});
      return this._animRow(this.store.get('SELECT * FROM anim_codes WHERE id=?', [id]));
    });
  };

  /** Edita: { code?, animation?, active?, player_id? (null desvincula), reserved_name? } */
  P.animUpdate = function (id, b = {}, actor = 'organizador') {
    return this.store.tx(() => {
      const cur = this.store.get('SELECT * FROM anim_codes WHERE id=?', [id]);
      if (!cur) fail('not_found', 'Código não encontrado.', 404);
      const next = { ...cur };
      if (b.code !== undefined && String(b.code).trim() !== cur.code) {
        const c = String(b.code).trim();
        if (!CODE_RE.test(c)) fail('invalid_code', 'O código deve ter de 3 a 6 números (ex.: 001).');
        if (this.store.get('SELECT id FROM anim_codes WHERE code=? AND id!=?', [c, id])) fail('code_exists', `O código <${c}> já existe. Cada código é exclusivo.`, 409);
        next.code = c;
      }
      if (b.animation !== undefined) next.animation = this._validAnimation(b.animation);
      if (b.active !== undefined) next.active = b.active ? 1 : 0;
      if (b.player_id !== undefined) {
        if (b.player_id === null || b.player_id === '') { next.player_id = null; next.claimed_at = null; }
        else {
          const pid = Number(b.player_id);
          if (!Number.isInteger(pid)) fail('invalid', 'Participante inválido.');
          this._checkPlayerFree(pid, id);
          next.player_id = pid; next.reserved_name = null; next.claimed_at = nowIso();
        }
      }
      if (b.reserved_name !== undefined) {
        const rn = b.reserved_name == null ? '' : String(b.reserved_name).trim();
        next.reserved_name = rn ? rn.slice(0, 40) : null;
        if (rn && b.player_id === undefined) { next.player_id = null; next.claimed_at = null; } // reservar para um nome desfaz o vínculo antigo
      }
      this.store.run('UPDATE anim_codes SET code=?, animation=?, active=?, player_id=?, reserved_name=?, claimed_at=? WHERE id=?',
        [next.code, next.animation, next.active, next.player_id, next.reserved_name, next.claimed_at, id]);
      this.store.audit(actor, 'codigo_animacao_editado', 'codigo', id, { de: { code: cur.code, animation: cur.animation, active: !!cur.active, player_id: cur.player_id }, para: { code: next.code, animation: next.animation, active: !!next.active, player_id: next.player_id, reserved_name: next.reserved_name } });
      this.emit('players', {});
      return this._animRow(this.store.get('SELECT * FROM anim_codes WHERE id=?', [id]));
    });
  };

  P.animDelete = function (id, actor = 'organizador') {
    return this.store.tx(() => {
      const cur = this.store.get('SELECT * FROM anim_codes WHERE id=?', [id]);
      if (!cur) fail('not_found', 'Código não encontrado.', 404);
      this.store.run('DELETE FROM anim_codes WHERE id=?', [id]);
      this.store.audit(actor, 'codigo_animacao_excluido', 'codigo', id, { code: cur.code, animation: cur.animation, player_id: cur.player_id });
      this.emit('players', {});
      return true;
    });
  };

  /**
   * Chamado dentro da transação de inscrição. Retorna o código vinculado ({code, animation}).
   * `organizer`: o organizador pode vincular um código livre/reservado a qualquer nome; ninguém vincula código de outra pessoa.
   */
  P._claimCode = function (playerId, code, displayName, { organizer = false } = {}) {
    const row = this.store.get('SELECT * FROM anim_codes WHERE code=?', [code]);
    if (!row) fail('code_unknown', `O código <${code}> não existe neste torneio. Peça um código válido ao organizador ou entre sem código.`, 403);
    if (row.player_id != null) fail('code_taken', `O código <${code}> pertence a outro participante. Cada código é exclusivo da pessoa a quem foi entregue.`, 403);
    if (row.reserved_name && normName(row.reserved_name) !== normName(displayName) && !organizer) fail('code_not_yours', `O código <${code}> está reservado para outro nome.`, 403);
    this._checkPlayerFree(playerId);
    this.store.run('UPDATE anim_codes SET player_id=?, claimed_at=? WHERE id=?', [playerId, nowIso(), row.id]);
    this.store.audit(organizer ? 'organizador' : 'participante', 'codigo_animacao_vinculado', 'codigo', row.id, { code, player_id: playerId });
    return { code, animation: row.animation, active: !!row.active };
  };

  // ------------------------------------------------------------------ convite e acesso
  P._meta = function (k) { const r = this.store.get('SELECT value FROM meta WHERE key=?', [k]); return r ? r.value : null; };
  P._setMeta = function (k, v) { this.store.run('INSERT OR REPLACE INTO meta(key,value) VALUES (?,?)', [k, v]); };

  P.generateAccessCode = () => { let s = ''; const b = crypto.randomBytes(6); for (let i = 0; i < 6; i++) s += ACCESS_ALPHABET[b[i] % ACCESS_ALPHABET.length]; return s; };

  P.accessCode = function () {
    let c = this._meta('access_code');
    if (!c) { c = this.generateAccessCode(); this._setMeta('access_code', c); }
    return c;
  };
  P.visibility = function () { return this._meta('visibility') === 'private' ? 'private' : 'public'; };

  /** Dados públicos do acesso (sem o código). */
  P.accessInfo = function () { const v = this.visibility(); return { visibility: v, needs_code: v === 'private' }; };

  /** Dados do organizador. */
  P.inviteAdmin = function () { const c = this.accessCode(); return { visibility: this.visibility(), access_code: c, access_code_display: fmtAccess(c) }; };

  /** Confere o código de acesso informado por quem quer entrar. Tempo constante. */
  P.checkAccess = function (given) {
    if (this.visibility() !== 'private') return true;
    const a = Buffer.from(normAccess(given).padEnd(16, '_').slice(0, 16));
    const b = Buffer.from(normAccess(this.accessCode()).padEnd(16, '_').slice(0, 16));
    return normAccess(given).length > 0 && crypto.timingSafeEqual(a, b) && normAccess(given) === normAccess(this.accessCode());
  };

  P.setInvite = function ({ visibility, regenerate, access_code } = {}, actor = 'organizador') {
    this.store.tx(() => {
      if (visibility !== undefined) {
        if (!['public', 'private'].includes(visibility)) fail('invalid', 'Visibilidade inválida.');
        this._setMeta('visibility', visibility);
        this.store.audit(actor, 'visibilidade_alterada', 'torneio', 1, { visibility });
      }
      if (access_code !== undefined && access_code !== null && access_code !== '') {
        const c = normAccess(access_code);
        if (!ACCESS_RE.test(c)) fail('invalid_access_code', 'O código de acesso deve ter de 4 a 12 letras ou números.');
        this._setMeta('access_code', c);
        this.store.audit(actor, 'codigo_acesso_alterado', 'torneio', 1);
      } else if (regenerate) {
        this._setMeta('access_code', this.generateAccessCode());
        this.store.audit(actor, 'codigo_acesso_regenerado', 'torneio', 1);
      }
    });
    this.emit('tournament', {});
    return this.inviteAdmin();
  };
}

module.exports = { install, normAccess, fmtAccess };
