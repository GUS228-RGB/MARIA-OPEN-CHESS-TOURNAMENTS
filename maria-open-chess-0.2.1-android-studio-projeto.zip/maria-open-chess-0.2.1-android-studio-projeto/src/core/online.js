'use strict';
const { Game } = require('../chess/game');
const { sqName } = require('../chess/engine');

class OnlineError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}
const fail = (code, msg) => { throw new OnlineError(code, msg); };

/**
 * Gerencia partidas online: valida lances no servidor, controla relógio, empates,
 * abandono, persistência lance a lance e recuperação após reinício.
 *
 * Os relógios usam `now()` injetável e `timers` injetável para permitir testes determinísticos.
 */
class OnlineManager {
  constructor(svc, { now = Date.now, timers = { set: setTimeout, clear: clearTimeout }, onUpdate = () => {} } = {}) {
    this.svc = svc;
    this.now = now;
    this.timers = timers;
    this.onUpdate = onUpdate;
    this.live = new Map();
  }

  // ---------------------------------------------------------------- carga / recuperação
  _load(gameId) {
    if (this.live.has(gameId)) return this.live.get(gameId);
    const row = this.svc.game(gameId);
    if (!row) fail('not_found', 'Partida não encontrada.');
    if (row.kind !== 'online') fail('not_online', 'Esta não é uma partida online.');
    if (row.black_id == null) fail('not_online', 'Partida com bye.');
    const t = this.svc.tournament();
    const base = t.time_base_s * 1000;
    const lg = {
      id: gameId, row, game: new Game(), color: { w: row.white_id, b: row.black_id },
      ms: { w: row.white_ms ?? base, b: row.black_ms ?? base },
      turnStartedAt: row.turn_started_at, inc: t.time_inc_s * 1000,
      drawOffer: null, presence: { w: 0, b: 0 }, timer: null, lastSpent: [],
    };
    const moves = this.svc.moves(gameId);
    for (const m of moves) {
      if (!lg.game.move(m.uci)) throw new Error(`Histórico corrompido na partida ${gameId}, lance ${m.ply}`);
    }
    if (row.state === 'finished') {
      lg.finished = true;
      lg.result = row.result; lg.reason = row.reason;
    } else if (row.state === 'playing') {
      // Reinício do servidor: o tempo parado não é cobrado dos jogadores.
      lg.turnStartedAt = this.now();
      this.svc.store.run('UPDATE games SET turn_started_at=? WHERE id=?', [lg.turnStartedAt, gameId]);
      this._arm(lg);
    }
    this.live.set(gameId, lg);
    return lg;
  }

  /** Reativa partidas em andamento após reiniciar o servidor. */
  recover() {
    const rows = this.svc.store.all("SELECT id FROM games WHERE kind='online' AND state='playing'");
    for (const r of rows) this._load(r.id);
    return rows.length;
  }

  // ---------------------------------------------------------------- consulta
  colorOf(lg, playerId) {
    if (lg.color.w === playerId) return 'w';
    if (lg.color.b === playerId) return 'b';
    return null;
  }

  remaining(lg) {
    const out = { w: lg.ms.w, b: lg.ms.b };
    if (lg.row.state === 'playing' && !lg.finished && lg.turnStartedAt) {
      const turn = lg.game.turn;
      out[turn] = Math.max(0, out[turn] - (this.now() - lg.turnStartedAt));
    }
    return out;
  }

  snapshot(gameId, viewerPlayerId = null) {
    const lg = this._load(gameId);
    const row = this.svc.game(gameId);
    const color = viewerPlayerId != null ? this.colorOf(lg, viewerPlayerId) : null;
    const rem = this.remaining(lg);
    const players = this.svc.players();
    const nm = (id) => { const p = players.find((x) => x.id === id); return p ? { id, number: p.number, name: p.name } : null; };
    const over = lg.finished || row.state === 'finished';
    const snap = {
      id: gameId, round: row.round, state: row.state, result: over ? (row.result || lg.result) : null,
      reason: over ? (lg.reason || row.reason) : null,
      white: nm(row.white_id), black: nm(row.black_id),
      fen: lg.game.fen, turn: lg.game.turn, moves: lg.game.moves.slice(),
      lastMove: lg.game.uci.length ? lg.game.uci[lg.game.uci.length - 1] : null,
      inCheck: lg.game.inCheck(), board: lg.game.boardMap(),
      whiteMs: rem.w, blackMs: rem.b, serverTime: this.now(), incMs: lg.inc,
      drawOffer: lg.drawOffer, you: color,
      presence: { w: lg.presence.w > 0, b: lg.presence.b > 0 },
    };
    if (color && color === lg.game.turn && row.state === 'playing' && !over) snap.legal = lg.game.legalList();
    return snap;
  }

  // ---------------------------------------------------------------- presença / início
  connect(gameId, playerId) {
    const lg = this._load(gameId);
    const color = this.colorOf(lg, playerId);
    if (!color) return null;
    lg.presence[color]++;
    this._maybeStart(lg);
    return color;
  }

  disconnect(gameId, playerId) {
    const lg = this.live.get(gameId);
    if (!lg) return;
    const color = this.colorOf(lg, playerId);
    if (color && lg.presence[color] > 0) lg.presence[color]--;
  }

  _maybeStart(lg) {
    const row = this.svc.game(lg.id);
    if (row.state !== 'waiting' || lg.finished) return false;
    if (lg.presence.w === 0 || lg.presence.b === 0) return false;
    const rd = this.svc.store.get('SELECT status FROM rounds WHERE number=?', [row.round]);
    if (rd.status !== 'running') return false;
    const t = this.svc.tournament();
    const base = t.time_base_s * 1000;
    lg.ms = { w: base, b: base };
    lg.turnStartedAt = this.now();
    this.svc.beginOnlineGame(lg.id, base, base, lg.turnStartedAt, lg.game.fen);
    lg.row = this.svc.game(lg.id);
    this._arm(lg);
    this.svc.emit('rounds', {});
    this.onUpdate(lg.id);
    return true;
  }

  // ---------------------------------------------------------------- ações
  _active(lg) {
    const row = this.svc.game(lg.id);
    if (lg.finished || row.state === 'finished') fail('finished', 'A partida já terminou.');
    if (row.state !== 'playing') fail('not_started', 'A partida ainda não começou: aguarde os dois jogadores.');
    return row;
  }

  move(gameId, playerId, mv) {
    const lg = this._load(gameId);
    this._active(lg);
    const color = this.colorOf(lg, playerId);
    if (!color) fail('forbidden', 'Você não é jogador desta partida.');
    if (this._flagged(lg)) return this._flag(lg);
    if (lg.game.turn !== color) fail('not_your_turn', 'Não é a sua vez.');
    const before = lg.game.moves.length;
    const spent = this.now() - lg.turnStartedAt;
    const san = lg.game.move(mv);
    if (!san) fail('illegal', 'Lance ilegal.');
    const nowMs = this.now();
    lg.ms[color] = lg.ms[color] - spent + lg.inc;
    lg.turnStartedAt = nowMs;
    lg.drawOffer = null;
    const ply = before + 1;
    const uci = lg.game.uci[lg.game.uci.length - 1];
    this.svc.saveMove(lg.id, ply, san, uci, lg.game.fen, spent, lg.ms.w, lg.ms.b, nowMs);
    if (lg.game.over) this._conclude(lg, lg.game.result, lg.game.reason);
    else this._arm(lg);
    this.onUpdate(lg.id);
    return san;
  }

  resign(gameId, playerId) {
    const lg = this._load(gameId);
    this._active(lg);
    const color = this.colorOf(lg, playerId);
    if (!color) fail('forbidden', 'Você não é jogador desta partida.');
    lg.game.resign(color);
    this._conclude(lg, lg.game.result, 'resign');
    this.onUpdate(lg.id);
  }

  offerDraw(gameId, playerId) {
    const lg = this._load(gameId);
    this._active(lg);
    const color = this.colorOf(lg, playerId);
    if (!color) fail('forbidden', 'Você não é jogador desta partida.');
    lg.drawOffer = color;
    this.onUpdate(lg.id);
  }

  respondDraw(gameId, playerId, accept) {
    const lg = this._load(gameId);
    this._active(lg);
    const color = this.colorOf(lg, playerId);
    if (!color) fail('forbidden', 'Você não é jogador desta partida.');
    if (!lg.drawOffer || lg.drawOffer === color) fail('no_offer', 'Não há proposta de empate do adversário.');
    if (accept) { lg.game.drawByAgreement(); this._conclude(lg, '1/2-1/2', 'agreement'); }
    else lg.drawOffer = null;
    this.onUpdate(lg.id);
  }

  // ---------------------------------------------------------------- relógio
  _flagged(lg) {
    if (!lg.turnStartedAt) return false;
    const turn = lg.game.turn;
    return lg.ms[turn] - (this.now() - lg.turnStartedAt) <= 0;
  }

  _flag(lg) {
    const loser = lg.game.turn;
    lg.ms[loser] = 0;
    lg.game.timeout(loser);
    this._conclude(lg, lg.game.result, 'timeout');
    this.onUpdate(lg.id);
    return null;
  }

  /** Verifica todas as partidas ativas (chamado pelo temporizador e por testes). */
  tick() {
    for (const lg of this.live.values()) {
      if (!lg.finished && this.svc.game(lg.id).state === 'playing' && this._flagged(lg)) this._flag(lg);
    }
  }

  _arm(lg) {
    if (lg.timer) this.timers.clear(lg.timer);
    if (lg.finished) return;
    const turn = lg.game.turn;
    const left = Math.max(0, lg.ms[turn] - (this.now() - lg.turnStartedAt));
    lg.timer = this.timers.set(() => { lg.timer = null; try { if (this._flagged(lg) && !lg.finished) this._flag(lg); else this._arm(lg); } catch (_) { /* sem partida ativa */ } }, left + 20);
    if (lg.timer && lg.timer.unref) lg.timer.unref();
  }

  _conclude(lg, result, reason) {
    lg.finished = true;
    lg.result = result; lg.reason = reason;
    if (lg.timer) { this.timers.clear(lg.timer); lg.timer = null; }
    this.svc.store.run('UPDATE games SET white_ms=?, black_ms=? WHERE id=?', [Math.max(0, lg.ms.w), Math.max(0, lg.ms.b), lg.id]);
    this.svc.recordResult(lg.id, result, { actor: 'motor', endReason: reason });
  }

  shutdown() {
    for (const lg of this.live.values()) if (lg.timer) this.timers.clear(lg.timer);
    this.live.clear();
  }

  /** Jogo online atual do participante (para a página dele abrir o tabuleiro). */
  currentGameFor(playerId) {
    const row = this.svc.store.get(`SELECT g.id FROM games g JOIN rounds r ON r.number=g.round
      WHERE g.kind='online' AND g.black_id IS NOT NULL AND (g.white_id=? OR g.black_id=?)
      AND r.status='running' AND g.state IN ('waiting','playing') ORDER BY g.round DESC, g.id DESC LIMIT 1`, [playerId, playerId]);
    return row ? row.id : null;
  }
}

module.exports = { OnlineManager, OnlineError, sqName };
