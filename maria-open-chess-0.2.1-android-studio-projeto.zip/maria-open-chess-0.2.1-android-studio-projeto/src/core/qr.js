'use strict';
/**
 * Gerador de QR Code (modo byte, nível de correção M, versões 1 a 10), sem dependências.
 * Capacidade: até 213 bytes (UTF-8) — suficiente para URLs de rede local.
 */

// [ecCodewordsPorBloco, [[nBlocos, dadosPorBloco], ...]] — nível M
const EC_M = {
  1: [10, [[1, 16]]], 2: [16, [[1, 28]]], 3: [26, [[1, 44]]], 4: [18, [[2, 32]]], 5: [24, [[2, 43]]],
  6: [16, [[4, 27]]], 7: [18, [[4, 31]]], 8: [22, [[2, 38], [2, 39]]], 9: [22, [[3, 36], [2, 37]]], 10: [26, [[4, 43], [1, 44]]],
};
const ALIGN = { 1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34], 7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50] };

// ---- Galois GF(256)
const EXP = new Array(512), LOG = new Array(256);
(() => { let x = 1; for (let i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; } for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255]; })();
const gmul = (a, b) => (a === 0 || b === 0 ? 0 : EXP[LOG[a] + LOG[b]]);

function rsGenerator(deg) {
  let poly = [1];
  for (let i = 0; i < deg; i++) {
    const next = new Array(poly.length + 1).fill(0);
    for (let j = 0; j < poly.length; j++) { next[j] ^= poly[j]; next[j + 1] ^= gmul(poly[j], EXP[i]); }
    poly = next;
  }
  return poly;
}
function rsRemainder(data, ecLen) {
  const gen = rsGenerator(ecLen);
  const res = new Array(ecLen).fill(0);
  for (const b of data) {
    const factor = b ^ res.shift();
    res.push(0);
    for (let i = 0; i < ecLen; i++) res[i] ^= gmul(gen[i + 1], factor);
  }
  return res;
}

function capacityBytes(version) {
  const [, groups] = EC_M[version];
  const dataCw = groups.reduce((a, [n, d]) => a + n * d, 0);
  const lenBits = version >= 10 ? 16 : 8;
  return Math.floor((dataCw * 8 - 4 - lenBits) / 8);
}

function encode(text) {
  const bytes = Buffer.from(String(text), 'utf8');
  let version = 0;
  for (let v = 1; v <= 10; v++) if (bytes.length <= capacityBytes(v)) { version = v; break; }
  if (!version) throw new Error('Texto longo demais para o QR Code (máx. ' + capacityBytes(10) + ' bytes)');
  const [ecLen, groups] = EC_M[version];
  const totalData = groups.reduce((a, [n, d]) => a + n * d, 0);

  const bits = [];
  const put = (val, len) => { for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
  put(0b0100, 4);
  put(bytes.length, version >= 10 ? 16 : 8);
  for (const b of bytes) put(b, 8);
  put(0, Math.min(4, totalData * 8 - bits.length));
  while (bits.length % 8) bits.push(0);
  const data = [];
  for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2));
  for (let pad = 0xEC; data.length < totalData; pad ^= 0xEC ^ 0x11) data.push(pad);

  // blocos + EC + intercalação
  const blocks = [];
  let off = 0;
  for (const [n, d] of groups) for (let i = 0; i < n; i++) { const blk = data.slice(off, off + d); off += d; blocks.push({ data: blk, ec: rsRemainder(blk, ecLen) }); }
  const out = [];
  const maxD = Math.max(...blocks.map((b) => b.data.length));
  for (let i = 0; i < maxD; i++) for (const b of blocks) if (i < b.data.length) out.push(b.data[i]);
  for (let i = 0; i < ecLen; i++) for (const b of blocks) out.push(b.ec[i]);
  return { version, codewords: out };
}

function buildMatrix(version, codewords) {
  const size = 17 + 4 * version;
  const m = Array.from({ length: size }, () => new Array(size).fill(false));
  const fn = Array.from({ length: size }, () => new Array(size).fill(false));
  const setF = (x, y, v) => { m[y][x] = v; fn[y][x] = true; };

  // padrões de localização
  const finder = (cx, cy) => {
    for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
      const x = cx + dx, y = cy + dy;
      if (x < 0 || y < 0 || x >= size || y >= size) continue;
      const d = Math.max(Math.abs(dx), Math.abs(dy));
      setF(x, y, d !== 2 && d !== 4);
    }
  };
  finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
  // temporização
  for (let i = 0; i < size; i++) { if (!fn[6][i]) setF(i, 6, i % 2 === 0); if (!fn[i][6]) setF(6, i, i % 2 === 0); }
  // alinhamento
  const pos = ALIGN[version];
  for (let a = 0; a < pos.length; a++) for (let b = 0; b < pos.length; b++) {
    if ((a === 0 && b === 0) || (a === 0 && b === pos.length - 1) || (a === pos.length - 1 && b === 0)) continue;
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) setF(pos[a] + dx, pos[b] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
  }
  // reservar formato / versão (valores reais gravados depois)
  const drawFormat = (mask) => {
    const data = (0b00 << 3) | mask; // nível M = 00
    let rem = data;
    for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
    const bitsF = ((data << 10) | rem) ^ 0x5412;
    const bit = (i) => ((bitsF >>> i) & 1) !== 0;
    for (let i = 0; i <= 5; i++) setF(8, i, bit(i));
    setF(8, 7, bit(6)); setF(8, 8, bit(7)); setF(7, 8, bit(8));
    for (let i = 9; i < 15; i++) setF(14 - i, 8, bit(i));
    for (let i = 0; i < 8; i++) setF(size - 1 - i, 8, bit(i));
    for (let i = 8; i < 15; i++) setF(8, size - 15 + i, bit(i));
    setF(8, size - 8, true);
  };
  drawFormat(0);
  if (version >= 7) {
    let rem = version;
    for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
    const bitsV = (version << 12) | rem;
    for (let i = 0; i < 18; i++) {
      const v = ((bitsV >>> i) & 1) !== 0;
      const a = size - 11 + (i % 3), b = Math.floor(i / 3);
      setF(a, b, v); setF(b, a, v);
    }
  }

  // dados em zigue-zague
  const dataBits = [];
  for (const cw of codewords) for (let i = 7; i >= 0; i--) dataBits.push((cw >>> i) & 1);
  let bi = 0;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++) {
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        const upward = ((right + 1) & 2) === 0;
        const y = upward ? size - 1 - vert : vert;
        if (!fn[y][x] && bi < dataBits.length) { m[y][x] = dataBits[bi++] === 1; }
      }
    }
  }

  const maskFn = [
    (x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x, y) => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
    (x, y) => (Math.floor(y / 2) + Math.floor(x / 3)) % 2 === 0, (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0,
    (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0, (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0,
  ];
  let best = null, bestScore = Infinity;
  for (let mask = 0; mask < 8; mask++) {
    const mm = m.map((row) => row.slice());
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!fn[y][x] && maskFn[mask](x, y)) mm[y][x] = !mm[y][x];
    // grava formato no candidato
    const saveM = m.map((r) => r.slice());
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) m[y][x] = mm[y][x];
    drawFormat(mask);
    const cand = m.map((r) => r.slice());
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) m[y][x] = saveM[y][x];
    const s = penalty(cand);
    if (s < bestScore) { bestScore = s; best = cand; }
  }
  return best;
}

function penalty(g) {
  const n = g.length;
  let score = 0;
  const runScore = (line) => {
    let s = 0, run = 1;
    for (let i = 1; i <= line.length; i++) {
      if (i < line.length && line[i] === line[i - 1]) run++;
      else { if (run >= 5) s += 3 + (run - 5); run = 1; }
    }
    return s;
  };
  for (let i = 0; i < n; i++) { score += runScore(g[i]); score += runScore(g.map((r) => r[i])); }
  for (let y = 0; y < n - 1; y++) for (let x = 0; x < n - 1; x++) if (g[y][x] === g[y][x + 1] && g[y][x] === g[y + 1][x] && g[y][x] === g[y + 1][x + 1]) score += 3;
  const pat1 = [true, false, true, true, true, false, true, false, false, false, false];
  const pat2 = pat1.slice().reverse();
  const matches = (arr, i, pat) => pat.every((v, k) => arr[i + k] === v);
  for (let i = 0; i < n; i++) {
    const row = g[i], col = g.map((r) => r[i]);
    for (let k = 0; k + 11 <= n; k++) {
      if (matches(row, k, pat1) || matches(row, k, pat2)) score += 40;
      if (matches(col, k, pat1) || matches(col, k, pat2)) score += 40;
    }
  }
  let dark = 0;
  for (const r of g) for (const v of r) if (v) dark++;
  score += Math.floor(Math.abs((dark * 100) / (n * n) - 50) / 5) * 10;
  return score;
}

/** Retorna matriz booleana (true = módulo escuro). */
function qrMatrix(text) {
  const { version, codewords } = encode(text);
  return buildMatrix(version, codewords);
}

/** QR para terminal: meio-blocos com cores ANSI (preto sobre branco), com margem. */
function qrTerminal(text, { quiet = 2 } = {}) {
  const m = qrMatrix(text);
  const n = m.length;
  const get = (x, y) => (x < 0 || y < 0 || x >= n || y >= n ? false : m[y][x]);
  const lines = [];
  for (let y = -quiet; y < n + quiet; y += 2) {
    let line = '';
    for (let x = -quiet; x < n + quiet; x++) {
      const top = get(x, y), bottom = get(x, y + 1);
      line += `\x1b[${top ? 30 : 97};${bottom ? 40 : 107}m▀`;
    }
    lines.push(line + '\x1b[0m');
  }
  return lines.join('\n');
}

/** QR em SVG (para a interface web e o app). */
function qrSvg(text, { quiet = 2, scale = 8 } = {}) {
  const m = qrMatrix(text);
  const n = m.length;
  const dim = (n + quiet * 2);
  let path = '';
  for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (m[y][x]) path += `M${x + quiet} ${y + quiet}h1v1h-1z`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${dim} ${dim}" width="${dim * scale}" height="${dim * scale}" shape-rendering="crispEdges" role="img" aria-label="QR Code"><rect width="${dim}" height="${dim}" fill="#fff"/><path d="${path}" fill="#000"/></svg>`;
}

module.exports = { qrMatrix, qrTerminal, qrSvg, capacityBytes };
