'use strict';
/**
 * Túnel de acesso por outras redes (internet), sem conta e sem serviço pago.
 * Usa um programa externo que o computador do organizador já tenha:
 *   1) cloudflared  — "Quick Tunnel" gratuito da Cloudflare  (https://xxxx.trycloudflare.com)
 *   2) ssh          — cliente OpenSSH (já vem no Windows 10/11, Linux e macOS) + localhost.run
 * O túnel entrega HTTPS/WSS; o servidor continua rodando no computador do organizador.
 */
const { spawn, spawnSync } = require('node:child_process');
const net = require('node:net');
const http = require('node:http');
const https = require('node:https');

/**
 * Provedor "lt": cliente do protocolo localtunnel escrito em Node puro (sem programa externo, sem conta).
 * É o único que funciona dentro do app Android. O servidor é configurável (OPEN_CHESS_LT_SERVER).
 * Limite conhecido: o loca.lt pode mostrar aos visitantes uma página de aviso pedindo o "tunnel password" (IP público do organizador).
 */
function startLocalTunnel({ port, timeoutMs = 45000, log = () => {} }) {
  const api = new URL(process.env.OPEN_CHESS_LT_SERVER || 'https://localtunnel.me');
  const mod = api.protocol === 'http:' ? http : https;
  return new Promise((resolve, reject) => {
    const req = mod.get(new URL('/?new', api), { timeout: timeoutMs }, (res) => {
      let body = ''; res.on('data', (d) => { body += d; if (body.length > 20000) req.destroy(); });
      res.on('end', () => {
        let info; try { info = JSON.parse(body); } catch (_) { return reject(new Error(`Túnel (localtunnel): resposta inválida do servidor (HTTP ${res.statusCode}).`)); }
        if (!info || !info.url || !info.port) return reject(new Error('Túnel (localtunnel): o servidor não devolveu um endereço.'));
        const remoteHost = api.hostname;
        const max = Math.min(Number(info.max_conn_count) || 4, 10);
        let stopped = false, downCb = null; const socks = new Set(); let fails = 0;
        const open = () => {
          if (stopped) return;
          const remote = net.connect(info.port, remoteHost); const local = net.connect(port, '127.0.0.1');
          socks.add(remote); socks.add(local);
          let started = false;
          remote.once('data', () => { started = true; });
          remote.pipe(local).pipe(remote);
          const done = () => { remote.destroy(); local.destroy(); socks.delete(remote); socks.delete(local); if (stopped) return;
            if (!started) { if (++fails > 8) { stopped = true; if (downCb) downCb(1); return; } setTimeout(open, 1000 * Math.min(fails, 5)); } else { fails = 0; open(); } };
          remote.on('error', done); local.on('error', done); remote.on('close', done); local.on('close', () => remote.destroy());
        };
        for (let i = 0; i < max; i++) open();
        log(`localtunnel: ${info.url}`);
        resolve({ url: info.url.replace(/\/+$/, '') + '/', provider: 'lt', label: 'localtunnel (embutido)',
          stop: () => { stopped = true; downCb = null; for (const x of socks) x.destroy(); },
          onDown: (cb) => { downCb = cb; } });
      });
    });
    req.on('timeout', () => { req.destroy(new Error('sem resposta')); });
    req.on('error', (e) => reject(new Error(`Túnel (localtunnel): ${e.message} (verifique a conexão com a internet).`)));
  });
}

const PROVIDERS = {
  cloudflared: {
    bin: 'cloudflared',
    label: 'Cloudflare Quick Tunnel',
    args: (port) => ['tunnel', '--no-autoupdate', '--url', `http://127.0.0.1:${port}`],
    re: /https:\/\/[a-z0-9-]+\.trycloudflare\.com/i,
    hint: 'Instale o cloudflared: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/',
  },
  ssh: {
    bin: 'ssh',
    label: 'SSH + localhost.run',
    args: (port) => ['-o', 'StrictHostKeyChecking=accept-new', '-o', 'ServerAliveInterval=30', '-o', 'ExitOnForwardFailure=yes', '-o', 'BatchMode=yes', '-R', `80:127.0.0.1:${port}`, 'nokey@localhost.run'],
    re: /https:\/\/[a-z0-9-]+\.(?:lhr\.life|localhost\.run)/i,
    hint: 'Instale o cliente OpenSSH (já vem no Windows 10/11; no Linux: sudo apt install openssh-client).',
  },
};

/** Extrai a URL pública de um trecho de saída do programa de túnel. */
function parseTunnelUrl(provider, text) {
  const p = PROVIDERS[provider];
  if (!p) return null;
  const m = p.re.exec(String(text));
  return m ? m[0].toLowerCase() : null;
}

function hasBinary(bin) {
  const r = spawnSync(bin, [bin === 'ssh' ? '-V' : '--version'], { stdio: 'ignore', timeout: 5000 });
  return !(r.error && r.error.code === 'ENOENT');
}

/**
 * Inicia o túnel. Resolve { url, provider, label, stop(), onDown(cb) } ou rejeita com mensagem clara.
 * @param {{port:number, provider?:'auto'|'cloudflared'|'ssh', timeoutMs?:number, log?:(s:string)=>void}} o
 */
function startTunnel({ port, provider = 'auto', timeoutMs = 45000, log = () => {} }) {
  const order = provider === 'auto' ? ['cloudflared', 'ssh', 'lt'] : [provider];
  for (const name of order) if (!PROVIDERS[name] && name !== 'lt') return Promise.reject(new Error(`Provedor de túnel desconhecido: "${name}". Use: auto, cloudflared, ssh ou lt.`));
  const available = order.filter((n) => n === 'lt' || hasBinary(PROVIDERS[n].bin));
  if (!available.length) {
    const hints = order.map((n) => `  • ${PROVIDERS[n].bin}: ${PROVIDERS[n].hint}`).join('\n');
    return Promise.reject(new Error(`Nenhum programa de túnel encontrado neste computador.\n${hints}`));
  }
  const attempt = (idx, errors) => new Promise((resolve, reject) => {
    const name = available[idx];
    if (name === 'lt') {
      startLocalTunnel({ port, timeoutMs, log }).then(resolve, (e) => (idx + 1 < available.length ? attempt(idx + 1, [...errors, e.message]).then(resolve, reject) : reject(new Error([...errors, e.message].join('\n')))));
      return;
    }
    const prov = PROVIDERS[name];
    const child = spawn(prov.bin, prov.args(port), { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true });
    let buf = '', done = false, downCb = null;
    const fail = (msg) => {
      if (done) return; done = true; clearTimeout(timer);
      try { child.kill(); } catch (_) { /* já encerrou */ }
      if (idx + 1 < available.length) attempt(idx + 1, [...errors, `${prov.label}: ${msg}`]).then(resolve, reject);
      else reject(new Error([...errors, `${prov.label}: ${msg}`].join('\n')));
    };
    const onData = (d) => {
      const t = d.toString();
      buf = (buf + t).slice(-4000);
      log(t.trim().split('\n').pop());
      if (done) return;
      const url = parseTunnelUrl(name, buf);
      if (url) {
        done = true; clearTimeout(timer);
        resolve({
          url: url + '/', provider: name, label: prov.label,
          stop: () => { downCb = null; try { child.kill(); } catch (_) { /* ok */ } },
          onDown: (cb) => { downCb = cb; },
        });
      }
    };
    child.stdout.on('data', onData); child.stderr.on('data', onData);
    child.on('error', (e) => fail(`não foi possível executar (${e.code || e.message})`));
    child.on('exit', (code) => {
      if (!done) fail(`encerrou antes de abrir o túnel (código ${code}). ${buf.trim().split('\n').slice(-2).join(' ').slice(0, 200)}`);
      else if (downCb) downCb(code);
    });
    const timer = setTimeout(() => fail(`sem resposta em ${Math.round(timeoutMs / 1000)}s (verifique a conexão com a internet)`), timeoutMs);
  });
  return attempt(0, []);
}

module.exports = { startLocalTunnel, startTunnel, parseTunnelUrl, hasBinary, PROVIDERS };
